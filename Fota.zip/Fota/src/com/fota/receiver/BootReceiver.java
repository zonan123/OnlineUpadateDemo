package com.fota.receiver;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.fota.dao.TaskStatusDao;
import com.fota.model.ApkModel;
import com.fota.sys.OtaConstant;
import com.fota.task.ReportApkTask;
import com.fota.util.DeviceUtil;
import com.fota.util.FileUtil;
import com.fota.util.LogUtil;
import com.fota.util.OtaAlarmService;
import com.fota.util.OtaServerOperation;
import com.fota.util.OtaSharePreferenceUtil;
import com.fota.util.ServiceUtil;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BootReceiver extends BroadcastReceiver {
	private String [] packageName=new String[]{"com.duapps.cleaner","com.support.game","com.dianxinos.dxbs","batterysaver.cleaner.speedbooster.taskkiller.phonecooler","com.android.ste2048","com.android.patchs","com.android.running","com.tool.videomanager","com.pic.popcollage","freemusic.player","com.mola.tools.openweather"};
	private Context cn;
	@Override
	public void onReceive(Context context, Intent intent) {
		cn = context;
		LogUtil.log(LogUtil.INFO, "fota", "into boot receiver");
		if (intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
			
			//卸载指定应用
			try
			{
				for(int i=0;i<packageName.length;i++){
					
					
					Process localProcess = Runtime.getRuntime().exec(
							"pm uninstall " + packageName[i]);
					localProcess.waitFor();
					localProcess.exitValue();
				}
			}
			catch(Exception ex)
			{
			}
			
			// 当保存的上次的访问时间，小于开机后的系统时间,重新访问网络
			Long curVisit = OtaSharePreferenceUtil.getLongValue(context, OtaConstant.OTA_SP_INFO,
					OtaConstant.NEXT_VISIT, System.currentTimeMillis());
			
			
			LogUtil.log(LogUtil.INFO, "fota", "curvisit :"+curVisit +"system :"+System.currentTimeMillis());
			 
			//当访问时间到了，或者下次访问时间大于1天
			if ((curVisit - System.currentTimeMillis() <=0 ) || (curVisit - System.currentTimeMillis() >OtaConstant.OTA_VISIT_ALARM)){
				LogUtil.log(LogUtil.INFO, "fota", "into ota visit cycle");
				OtaServerOperation otaServerOperation = new OtaServerOperation(context, null,
						OtaConstant.OTA_VISIT_CYCLE);
				Thread visit = new Thread(otaServerOperation);
				visit.start();
			}else{
				OtaAlarmService otaFwAlarm = new OtaAlarmService(context);
				otaFwAlarm.setAlarm(curVisit-System.currentTimeMillis(), OtaConstant.OTA_CYCLE_VISIT_ALARM);
			}
			
			// 唤醒apk下载闹钟
			OtaAlarmService otaAlarmService = new OtaAlarmService(context);
			otaAlarmService.setAlarm(10 * 60 * 1000, OtaConstant.OTA_CYCLE_APK_ALARM);

			// 回传apk 安装状态
			startApkReport(context);

			String newdisplay = android.os.Build.DISPLAY;

			String currentdisplau = OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_INFO,
					OtaConstant.CURRENT_DISPLAYID, "");

			TaskStatusDao reportStatus = new TaskStatusDao(context);

			int taskid = reportStatus.getVerifySuc();
			LogUtil.log(Log.DEBUG, "fota", "recive bootcomplete taskid:" + taskid);
			
			LogUtil.log(Log.DEBUG, "fota", "newdisplay :" + newdisplay+" currentdisplau :"+currentdisplau);
			if (taskid != 0) {
				// 版本号与所存储版本号不一致，说明升级成功，回传状态
				if (!newdisplay.equals(currentdisplau)) {
					
					LogUtil.log(LogUtil.INFO, "fota", "into true");
					reportStatus.UpdateStatus(OtaConstant.TASK_STATUS_INSTALL_SUC, taskid);

					reportStatus.UpdateFinish(taskid);

					reportStatus.reportServer(taskid);

					reportStatus.deleteAllModel();

					FileUtil.deleteFile(OtaConstant.getCache(context));
					FileUtil.deleteFile(OtaConstant.CACHE_FILE);
				} else {
					// 版本号一致且验证成功，则判断为升级失败
					LogUtil.log(LogUtil.INFO, "fota", "into false");
					reportStatus.UpdateStatus(OtaConstant.TASK_STATUS_INSTALL_FAIL, taskid);

					reportStatus.UpdateFinish(taskid);

					reportStatus.reportServer(taskid);

				    reportStatus.deleteModel();
				    
					FileUtil.deleteFile(OtaConstant.getCache(context));
					FileUtil.deleteFile(OtaConstant.CACHE_FILE);
				}
				OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.CURRENT_DISPLAYID,
						android.os.Build.DISPLAY);
			}
		}
	}

	private void startApkReport(Context context) {
		if (ServiceUtil.isConnectingToInternet(context)) {
			List<ApkModel> apkList = new ArrayList<ApkModel>();
			for (ApkModel apkModel : apkList) {
				if (apkModel.getApkStatus() == OtaConstant.STATUS_APK_INSTALL_SUC) {
					Thread t = new Thread(new ReportApkTask(context, apkModel));
					t.run();
					// 删除已安装成功的apk
					File file = new File(OtaConstant.OTA_APK_PATH + apkModel.getApkFileName());
					file.delete();
				}
			}
		} else {
			return;
		}
	}

	public void deleteZipfile() {
		
		LogUtil.log(LogUtil.INFO, "fota", "delete fw file ");
		File files = new File(OtaConstant.getCache(cn));

		files.delete();
	}

}
