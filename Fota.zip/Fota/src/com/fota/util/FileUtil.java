package com.fota.util;

import java.io.File;
import java.io.FileInputStream;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class FileUtil
{
	public static Bitmap getBitmapFromFile(String filePath)
	{
		Bitmap bitmap = null;
		FileInputStream fis = null;
		
		try
		{
			File file = new File(filePath);
			
			if(!file.exists())
				return null;
			
			fis = new FileInputStream(filePath);
			
			int totalReadLength = 0;
			
			byte[] content = new byte[fis.available()];
			
			byte[] buffer = new byte[1024];
			
			int readLength = -1;
			
			while((readLength = fis.read(buffer))!=-1)
			{
				System.arraycopy(buffer,0, content, totalReadLength, readLength);
				
				totalReadLength += readLength;
			}
			
			bitmap = BitmapFactory.decodeByteArray(content, 0,totalReadLength);
			
		}
		catch(Exception ex)
		{
			LogUtil.log(LogUtil.ERROR, "FileUtil getBitmapFromFile", "fail to translate image to BITMAP:" + ex.getMessage());
		}
		finally
		{
			try{ if(fis!=null)fis.close(); }catch(Exception ex){}
		}
		
		return bitmap;
	}
	
	public static void deleteFile(String filePath)
	{
		try
		{
			Runtime runtime=Runtime.getRuntime();
			String command="chmod 777 "+filePath;
			LogUtil.log(LogUtil.INFO, "fota", "file path  command :"+command);
			runtime.exec(command);
			Thread t=new Thread();
			t.sleep(1000);
			new File(filePath).delete();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
