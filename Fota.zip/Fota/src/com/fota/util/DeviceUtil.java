package com.fota.util;

import java.util.List;
import java.util.Random;
import java.util.UUID;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;

import com.fota.model.ApkModel;
import com.fota.sys.OtaConstant;
import com.fota.R;

public class DeviceUtil
{
	private static char[]	oriChars	= { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
			'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u',
			'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
			'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', '0',
			'1', '2', '3', '4', '5', '6', '7', '8', '9' };
	
	public static String getDeviceId(Context context)
	{
		String deviceID=OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID, "");
		if(!StringUtil.isNullOrEmpty(deviceID)){
			return deviceID;
		}else if(StringUtil.isNullOrEmpty(deviceID)){
			StringBuffer sb = new StringBuffer();
			Random rand = new Random();
			for(int i=0; i<oriChars.length; i++)
			{
				sb.append(oriChars[rand.nextInt(oriChars.length)]);
			}
			UUID uuid = UUID.randomUUID();
			int table= (int)(Math.random()*10); //区分是哪个表
			deviceID=table+uuid.toString().replace("_", "");
		}else{
			deviceID= "0123456789xxxxxxx";
		}
		OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID, deviceID);
		return deviceID;
		
		
	}
	
	public static String getRegistTime(Context context){
		String registerTime=OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.OTA_REGIS_TIME, "");
		return registerTime;
	}
	
	public static String getCurrentSoftVersion(Context _context)
	{
		try
		{
			PackageManager manager = _context.getPackageManager();
			
			PackageInfo info = manager.getPackageInfo(_context.getPackageName(),0);
			
			return info.versionName;
		}
		catch (Exception e)
		{
			LogUtil.log(LogUtil.ERROR,"DeviceUtil getCurrentSoftVersion ", e.getMessage());
			return _context.getResources().getString(R.string.default_softversion);
		}
		
	}
	
	public static Bitmap getBitmapByPackageName(Context context,String packageName)
	{
		Bitmap bm = null;
		
		try
		{ 
			Drawable drawable = null;
			List<PackageInfo> packages = context.getPackageManager()
					.getInstalledPackages(0);
			PackageManager pManager = context.getPackageManager();
			for (PackageInfo pi : packages)
			{
				if (packageName
						.equalsIgnoreCase(pi.applicationInfo.packageName))
				{
					drawable = pManager.getApplicationIcon(pi.applicationInfo);
					drawableToBitmap(drawable);
					break;
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return bm;
	}
	
	public static Bitmap drawableToBitmap(Drawable drawable)
	{
		Bitmap bitmap = Bitmap
				.createBitmap(
						drawable.getIntrinsicWidth(),
						drawable.getIntrinsicHeight(),
						drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888
								: Bitmap.Config.RGB_565);
		Canvas canvas = new Canvas(bitmap);
		drawable.setBounds(0, 0, drawable.getIntrinsicWidth(),
				drawable.getIntrinsicHeight());
		drawable.draw(canvas);
		return bitmap;
	}
	
	public static boolean isExistApk(Context context,ApkModel model)
	{
		try
		{
			List<PackageInfo> packages = context.getPackageManager().getInstalledPackages(0|1);
			for(PackageInfo info : packages )
			{
				if(info.packageName.equalsIgnoreCase(model.getApkPackage()))
						return true;
			}
		}
		catch(Exception ex)
		{
			LogUtil.log(LogUtil.ERROR, "DeviceUtil isExistApk", "判断是否存在APK错误" + ex.getMessage());
		}
		return false;
	}
	
	/*type 1  fw
	 * type 2 apk
	 * */
	public static boolean taskIsExist(int id,int type){
		boolean result=false;
		if(type==1){
			
		}else if(type==2){
			
		}
		return result;
	}
	
	public static boolean isExistPackageInDevice(Context context,String packageName) 
	{
		List<PackageInfo> packages = context.getPackageManager().getInstalledPackages(0);
		
		for (PackageInfo pi : packages) 
		{
			if (packageName.equalsIgnoreCase(pi.applicationInfo.packageName)) 
			{
				return true;
			}
		}
		return false;
	}
	
	public static String GetAllAPPList(Context context){
		PackageManager pckManager = context.getPackageManager();
		Intent intent = new Intent(Intent.ACTION_MAIN, null);
		intent.addCategory(Intent.CATEGORY_LAUNCHER);
		List<ResolveInfo> allApps = pckManager.queryIntentActivities(intent, PackageManager.GET_INTENT_FILTERS);
		StringBuffer sbAllApp=new StringBuffer();
		for(ResolveInfo info:allApps){
			boolean isSystemApp = true;
			try {
				PackageInfo packInfo = context.getPackageManager()
						.getPackageInfo(info.activityInfo.packageName, 0);
				if ((packInfo.applicationInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
				} else if ((packInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
					sbAllApp.append(packInfo.packageName+",");
				}
			} catch (NameNotFoundException e) {
				e.printStackTrace();
			}
			
		} 
		return sbAllApp.toString();
	}
	
	public static ApkModel getApkModelByPackageName(Context context,String packageName) 
	{
		PackageManager pmManager = context.getPackageManager();
		
		List<PackageInfo> packages = context.getPackageManager().getInstalledPackages(0);
		
		try
		{
			for (PackageInfo pi : packages) 
			{
				if (packageName.equalsIgnoreCase(pi.applicationInfo.packageName)) 
				{
					ApkModel model = new ApkModel();
					
//					model.setApkPackage(pi.applicationInfo.packageName);
//					model.setApkVersion(pi.versionName)
//					model.setVersionCode(pi.versionCode);
//					model.setAppName(pmManager.getApplicationLabel(
//							pmManager.getApplicationInfo(pi.applicationInfo.packageName,
//									PackageManager.GET_META_DATA)).toString());
					return model;
				}
			}
		}
		catch(Exception ex)
		{
			LogUtil.log(LogUtil.ERROR,"DeviceUtil getApkModelByPackageName","根据包名取详细数据出错");
		}
		return null;
	}
	
	
	public static String getPackAgeFromPath(Context context,String filePath)
	{
		try
		{
			PackageManager pmManager = context.getPackageManager();
			PackageInfo pkinfo = pmManager.getPackageArchiveInfo(filePath, PackageManager.GET_ACTIVITIES);
			if(pkinfo!=null)
			{
				return pkinfo.packageName;
			}
		}
		catch(Exception ex)
		{
			LogUtil.log(LogUtil.ERROR, "DeviceUtil getPackAgeFromPath", "从APK文件中取得PackageName Error：" + ex.getMessage());
		}
		
		return "";
	}
	
	public static ApkModel getApkModelFromPath(Context context,String filePath)
	{
		try
		{
			PackageManager pmManager = context.getPackageManager();
			PackageInfo pkinfo = pmManager.getPackageArchiveInfo(filePath, PackageManager.GET_ACTIVITIES);
			
			if(pkinfo!=null)
			{
				ApplicationInfo info = pkinfo.applicationInfo;
				ApkModel model = new ApkModel();
//				model.setPackageName(info.packageName);
//				model.setVersionName(pkinfo.versionName);
//				model.setVersionCode(pkinfo.versionCode);
//				model.setAppName(pmManager.getApplicationLabel(
//						pmManager.getApplicationInfo(info.packageName,
//								PackageManager.GET_META_DATA)).toString());
				return model;
			}
		}
		catch(Exception ex)
		{
			LogUtil.log(LogUtil.ERROR, "DeviceUtil getApkModelFromPath", "从APK文件中取得INFO信息错误：" + ex.getMessage());
		}

		return null;
	}
	
//	
//	public ArrayList<ApkModel> getSystemAppInfo(Context context)
//	{
//		ArrayList<ApkModel> list = new ArrayList<ApkModel>();
//		
//		List<PackageInfo> packages = context.getPackageManager()
//				.getInstalledPackages(0);
//		
//		for (PackageInfo packageInfo : packages)
//		{
//			ApkModel model = new ApkModel();
////
////			model.setAppName(packageInfo.applicationInfo.loadLabel(
////					context.getPackageManager()).toString());
////
////			model.setPackageName(packageInfo.packageName);
////
////			model.setVersionCode(packageInfo.versionCode);
////
////			model.setVersionName(packageInfo.versionName);
//
//			boolean needAddToUpload = false;
//
//			if ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0)
//			{
//				// 一定是第三方应用非系统应用--0430决定不统计系统应用
////				model.setAppFlag(0);
//				needAddToUpload = true;
//			}
//			else if ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0)
//			{
//				// 表示是系统程序，但用户更新过，也算是用户安装的程序
////				model.setAppFlag(1);
//				needAddToUpload = true;
//			}
//
//			if (needAddToUpload)
//			{
//				list.add(model);
//			}
//		}
//		
//		LogUtil.log(LogUtil.INFO, "DeviceUtil getSystemAppInfo", "取得所有应用,总数为:" + list.size());
//		
//		return list;
//	}

}
