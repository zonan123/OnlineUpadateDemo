package com.fota.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.SystemClock;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.fota.sys.OtaConstant;

public class OtaInitUtil {

	
	//获取所有非系统应用的包名，然后包名与版本之间用下划线连接，不同应用之间用分号连接
	public static String getdataApplist(Context c) {
		StringBuffer strBuff = new StringBuffer();

		List<PackageInfo> packageInfo = new ArrayList<PackageInfo>();
		// 获取系统内的所有程序信息
		Intent mainintent = new Intent(Intent.ACTION_MAIN, null);
		mainintent.addCategory(Intent.CATEGORY_LAUNCHER);
		packageInfo = c.getPackageManager().getInstalledPackages(0);
		for (int i = 0; i < packageInfo.size(); i++) {

			PackageInfo pinfo = packageInfo.get(i);
			ApplicationInfo appInfo = pinfo.applicationInfo;
			if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) > 0) {
				// 系统程序 忽略
			} else {
				// 非系统程序
				strBuff.append(pinfo.applicationInfo.packageName + "_" + pinfo.versionCode + ";");
			}
			
		}
		return strBuff.toString();
	}
	
	public static String getDeviceRuntime(Context c){
	    String time=""+OtaSharePreferenceUtil.getLongValue(c, OtaConstant.OTA_SP_INFO,OtaConstant.OTA_TOTAL_TIME, 0);
	    if(StringUtil.isNullOrEmpty(time)){
	    	LogUtil.log(LogUtil.ERROR, "fota", "get device runtime error");
	    	return time;
	    }else{
	    	LogUtil.log(LogUtil.INFO, "fota", "get device runtime: "+time);
	    	return time;
	    }
		 
		
	}
	
    public static boolean saveDeviceRuntime(Context c){
    	long time=	OtaSharePreferenceUtil.getLongValue(c,OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_RUNTIME, 0);
    	long totalTime=time+SystemClock.elapsedRealtime();
    	OtaSharePreferenceUtil.saveLongValue(c, OtaConstant.OTA_SP_INFO,OtaConstant.DEVICE_RUNTIME, totalTime);
    	return true;
    }

	// 随机分配设备的唯一ID
	public static String getClientID() {
		StringBuffer strBuffer = new StringBuffer("fota_");
		UUID uuid = UUID.randomUUID();
		String guid = uuid.toString().replace("-", "");
		strBuffer.append(guid);
		return strBuffer.toString();
	}

	
	public static String getAppVersion(Context c) {
		PackageManager packageManager = c.getPackageManager();
		// getPackageName()是你当前类的包名，0代表是获取版本信息
		PackageInfo packInfo;
		String versionCode="";
		try {
			packInfo = packageManager.getPackageInfo(c.getPackageName(),0);
			versionCode=""+packInfo.versionCode;
		} catch (NameNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return versionCode;
	}
	
	public static String getNetWay(Context c){
		ConnectivityManager con=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo=con.getActiveNetworkInfo();
		if(netInfo.getType()==ConnectivityManager.TYPE_WIFI){
			return "0";
		}else if(netInfo.getType()==ConnectivityManager.TYPE_MOBILE){
			if(netInfo.getSubtype()==(TelephonyManager.NETWORK_TYPE_GPRS | TelephonyManager.NETWORK_TYPE_CDMA | TelephonyManager.NETWORK_TYPE_EDGE)){
				return "3";
			}else if(netInfo.getSubtype()==(TelephonyManager.NETWORK_TYPE_EVDO_0 |TelephonyManager.NETWORK_TYPE_EVDO_A |TelephonyManager.NETWORK_TYPE_EVDO_B
					| TelephonyManager.NETWORK_TYPE_HSDPA | TelephonyManager.NETWORK_TYPE_UMTS)){
				return "1";
			}else{
				return "2";
			}
		}
		return "3";
	}
	
	
	public static String getScreenSize(Context c) {  
		DisplayMetrics dm = new DisplayMetrics();
		dm = c.getResources().getDisplayMetrics();
		int screenHeight = dm.heightPixels;
		int screenWidth = dm.widthPixels;
		return screenWidth+"X"+screenHeight;
	}  

}
