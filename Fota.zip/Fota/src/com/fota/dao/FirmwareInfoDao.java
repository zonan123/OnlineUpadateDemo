package com.fota.dao;

import java.util.ArrayList;
import java.util.List;

import com.fota.model.FirmwareInfoModel;
import com.fota.util.LogUtil;

import android.content.Context;
import android.database.Cursor;

public class FirmwareInfoDao {
	
	
	public static boolean saveFwInfo(Context context,List<FirmwareInfoModel> infoList){
		boolean result=false;
		try{
			for(FirmwareInfoModel info:infoList){
				String sql="replace into fw_info "+
					   "(info_id,info_fw_id,info_context) "+
						"values ("+info.getFwInfoId()+","+info.getFwID()+",'"+info.getFwInfoContext()+"')";
				LogUtil.log(LogUtil.INFO, "fota", "insert info sql:"+sql);
				OtaDbUtil dbUtil=OtaDbUtil.getOtaDbUtil(context);
				dbUtil.exec(sql);
				result=true;
			}
		}catch(Exception ex){
			result=false;
			ex.printStackTrace();
		}
		return result;
	}
	
	
	public static List<FirmwareInfoModel> getFwInfoList(int fwId,Context context){
		List<FirmwareInfoModel> fwInfoList=new ArrayList<FirmwareInfoModel>();
		String sql="select * from fw_info where info_fw_id=?";
		Cursor cursor=OtaDbUtil.getOtaDbUtil(context).rawquery(sql,new String[]{fwId+""});
		while(cursor.moveToNext()){
			FirmwareInfoModel fwInfo=new FirmwareInfoModel();
			fwInfo.setFwID(cursor.getInt(cursor.getColumnIndex("info_fw_id")));
			fwInfo.setFwInfoContext(cursor.getString(cursor.getColumnIndex("info_context")));
			fwInfo.setFwInfoId(cursor.getInt(cursor.getColumnIndex("info_id")));
			fwInfoList.add(fwInfo);
		}
		if (cursor != null) {
			cursor.close();
		}
		return fwInfoList;
		
	}
	
	public static boolean dropFwInfo(Context context,int fwId){
		boolean result=false;
		String sql="delete from fw_info where info_fw_id="+fwId;
		try{
		
		OtaDbUtil.getOtaDbUtil(context).exec(sql);
		result=true;
		}catch(Exception ex){
			LogUtil.log(LogUtil.INFO, "fota", "delete info sql:"+sql);
			ex.printStackTrace();
		}
		return result;
	}

}
