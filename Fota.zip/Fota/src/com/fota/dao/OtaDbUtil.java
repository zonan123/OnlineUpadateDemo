package com.fota.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class OtaDbUtil 
{

	public  static final String DB_NAME="ota.db";
	
	public static final int DB_VERSION = 1;
	
	public DbHelper dbHelper;
	
	public SQLiteDatabase db;
	
	private static OtaDbUtil otaDbUtil;
	
	public static OtaDbUtil getOtaDbUtil(Context context) {
		if(otaDbUtil==null || !otaDbUtil.db.isOpen()){
			 synchronized(OtaDbUtil.class){
	                if(otaDbUtil==null){
	                	otaDbUtil=new OtaDbUtil(context);
	                }
	            }
		}
		return otaDbUtil;
	}

	public final  Context _context;
	
	public String device_table = "create table if not exists device_table(dev_id varchar(50)," +
			"dev_device  varchar(20)," +
			"dev_brand  varchar(30)," +
			"dev_manufacturer varchar(30)," +
			"dev_model varchar(30)," +
			"dev_version varchar(30)," +
			"dev_firmware varchar(30)," +
			"dev_record  integer default 0," +
			"dev_data varchar(30)," +
			"dev_next_push long default 0," +
			"dev_push_status integer default 0," +
			"dev_app_version varchar(30)" +
			")";
	
	
	public String fw_info = "create table if not exists fw_info(info_id integer primary key," +
			"info_fw_id  integer," +
			"info_context  varchar(400)" +
			")";
	
	public String ota_apk_table = "create table if not exists ota_apk_table(Apk_id integer primary key," +
			"Apk_package varchar(30)," +
			"Apk_md5 varchar(60)," +
			"Apk_total_size integer," +
			"Apk_download_url integer," +
			"Apk_filename varchar(60)," +
			"Apk_type integer," +
			"Apk_version varchar(100)," +
			"Apk_download_size integer," +
			"Apk_download_count integer," +
			"Apk_status integer," +
			"Apk_click integer " +
			")";
	
	
	public String firmware_infomation_table = "create table if not exists firmware_infomation(fw_id integer primary key autoincrement," +
			"fw_cur_version varchar(30)," +
			"fw_targer_version varchar(30)," +
			"fw_total_size integer," +
			"fw_download_size integer," +
			"fw_md5 varchar(60))";
	
	public String mission_table = "create table if not exists mission_table(_id integer primary key autoincrement," +
			"new_display varchar(200)," +
			"file_md5 varchar(200)," +
			"apk_md5 varchar(200)," +
			"push_status int default 0," +
			"firm_url varchar(200)," +
			"apk_url varchar(200)," +
			"apk_version varchar(200)," +
			"apk_name varchar(200)," +
			"firw_name varchar(200)," +
			"firw_totalsize long default 0" +
			")";
	
	public String task_status_table = "create table if not exists task_status(task_id integer primary key autoincrement," +
			"task_descrip int default 0," +
			"task_status int default 0," +
			"finish int default 0)";
			
	
	class DbHelper extends SQLiteOpenHelper
	{
		public DbHelper(Context context)
		{
			super(context, DB_NAME, null, DB_VERSION);
		}
		
		@Override
		public void onCreate(SQLiteDatabase db)
		{
			db.execSQL(device_table);
			db.execSQL(ota_apk_table);
			db.execSQL(firmware_infomation_table);
			db.execSQL(mission_table);
			db.execSQL(task_status_table);
			db.execSQL(fw_info);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) 
		{
			db.execSQL("DROP TABLE IF EXISTS device_table");
	        db.execSQL("DROP TABLE IF EXISTS ota_apk_table");
	        db.execSQL("DROP TABLE IF EXISTS firmware_infomation_table");
	        db.execSQL("DROP TABLE IF EXISTS mission_table");
	        db.execSQL("DROP TABLE IF EXISTS task_status_table");
	        db.execSQL("DROP TABLE IF EXISTS fw_info");
	        onCreate(db);
		}
	}
	
	public OtaDbUtil(Context context) 
	{
		_context = context;
		dbHelper = new DbHelper(context);
		db = dbHelper.getWritableDatabase();
	}
	
	public void exec(String sql)
	{
		db.execSQL(sql);
	}
	
	public void exec(String sql,Object[] bindArgs)
	{
		db.execSQL(sql, bindArgs);
	}
	
	public long insert(String table,String nullColumnHack,ContentValues values)
	{
		return db.insert(table, nullColumnHack, values);
	}
	
	public Cursor rawquery(String sql,String[] selectionArgs)
	{
		return db.rawQuery(sql, selectionArgs);
	}
	
	
	public void close()
	{
		db.close();
	}
	
	public SQLiteDatabase getDatebase()
	{
		return db;
	}
	
	public String sqliteEscape(String keyWord){  
	    keyWord = keyWord.replace("/", "//");  
	    keyWord = keyWord.replace("'", "''");  
	    keyWord = keyWord.replace("[", "/[");  
	    keyWord = keyWord.replace("]", "/]");  
	    keyWord = keyWord.replace("%", "/%");  
	    keyWord = keyWord.replace("&","/&");  
	    keyWord = keyWord.replace("_", "/_");  
	    keyWord = keyWord.replace("(", "/(");  
	    keyWord = keyWord.replace(")", "/)");
	    return keyWord;  
	}
	public String sqliteUnescape(String keyWord){  
	    keyWord = keyWord.replace("//", "/");  
	    keyWord = keyWord.replace("''", "'");  
	    keyWord = keyWord.replace("/[", "[");  
	    keyWord = keyWord.replace("/]", "]");  
	    keyWord = keyWord.replace("/%", "%");  
	    keyWord = keyWord.replace("/&","&");  
	    keyWord = keyWord.replace("/_", "_");  
	    keyWord = keyWord.replace("/(", "(");  
	    keyWord = keyWord.replace("/)", ")");
	    return keyWord;  
	}  
	
}
