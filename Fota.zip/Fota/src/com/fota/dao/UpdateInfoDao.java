package com.fota.dao;

import java.util.ArrayList;
import java.util.List;

import com.fota.model.UpdateInfoModel;
import com.fota.util.LogUtil;

import android.content.Context;
import android.database.Cursor;

public class UpdateInfoDao {
	
	public static boolean saveUpdateInfo(List<UpdateInfoModel> infoList,Context context){
//		UpdateInfoModel infoModel=new UpdateInfoModel();
		try{
		for(UpdateInfoModel infoModel:infoList){
			String sql="replace into fw_info "+
					"(infoId,infoFwId,infoContext) "+
					"values ("+infoModel.getInfoId()+","+infoModel.getInfoFwId()+","+infoModel.getInfoContext()+")";
			LogUtil.log(LogUtil.ERROR, "fota", "save update info sql :"+sql);
			OtaDbUtil dbUtil= OtaDbUtil.getOtaDbUtil(context);
			dbUtil.exec(sql);
		}
		}catch (Exception ex){
			LogUtil.log(LogUtil.ERROR, "fota", "save uptate info error");
			ex.printStackTrace();
		}
		
		return false;
		
	}
	
	public static List<UpdateInfoModel> getInfoList(Context context){
		String sql="select * from fw_info";
	    List<UpdateInfoModel> infoList=new ArrayList<UpdateInfoModel>();
		OtaDbUtil dbUtil=null;
		Cursor cursor=null;
		try{
		dbUtil=OtaDbUtil.getOtaDbUtil(context);
		cursor=dbUtil.rawquery(sql, null);
			
		for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
			UpdateInfoModel infoModel=new UpdateInfoModel();
			infoModel.setInfoContext(cursor.getString(cursor.getColumnIndex("info_context")));
			infoModel.setInfoFwId(cursor.getInt(cursor.getColumnIndex("info_fw_id")));
			infoModel.setInfoId(cursor.getInt(cursor.getColumnIndex("info_id")));
			infoList.add(infoModel);
		}
		}catch(Exception ex){
			ex.printStackTrace();
		}finally {
			if(cursor!=null)
				cursor.close();
		}
		
		return infoList;
	}

}
