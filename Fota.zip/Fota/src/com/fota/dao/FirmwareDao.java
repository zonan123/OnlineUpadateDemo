package com.fota.dao;

import org.json.JSONObject;

import com.fota.model.FirmwareModel;
import com.fota.sys.OtaConstant;
import com.fota.util.LogUtil;
import com.fota.util.OtaSharePreferenceUtil;

import android.content.Context;

public class FirmwareDao {

	// 保存到sharedpreference中
	public static boolean saveFw(Context context, JSONObject fwJson) {
		boolean result = false;
		try {
			OtaSharePreferenceUtil.saveIntValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_ID,
					fwJson.optInt(""));
			OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_CUR_VERSION,
					fwJson.optString(""));
			OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_TARGET_VERSION,
					fwJson.optString(""));
			OtaSharePreferenceUtil.saveIntValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_TOTAL_SIZE,
					fwJson.optInt(""));
			OtaSharePreferenceUtil.saveIntValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_DOWNLOAD_SIZE,
					fwJson.optInt(""));

			OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_MD4,
					fwJson.optString(""));
			OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_DOWNLOAD_URL,
					fwJson.optString(""));
			OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_FILE_NAME,
					fwJson.optString(""));

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return result;
	}

	// 保存到sharedpreference中
	public static boolean saveFw(Context context, FirmwareModel fwModel) {
		boolean result = false;
		if (fwModel != null) {
			try {
				OtaSharePreferenceUtil.saveIntValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_ID,
						fwModel.getFwID());
				OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_CUR_VERSION,
						fwModel.getFwCurVersion());
				OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_FW,
						OtaConstant.OTA_FW_TARGET_VERSION, fwModel.getFwTargetVersion());
				OtaSharePreferenceUtil.saveIntValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_TOTAL_SIZE,
						fwModel.getFwTotailSize());
				OtaSharePreferenceUtil.saveIntValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_DOWNLOAD_SIZE,
						fwModel.getFwDownLoadSize());

				OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_MD4,
						fwModel.getFwMd5());
				OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_DOWNLOAD_URL,
						fwModel.getFwDownloadUrl());
				OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_FILE_NAME,
						fwModel.getFwFileName());
				result=true;
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}

	public static FirmwareModel getFw(Context context) {
		FirmwareModel fwModel = new FirmwareModel();
		fwModel.setFwID(OtaSharePreferenceUtil.getIntValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_ID, -1));
		fwModel.setFwCurVersion(OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_FW,
				OtaConstant.OTA_FW_CUR_VERSION, ""));
		fwModel.setFwTargetVersion(OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_FW,
				OtaConstant.OTA_FW_TARGET_VERSION, ""));
		fwModel.setFwTotailSize(
				OtaSharePreferenceUtil.getIntValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_TOTAL_SIZE, -1));
		fwModel.setFwDownLoadSize(OtaSharePreferenceUtil.getIntValue(context, OtaConstant.OTA_SP_FW,
				OtaConstant.OTA_FW_DOWNLOAD_SIZE, -1));
		fwModel.setFwMd5(
				OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_FW, OtaConstant.OTA_FW_MD4, ""));
		fwModel.setFwDownloadUrl(OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_FW,
				OtaConstant.OTA_FW_DOWNLOAD_URL, ""));
		fwModel.setFwFileName(OtaSharePreferenceUtil.getStringValue(context, OtaConstant.OTA_SP_FW,
				OtaConstant.OTA_FW_FILE_NAME, ""));
		LogUtil.log(LogUtil.INFO, "fota", "get fw model is :"+fwModel.toString());
		return fwModel;
	}

}
