package com.fota.dao;


import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import com.fota.model.MissionModel;
import com.fota.sys.OtaConstant;
import com.fota.util.LogUtil;
import com.fota.util.OtaServerOperation;
import com.fota.util.OtaSharePreferenceUtil;

public class TaskStatusDao 
{
	
	public  Context context;
	
	public TaskStatusDao(Context cn)
	{
		this.context = cn;
	}
	
	public  void TaskStatusBegin(int descrip,int status)
	{
		OtaDbUtil dbUtil = null;
		
		try 
		{
			
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String insert = "insert into task_status(task_descrip,task_status)  values("+descrip+","+status+")";
			
			dbUtil.exec(insert);
			
		}
		catch (Exception e)
		{
			LogUtil.log(Log.DEBUG, "saveTaskStatus", "保存数据错误：" + e.getMessage());
		}
		finally
		{
			try 
			{
				//if(dbUtil!=null)dbUtil.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
	}
	
	public void UpdateStatus(int status,int id)
	{
		OtaDbUtil dbUtil = null;
		
		try 
		{
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String update = "update task_status set task_status = " + status + "  where task_id = " + id;
			
			dbUtil.exec(update);
		}
		catch (Exception e) 
		{
			LogUtil.log(Log.DEBUG, "UpdateStatus", "更新任务状态错误：" + e.getMessage());
			
		}
		finally
		{
			try 
			{
			//	if(dbUtil!=null)dbUtil.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
	}
	
	public void UpdateFinish(int taskid)
	{
		OtaDbUtil dbUtil = null;
		
		try 
		{
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String update = "update task_status set finish = 1  where task_id = "+taskid;
			
			dbUtil.exec(update);
		} 
		catch (Exception e) 
		{
			LogUtil.log(Log.DEBUG, "UpdateFinish", "跟新完成状态错误：" + e.getMessage());
		}
		finally
		{
			try 
			{
			//	if(dbUtil!=null)dbUtil.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
	}
	
	public int getTaskId(int descrip,int status)
	{
		OtaDbUtil dbUtil = null;
		
		Cursor cursor = null;
		
		int taskId = 0;
		
		try 
		{
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String select = "select * from task_status where task_descrip = "+descrip+" and task_status = "+status;
			
			cursor = dbUtil.rawquery(select, null);
			
			if(cursor.moveToNext())
			{
				taskId = cursor.getInt(cursor.getColumnIndex("task_id"));
			}
		} 
		catch (Exception e) 
		{
			Log.d("fota", "get id error:" + e.getMessage());
		}
		finally
		{
			try 
			{
				//if(dbUtil!=null)dbUtil.close();
				if(cursor!=null)cursor.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		
		return taskId;
	}
	
	public int getFinish(int id)
	{
		OtaDbUtil dbUtil = null;
		
		Cursor cursor = null;
		
		int finish = 0;
		
		try 
		{
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String select = "select * from task_status where task_id ="+id;
			
			cursor = dbUtil.rawquery(select, null);
			
			if(cursor.moveToNext())
			{
				finish = cursor.getInt(cursor.getColumnIndex("finish"));
			}
			return finish;
		} 
		catch (Exception e) 
		{
			LogUtil.log(Log.DEBUG, "getFinish", "获取finish状态出错" + e.getMessage());
		}
		finally
		{
			try 
			{
				//if(dbUtil!=null)dbUtil.close();
				if(cursor!=null)cursor.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		
		return finish;
	}
	
	public int getVerifySuc()
	{
		OtaDbUtil dbUtil = null;
		
		Cursor cursor = null;
		
		int taskid = 0;
		
		try 
		{
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String select = "select * from task_status where task_descrip = 1 order by task_id desc limit 1 ";
			
			cursor = dbUtil.rawquery(select, null);
			
			if(cursor.moveToNext())
			{
				taskid = cursor.getInt(cursor.getColumnIndex("task_id"));
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
			// TODO: handle exception
		}finally {
			if(cursor!=null)
			cursor.close();
		}
		
		return taskid;
	}
	
	public  void DeleteStatus(int taskid)
	{
		OtaDbUtil dbUtil = null;
		
		try 
		{
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String delete = "delete from task_status where task_id = " + taskid;
//			String delete = "delete from task_status where finish = 1";
			dbUtil.exec(delete);
			
		} 
		catch (Exception e) 
		{
			LogUtil.log(Log.DEBUG, "DeleteStatus", "删除任务出错：" + e.getMessage());
		}
		finally
		{
			try 
			{
				//if(dbUtil!=null)dbUtil.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
	}
	
	public int getSelfupdate()
	{
		OtaDbUtil dbUtil = null;
		
		Cursor cursor = null;
		
		int task_descrip = 0;
		
		int task_status = 0;
		
		int task_id = 0;
		
		try 
		{
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String select = "select  * from task_status where task_descrip = 2 and task_status = 1 and finish = 0";
			
			cursor = dbUtil.rawquery(select, null);
			
			if(cursor.moveToNext())
			{
				task_descrip = cursor.getInt(cursor.getColumnIndex("task_descrip"));
				
				task_status = cursor.getInt(cursor.getColumnIndex("task_status"));
				
				task_id = cursor.getInt(cursor.getColumnIndex("task_id"));
				
//				if(task_descrip!=0&&task_status!=0)
//				{
//					return true;
//				}
			}
		} 
		catch (Exception e)
		{
			LogUtil.log(Log.DEBUG, "getSelfupdate", "获取自升级任务失败"+e.getMessage());
		}
		finally
		{
			try 
			{
				//if(dbUtil!=null)dbUtil.close();
				if(cursor!=null)cursor.close();;
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}

		return task_id;
	}
	
	public int getDownloaFail()
	{
		OtaDbUtil dbUtil = null;
		
		Cursor cursor = null;
		
		int id = 0;
		
		try 
		{
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String select = "select * from task_status where task_descrip = 2 and task_status = 2 and finish = 0";
			
			cursor = dbUtil.rawquery(select, null);
			
			if(cursor.moveToNext())
			{
				id = cursor.getInt(cursor.getColumnIndex("task_id"));
			}
			
		}
		catch (Exception e)
		{
			LogUtil.log(Log.DEBUG, "getDownloaFail", "获取下载失败自升级任务出错：" + e.getMessage());
		}
		finally
		{
			try 
			{
				//if(dbUtil!=null)dbUtil.close();
				if(cursor!=null)cursor.close();
			} 
			catch (Exception e2) 
			{
				// TODO: handle exception
			}
		}
		
		return id;
	}
	
	public void saveModel(MissionModel model)
	 {
		 OtaDbUtil dbUtil = null;
		 
		 try 
		 {
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			LogUtil.log(Log.DEBUG, "mission model :", model.toString() +"total size :"+model.getTotalsize());
			
			String insert = "insert into mission_table(new_display,file_md5,firm_url,firw_name,firw_totalsize)" +
					"  values('"+ 
						dbUtil.sqliteEscape(model.getNewdisplay())+"','"+
						dbUtil.sqliteEscape(model.getFilemd5())+"','"+
						dbUtil.sqliteEscape(model.getFirmurl())+"','"+
						dbUtil.sqliteEscape(model.getFirwname()) +"'," +
						model.getTotalsize() + ")";
			
			dbUtil.exec(insert);
		 } 
		 catch (Exception e) 
		 {
			 e.printStackTrace();
			LogUtil.log(Log.DEBUG, "saveModel", "保存服务器下发数据出错：" + e.getMessage());
		 } 
		 finally
		 {
			try 
			{
				//if(dbUtil!=null)dbUtil.close();
			} catch (Exception e2) {
					// TODO: handle exception
			}
		 }
	 }
	
	public MissionModel getModel()
	{
		OtaDbUtil dbUtil = null;
		
		Cursor cursor = null;
		
		MissionModel model = new MissionModel();
		
		try 
		{
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String select = "select * from mission_table where _id = (select max(_id) from mission_table)";
			
			cursor = dbUtil.rawquery(select, null);
			
			if(cursor.moveToNext())
			{	//08-28
				
				model.setFilemd5(dbUtil.sqliteUnescape(cursor.getString(cursor.getColumnIndex("file_md5"))));
				
				model.setFirmurl(dbUtil.sqliteUnescape(cursor.getString(cursor.getColumnIndex("firm_url"))));
				
				model.setNewdisplay(dbUtil.sqliteUnescape(cursor.getString(cursor.getColumnIndex("new_display"))));
				
				model.setFirwname(dbUtil.sqliteUnescape(cursor.getString(cursor.getColumnIndex("firw_name"))));
				
				model.setTotalsize(cursor.getLong(cursor.getColumnIndex("firw_totalsize")));
				
				
			}
			if(cursor!=null){
				cursor.close();
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			LogUtil.log(Log.DEBUG, "getModel", "获取存数数据出错：" + e.getMessage());
		}
		finally
		{
			try 
			{
				//if(dbUtil!=null)dbUtil.close();
				if(cursor!=null)cursor.close();
			} catch (Exception e2) 
			{
				// TODO: handle exception
			}
		}
		Log.d("fota", "get mission model");
		return model;
	}
	
	public void deleteModel()
	{
		OtaDbUtil dbUtil = null;
		
		try 
		{
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String delete = "delete from  mission_table where _id = (select max(_id) from mission_table)";
			
			dbUtil.exec(delete);
		} 
		catch (Exception e) 
		{
			LogUtil.log(Log.DEBUG, "deleteModel", "删除model出错：" + e.getMessage());
		}
		finally
		{
			try 
			{
			//	if(dbUtil!=null)dbUtil.close();
			} 
			catch (Exception e2) 
			{
				// TODO: handle exception
			}
		}
	}
	
	public void deleteAllModel()
	{
		OtaDbUtil dbUtil = null;
		
		try 
		{
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String  deleteall = "delete from mission_table";
			
			dbUtil.exec(deleteall);
		} 
		catch (Exception e)
		{
			LogUtil.log(Log.DEBUG, "deleteAllModel", "删除所有记录出错："+e.getMessage());
			Log.d("fota", "delete all model fail:" + e.getMessage());
		}
		finally
		{
			try 
			{
				//if(dbUtil!=null)dbUtil.close();
			} 
			catch (Exception e2) {
				// TODO: handle exception
			}
		}
	}
	
	public void reportServer(int taskid)
	{
		
		OtaDbUtil dbUtil = null;
		
		Cursor cursor = null;
		
		int taskstatus = 0;
		
		int taskdescript = 0;
		
		
		
		LogUtil.log(Log.DEBUG, "fota", "into report fw install");
		try 
		{
			
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String select;
			
			select = "select * from task_status where task_id = (select max(task_id) from task_status)";
//			select = "select * from task_status where task_id = " + taskid;
			
			cursor = dbUtil.rawquery(select, null);
			
			if(cursor.moveToNext())
			{
				taskdescript = cursor.getInt(cursor.getColumnIndex("task_descrip"));
				
				taskstatus = cursor.getInt(cursor.getColumnIndex("task_status"));
			} 
			LogUtil.log(Log.DEBUG, "fota", "task report  taskstatus: "+taskstatus+" taskdescript : "+taskdescript);
		}
		catch (Exception e)
		{
			LogUtil.log(Log.DEBUG, "fota", "任务状态报告回传出错: " + e.getMessage());
		}
		finally
		{
			try 
			{
				//if(dbUtil!=null)dbUtil.close();
				if(cursor!=null)cursor.close();
			} 
			catch (Exception e2) {
				// TODO: handle exception
			}
		}
		boolean isreporting = OtaSharePreferenceUtil.getBooleanValue(context, OtaConstant.OTA_SP_INFO,OtaConstant.IS_REPORTING,true);
		Log.d("fota", "report server taskid:" + taskid+"  taskdescrip:"+taskdescript+"  taskstatus:"+taskstatus+"isreporting :"+isreporting);
		if(taskdescript!=0 && taskstatus!=0)
		{
			LogUtil.log(LogUtil.INFO, "fota", "into report thread");
			OtaServerOperation otaServerOperation = new OtaServerOperation(context, null,true);
			otaServerOperation.setReport(true, taskdescript, taskstatus,taskid);
			Thread thread = new Thread(otaServerOperation);
			thread.start();
		}
		
	}
	
	public void scanReport()
	{
		OtaDbUtil dbUtil = null;
		
		Cursor cursor = null;
	    
		int taskstatus = 0;
		
		int taskdescript = 0;
		
		int taskid = 0;
		
		OtaServerOperation otaServerOperation = new OtaServerOperation(context, null);
		try 
		{
			
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			
			String select;
			
			select = "select * from task_status where finish = 1";
			
			cursor = dbUtil.rawquery(select, null);
			LogUtil.log(Log.DEBUG, "fota", "cursor length:" + cursor.getColumnCount() + "row:" + cursor.getCount());
			if(cursor.moveToFirst())
			{
				taskdescript = cursor.getInt(cursor.getColumnIndex("task_descrip"));
				
				taskstatus = cursor.getInt(cursor.getColumnIndex("task_status"));
				
				taskid = cursor.getInt(cursor.getColumnIndex("task_id"));
				LogUtil.log(Log.DEBUG, "fota", "descrip:"+taskdescript+"   status:"+taskstatus+"   id:"+taskid);
			} 
			
		}
		catch (Exception e)
		{
			LogUtil.log(Log.DEBUG, "fota", "扫描未回传任务失败" + e.getMessage());
		}
		finally
		{
			try 
			{
				//if(dbUtil!=null)dbUtil.close();
				if(cursor!=null)cursor.close();
			} 
			catch (Exception e2) {
				// TODO: handle exception
			}
		}
		
		boolean isReporting = OtaSharePreferenceUtil.getBooleanValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.IS_REPORTING, false);
		Log.d("fota", "scane report task,descrip:" + taskdescript+"  status:"+taskstatus+"  taskid:"+taskid+"  isReporting:"+isReporting);
		if(taskdescript!=0&&taskstatus!=0)
		{
			otaServerOperation.setReport(true, taskdescript, taskstatus,taskid);
			
			Thread thread = new Thread(otaServerOperation);
			
			thread.start();
		}
		
	}
}
