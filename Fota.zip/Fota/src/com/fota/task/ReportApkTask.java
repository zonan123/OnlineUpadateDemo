package com.fota.task;

import java.util.HashMap;
import java.util.Map;

import com.fota.dao.ApkDao;
import com.fota.model.ApkModel;
import com.fota.sys.OtaConstant;
import com.fota.util.DeviceUtil;
import com.fota.util.LogUtil;
import com.fota.util.OtaInitUtil;
import com.fota.util.ServiceUtil;
import com.fota.R;

import android.content.Context;
import android.os.Build;

public class ReportApkTask implements Runnable {
	
	
	private Context context;
	private ApkModel apkModel;
	
	
	public ReportApkTask(Context context,ApkModel apkModel) {
		// TODO Auto-generated constructor stub
		this.context=context;
		this.apkModel=apkModel;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		Thread t=new Thread();
		try {
			t.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		apkReport();

	}
	
	private Map<String, String> getReportPara(){
		Map<String, String> paraMap=new HashMap<String, String>();
		paraMap.put("report_uuid", DeviceUtil.getDeviceId(context));
		paraMap.put("report_qudaohao", context.getResources().getString(R.string.channel_name));
		paraMap.put("report_apk_id", ""+apkModel.getApkId());
		paraMap.put("report_system_version", Build.VERSION.SDK);
		paraMap.put("report_status", ""+apkModel.getApkStatus());
		paraMap.put("report_net_way", OtaInitUtil.getNetWay(context));
		paraMap.put("report_soft_version", new DeviceUtil().getCurrentSoftVersion(context));
		LogUtil.log(LogUtil.INFO, "fota", "report parm :"+paraMap.values().toString());
		return paraMap;
	}
	
	
	
	private void apkReport(){
		String result=ServiceUtil.sendGet(OtaConstant.OTA_BASE+OtaConstant.OTA_APK_REPORT, getReportPara());
		if(result.equalsIgnoreCase("ok")){
			ApkDao.dropApkInfoByKey(apkModel.getApkId(), context);
		}else{
			LogUtil.log(LogUtil.ERROR, "fota", "report apk download info error");
		}
	}

}
