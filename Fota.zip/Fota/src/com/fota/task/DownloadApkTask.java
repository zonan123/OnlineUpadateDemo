package com.fota.task;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import com.fota.dao.ApkDao;
import com.fota.model.ApkModel;
import com.fota.service.SelfUpdate;
import com.fota.sys.OtaConstant;
import com.fota.util.FileMd5;
import com.fota.util.FileUtil;
import com.fota.util.LogUtil;
import com.fota.util.OtaAlarmService;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

public class DownloadApkTask implements Runnable {

	private ApkModel apkModel;
	private Context context;

	public DownloadApkTask(ApkModel apkModel, Context context) {
		// TODO Auto-generated constructor stub
		this.apkModel = apkModel;
		this.context = context;
	}

	public void downloadApk(ApkModel apkModel) {

		LogUtil.log(LogUtil.INFO, "fota", Environment.getExternalStorageDirectory().getPath());
		LogUtil.log(LogUtil.INFO, "fota", Environment.getDataDirectory().getPath());
		LogUtil.log(LogUtil.INFO, "fota", Environment.getExternalStorageDirectory().getPath());

		// 应用最多下载三次，三次都失败时，回传任务，并且删除
		if (apkModel.getApkDownloadCount() > OtaConstant.OTA_APK_DOWNLOAD_ALLOW_ERR) {

			apkModel.setApkStatus(OtaConstant.STATUS_APK_DOWNLOAD_FAIL);
			ApkDao.saveApkModel(apkModel, context);
			ApkDao.dropApkInfoByKey(apkModel.getApkId(), context);
			//删除三次下载失败的应用文件
			File file=new File(OtaConstant.OTA_APK_PATH+apkModel.getApkFileName());
			file.delete();

			new ReportApkTask(context, apkModel).run();
			return;
		} else {
			apkModel.setApkDownloadCount(apkModel.getApkDownloadCount() + 1);
			ApkDao.saveApkModel(apkModel, context);
		}

		InputStream instream = null;

		FileOutputStream outsteam = null;

		File savefile = null;

		try {

			URL url = new URL(apkModel.getApkDownloadUrl());

			URLConnection uConnection = url.openConnection();

			uConnection.setDoInput(true);

			uConnection.setDoOutput(true);

			uConnection.setConnectTimeout(500000);

			uConnection.setReadTimeout(500000);

			uConnection.setRequestProperty("accept", "*/*");

			uConnection.setRequestProperty("connection", "Keep-Alive");

			uConnection.setRequestProperty("user-agent",
					"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.34 Safari/534.24");

			savefile = new File(OtaConstant.OTA_APK_PATH + apkModel.getApkFileName());

			long exitfilelength = 0;

			if (savefile.exists()) {
				exitfilelength = savefile.length();
			} else {
				savefile.createNewFile();
			}
			LogUtil.log(Log.DEBUG, "fota", "download apk length is:" + exitfilelength);
			long downsize = exitfilelength;
			//当文件存在 并且 已下载大小小于文件总大小
			if (exitfilelength >= 0 && exitfilelength < apkModel.getApkTotalSize()) {
				uConnection.setRequestProperty("Range", "bytes=" + exitfilelength + "-");
				LogUtil.log(Log.DEBUG, "fota", "range : bytes=" + exitfilelength + "-");

				uConnection.connect();

				int responseCode = ((HttpURLConnection) uConnection).getResponseCode();
				LogUtil.log(Log.DEBUG, "fota", "response code:" + responseCode);

				instream = uConnection.getInputStream();
				LogUtil.log(Log.DEBUG, "fota", "stream length:  " + uConnection.getContentLength());
				outsteam = new FileOutputStream(savefile, true);

				LogUtil.log(Log.DEBUG, "fota", "totalsize is:" + apkModel.getApkTotalSize());

				byte[] buff = new byte[1024];

				int len = 0;

				OtaConstant.status = true;

				while ((len = instream.read(buff)) != -1 && OtaConstant.status) {
					outsteam.write(buff, 0, len);
					downsize += len;
				}

				outsteam.flush();
				//当文件不存在或者小于文件总大小时
			} else if (exitfilelength == apkModel.getApkTotalSize()) {
				LogUtil.log(LogUtil.INFO, "fota", "apk downlad aleady over!!!");
				
				// 下载出错，文件大于文件总大小，return
			} else {
				LogUtil.log(LogUtil.INFO, "fota", "apk downlad error ,delete file !!!");
				File file = new File(OtaConstant.OTA_APK_PATH + apkModel.getApkFileName());
				file.delete();
				return ;
			}

			// 下载完成
			ReportApkTask report = new ReportApkTask(context, apkModel);
			if (downsize == apkModel.getApkTotalSize()) {
				LogUtil.log(LogUtil.INFO, "fota", "apk download finish");
				apkModel.setApkStatus(OtaConstant.STATUS_APK_DOWNLOAD_SUC);

				LogUtil.log(LogUtil.INFO, "fota", "md5 error :" + "save file111 md5 :" + FileMd5.calculateMD5(savefile)
						+ "==== md5 :" + apkModel.getApkMd5());

				if (FileMd5.calculateMD5(savefile).equalsIgnoreCase(apkModel.getApkMd5())) {
					apkModel.setApkStatus(OtaConstant.STATUS_APK_CHECK_SUC);

					String result = SelfUpdate.installApk(context, OtaConstant.OTA_APK_PATH + apkModel.getApkFileName(),
							apkModel);

					LogUtil.log(LogUtil.INFO, "fota", "pm install result :" + result);
					if (result.equalsIgnoreCase("fail")) {
						apkModel.setApkStatus(OtaConstant.STATUS_APK_INSTALL_FAIL);
						ApkDao.saveApkModel(apkModel, context);
						ApkDao.dropApkInfoByKey(apkModel.getApkId(), context);
						FileUtil.deleteFile(OtaConstant.OTA_APK_PATH + apkModel.getApkFileName());
						report.run();
					} else {
						apkModel.setApkStatus(OtaConstant.STATUS_APK_INSTALL_SUC);
						ApkDao.saveApkModel(apkModel, context);
						FileUtil.deleteFile(OtaConstant.OTA_APK_PATH + apkModel.getApkFileName());
						report.run();
					}
				}
			} else {
				report.run();
				LogUtil.log(LogUtil.INFO, "fota", "md5 error :" + "save file md5 :" + FileMd5.calculateMD5(savefile)
						+ "==== md5 :" + apkModel.getApkMd5());
			}
			
		}

		catch (Exception e) {
			LogUtil.log(Log.DEBUG, "download apk ", "Message:" + e.getMessage());
			Log.d("fota", "download exception: " + e.toString() + "\nerror message: " + e.getMessage());
			e.printStackTrace();
			new OtaAlarmService(context).setAlarm(OtaConstant.OTA_APK_INSTALL_ALARM, OtaConstant.OTA_CYCLE_APK_ALARM);

		} finally {
			try {
				if (instream != null)
					instream.close();
				if (outsteam != null)
					outsteam.close();
				new OtaAlarmService(context).setAlarm(OtaConstant.OTA_CYCLE_APK_TIME, OtaConstant.OTA_CYCLE_APK_ALARM);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		downloadApk(apkModel);

	}

}
