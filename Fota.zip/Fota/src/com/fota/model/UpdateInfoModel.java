package com.fota.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fota.dao.OtaDbUtil;
import com.fota.dao.UpdateInfoDao;

import android.content.Context;

public class UpdateInfoModel {

	private String infoContext;
	private int infoFwId;
	private int infoId;

	public String getInfoContext() {
		return infoContext;
	}

	public void setInfoContext(String infoContext) {
		this.infoContext = infoContext;
	}

	public int getInfoFwId() {
		return infoFwId;
	}

	public void setInfoFwId(int infoFwId) {
		this.infoFwId = infoFwId;
	}

	public int getInfoId() {
		return infoId;
	}

	public void setInfoId(int infoId) {
		this.infoId = infoId;
	}

	public static List<UpdateInfoModel> parseJson(JSONArray jsonArray) {
		List<UpdateInfoModel> infoList = new ArrayList<UpdateInfoModel>();
		if (jsonArray != null & jsonArray.length() != 0) {
			for (int i = 0; i < jsonArray.length(); i++) {
				UpdateInfoModel infoModel=new UpdateInfoModel();
				JSONObject infoJson=jsonArray.optJSONObject(i);
				infoModel.setInfoContext(infoJson.optString("info_context"));
				infoModel.setInfoFwId(infoJson.optInt("info_fw_id"));
				infoModel.setInfoId(infoJson.optInt("info_id"));
				infoList.add(infoModel);
			}
		}else{
			infoList=null;
		}
		return infoList;

	}
	
	public static String getInfoString(Context context,int fwId){
		List<UpdateInfoModel> updateInfo=UpdateInfoDao.getInfoList(context);
		StringBuffer strBuff=new StringBuffer();
		if(updateInfo!=null){
			for(int i=1;i<updateInfo.size()+1;i++){
				UpdateInfoModel updateInfoModel=updateInfo.get(i-1);
				strBuff.append(i+". "+updateInfoModel.getInfoContext()+"\n");
			}
		}
		
		
		return strBuff.toString();
	}

	@Override
	public String toString() {
		return "UpdateInfoModel [infoContext=" + infoContext + ", infoFwId=" + infoFwId + ", infoId=" + infoId + "]";
	}

}
