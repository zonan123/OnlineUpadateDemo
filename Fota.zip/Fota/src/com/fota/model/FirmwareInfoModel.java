package com.fota.model;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.fota.util.LogUtil;

public class FirmwareInfoModel {

	private int fwInfoId;
	private int fwID;
	private String fwInfoContext;

	@Override
	public String toString() {
		return "FirmwareInfoModel [fwInfoId=" + fwInfoId + ", fwID=" + fwID + ", fwInfoContext=" + fwInfoContext + "]";
	}

	public int getFwInfoId() {
		return fwInfoId;
	}

	public void setFwInfoId(int fwInfoId) {
		this.fwInfoId = fwInfoId;
	}

	public int getFwID() {
		return fwID;
	}

	public void setFwID(int fwID) {
		this.fwID = fwID;
	}

	public String getFwInfoContext() {
		return fwInfoContext;
	}

	public void setFwInfoContext(String fwInfoContext) {
		this.fwInfoContext = fwInfoContext;
	}

	public static List<FirmwareInfoModel> parseJson(JSONArray jsonArray) {
		List<FirmwareInfoModel> infoList = new ArrayList<FirmwareInfoModel>();
		
		LogUtil.log(LogUtil.INFO, "fota", "into convert update json :"+jsonArray.length());
		
		if (jsonArray != null && jsonArray.length() > 0) {
			for (int i = 0; i < jsonArray.length(); i++) {
				FirmwareInfoModel infoModel = new FirmwareInfoModel();
				JSONObject jsonObject;
				try {
					jsonObject = jsonArray.getJSONObject(i);
					infoModel.setFwID(jsonObject.optInt("info_fw_id"));
					infoModel.setFwInfoContext(jsonObject.optString("info_context"));
					infoModel.setFwInfoId(jsonObject.optInt("info_id"));
					infoList.add(infoModel);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			LogUtil.log(LogUtil.INFO, "fota", "info list :"+infoList.size());
		}

		return infoList;

	}

}
