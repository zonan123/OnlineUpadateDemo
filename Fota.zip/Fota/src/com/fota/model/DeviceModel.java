package com.fota.model;

import com.fota.sys.OtaConstant;
import com.fota.util.DeviceUtil;
import com.fota.util.OtaSharePreferenceUtil;
import com.fota.R;

import android.content.Context;
import android.os.Build;
import android.widget.Toast;

public class DeviceModel {
    
    private String UUID;   //唯一主键ID
    private String deviceModel;     //设备型号
    private String systemVersion;   //系统版本
    private String manufacturer;   //制造厂商
    
    
    private String totalRunTime; // 系统总共运行时间
    private String fingerprint; // ginger 属性
    private String qudaoshang;   // 渠道号
    private String softVersion;   //apk版本
    private String sdkVersion; //系统版本
    private String brand;   // 商标属性
    private String registerTime;  // 注册时间
    
    private String allPkg;  //预装第三方应用列表
    
    
    
	public String getAllPkg() {
		return allPkg;
	}
	public void setAllPkg(String allPkg) {
		this.allPkg = allPkg;
	}
	public String getQudaoshang() {
		return qudaoshang;
	}
	public void setQudaoshang(String qudaoshang) {
		this.qudaoshang = qudaoshang;
	}
	public String getSoftVersion() {
		return softVersion;
	}
	public void setSoftVersion(String softVersion) {
		this.softVersion = softVersion;
	}
	public String getSdkVersion() {
		return sdkVersion;
	}
	public void setSdkVersion(String sdkVersion) {
		this.sdkVersion = sdkVersion;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getRegisterTime() {
		return registerTime;
	}
	public void setRegisterTime(String registerTime) {
		this.registerTime = registerTime;
	}
	public String getTotalRunTime() {
		return totalRunTime;
	}
	public void setTotalRunTime(String totalRunTime) {
		this.totalRunTime = totalRunTime;
	}
	public String getFingerprint() {
		return fingerprint;
	}
	public void setFingerprint(String fingerprint) {
		this.fingerprint = fingerprint;
	}
	public String getUUID() {
		return UUID;
	}
	public void setUUID(String uUID) {
		UUID = uUID;
	}
	public String getPkgList() {
		return pkgList;
	}
	public void setPkgList(String pkgList) {
		this.pkgList = pkgList;
	}
	private String pkgList;
    
   
    public String getDeviceModel() {
        return deviceModel;
    }
    public void setDeviceModel(String deviceModel) {
        this.deviceModel = deviceModel;
    }
    public String getSystemVersion() {
        return systemVersion;
    }
    public void setSystemVersion(String systemVersion) {
        this.systemVersion = systemVersion;
    }
    public String getManufacturer() {
        return manufacturer;
    }
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }
    
    
    
    @Override
   	public String toString() {
   		return "DeviceModel [clientID=" + UUID + ", deviceModel=" + deviceModel + ", systemVersion=" + systemVersion
   				+ ", manufacturer=" + manufacturer + ", totalRunTime=" + totalRunTime + ", fingerprint=" + fingerprint
   				+ ", qudaoshang=" + qudaoshang + ", softVersion=" + softVersion + ", sdkVersion=" + sdkVersion
   				+ ", brand=" + brand + ", registerTime=" + registerTime + ", pkgList=" + pkgList + "]";
   	}
    
    

}
