package com.fota.ui;

import java.util.RandomAccess;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.fota.sys.OtaConstant;
import com.fota.util.LogUtil;
import com.fota.util.OtaAlarmService;
import com.fota.util.OtaSharePreferenceUtil;
import com.fota.R;

public class UpdateSetting extends Activity {
	
	private  Dialog myDialog;
	
	private CheckBox accessCheckBox;
	
	private CheckBox wifiCheckBox;
	
	private TableRow accessRow;
	
	private TableRow wifiRow;
	
	private TableRow timeRow;
	
	private RelativeLayout timeRelativeLayout;
	
	private Context context;
	
	private TextView  frequency;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.updatesetting3);
		
		context = getApplicationContext();
		
		accessCheckBox = (CheckBox)findViewById(R.id.checkbox1);
		
		wifiCheckBox = (CheckBox)findViewById(R.id.checkbox2);
		
		accessRow = (TableRow)findViewById(R.id.row1);
		
		wifiRow = (TableRow)findViewById(R.id.row2);
		
		timeRow = (TableRow)findViewById(R.id.row3);
		
		timeRelativeLayout = (RelativeLayout)findViewById(R.id.relay3);
		
		accessRow.setOnClickListener(new MyClick());
		
		wifiRow.setOnClickListener(new MyClick());
		
		accessCheckBox.setOnClickListener(new MyClick());
		
		wifiCheckBox.setOnClickListener(new MyClick());
		
		timeRow.setOnClickListener(new MyClick());
		
		timeRelativeLayout.setOnClickListener(new MyClick());
		
		frequency = (TextView)findViewById(R.id.titile3);
		
		initCheckbox();
		
		
	}

	public void initCheckbox()
	{
		if (OtaSharePreferenceUtil.getBooleanValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, OtaConstant.ALLOW_ACCESS_AUTO, false)) 
		{
			accessCheckBox.setChecked(true);
//			timeRow.setBackgroundColor(getResources().getColor(R.color.layoutdeselect));
			frequency.setTextColor(getResources().getColor(R.color.textcolor));
		}
		else
		{
			frequency.setTextColor(getResources().getColor(R.color.black));
		}
		if (OtaSharePreferenceUtil.getBooleanValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, OtaConstant.WIFI_ONLY, false))
		{
			wifiCheckBox.setChecked(true);
		}
	}

	
	//diaolog中直接使用布局，不使用listview
	public void showDialog()
	{
//		final Dialog myDialog = new Dialog(MainActivity.this);
		myDialog = new Dialog(UpdateSetting.this);
		myDialog.setContentView(R.layout.dialog);
		
		myDialog.setTitle(R.string.frequency_setting_title);
		
		myDialog.setCancelable(false);
		
		CheckBox check1 = (CheckBox) myDialog.findViewById(R.id.listcheck1);
		
		CheckBox check2 = (CheckBox)myDialog.findViewById(R.id.listcheck2);
		
		CheckBox check3 = (CheckBox)myDialog.findViewById(R.id.listcheck3);
		
		Button cancle = (Button)myDialog.findViewById(R.id.canclebutton);
		
		cancle.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				myDialog.dismiss();
			}
		});
		
		check1.setOnClickListener(new MyClick());
		
		check2.setOnClickListener(new MyClick());
		
		check3.setOnClickListener(new MyClick());
		
		int index = OtaSharePreferenceUtil.getIntValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, OtaConstant.DIALOG_CHECKBOX_INDEX, 2);
		
		switch (index) {
		case 1:
			check1.setChecked(true);
			break;
		case 2:
			check2.setChecked(true);
			break;
		case 3:
			check3.setChecked(true);
			break;
		default:
			break;
		}
		
		myDialog.show();
	}
	
	public void setAarm(int index)
	{
		long currentmill = System.currentTimeMillis();
		
		long daymill = 1000*60*60*24;  //1000*60*60*24 = 86400000
		
		switch (index) 
		{
		case 1:
			new OtaAlarmService(context).setAlarm( daymill*3,OtaConstant.OTA_CYCLE_VISIT_ALARM);
			OtaSharePreferenceUtil.saveLongValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.NEXT_VISIT, currentmill + daymill*1);
			break;
		case 2:
			new OtaAlarmService(context).setAlarm( daymill*7,OtaConstant.OTA_CYCLE_VISIT_ALARM);
			OtaSharePreferenceUtil.saveLongValue(context, OtaConstant.OTA_SP_INFO,OtaConstant.NEXT_VISIT, currentmill + daymill*7);
			break;
		case 3:
			new OtaAlarmService(context).setAlarm( daymill*10,OtaConstant.OTA_CYCLE_VISIT_ALARM);
			OtaSharePreferenceUtil.saveLongValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.NEXT_VISIT, currentmill + daymill*15);
			break;
			
		default:
			break;
		}
		LogUtil.log(Log.DEBUG, "UpdateSetting setAarm", "访问频率改变");
		Log.d("fota", "UpdateSetting setAarm index :" + index);
	}
	
	class MyClick implements OnClickListener
	{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub

			String name = v.toString().substring(v.toString().lastIndexOf("/")+1, v.toString().length()-1);
			if(name.equals("listcheck1"))
			{
				
				OtaSharePreferenceUtil.saveIntValue(getApplicationContext(), OtaConstant.OTA_SP_INFO,OtaConstant.DIALOG_CHECKBOX_INDEX, 1);
				setAarm(1);
				myDialog.dismiss();
			}
			else if (name.equals("listcheck2")) 
			{
				OtaSharePreferenceUtil.saveIntValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, OtaConstant.DIALOG_CHECKBOX_INDEX, 2);
				setAarm(2);
				myDialog.dismiss();
			}
			else if (name.equals("listcheck3")) 
			{
				OtaSharePreferenceUtil.saveIntValue(getApplicationContext(), OtaConstant.OTA_SP_INFO,OtaConstant.DIALOG_CHECKBOX_INDEX, 3);
				setAarm(3);
				myDialog.dismiss();
			}
			else if (name.equals("checkbox1"))
			{
				Log.d("fota", "auto access");
				if (accessCheckBox.isChecked()) 
				{
					Log.d("fota", "auto access checked");
					OtaSharePreferenceUtil.saveBooleanValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, OtaConstant.ALLOW_ACCESS_AUTO, true);
					
//					timeRow.setBackgroundColor(getResources().getColor(R.color.layoutdeselect));
					frequency.setTextColor(getResources().getColor(R.color.textcolor));
				}else
				{
					Log.d("fota", "auto access un  checked");
					OtaSharePreferenceUtil.saveBooleanValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, OtaConstant.ALLOW_ACCESS_AUTO, false);
					
//					timeRow.setBackgroundColor(getApplicationContext().getResources().getColor(R.color.linedisable));
					frequency.setTextColor(getResources().getColor(R.color.black));
				}
			}
			else if (name.equals("row1"))
			{
				Log.d("fota", "row1 ");
				if (accessCheckBox.isChecked()) 
				{
					accessCheckBox.setChecked(false);
					
					OtaSharePreferenceUtil.saveBooleanValue(getApplicationContext(), OtaConstant.OTA_SP_INFO,OtaConstant.ALLOW_ACCESS_AUTO, false);
					
//					timeRow.setBackgroundColor(getApplicationContext().getResources().getColor(R.color.linedisable));
					frequency.setTextColor(getResources().getColor(R.color.black));
				}
				else
				{
					accessCheckBox.setChecked(true);
					
					OtaSharePreferenceUtil.saveBooleanValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, OtaConstant.ALLOW_ACCESS_AUTO, true);
					
//					timeRow.setBackgroundColor(getResources().getColor(R.color.layoutdeselect));
					frequency.setTextColor(getResources().getColor(R.color.textcolor));
				}
			}
			else if (name.equals("checkbox2"))
			{
				Log.d("fota", "wifi only");
				if (wifiCheckBox.isChecked())
				{
					Log.d("fota", "wifi access checked");
					OtaSharePreferenceUtil.saveBooleanValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, OtaConstant.WIFI_ONLY, true);
				}else
				{
					Log.d("fota", "wifi access un checked");
					OtaSharePreferenceUtil.saveBooleanValue(getApplicationContext(), OtaConstant.OTA_SP_INFO,OtaConstant.WIFI_ONLY, false);
				}
			}
			else if (name.equals("row2")) 
			{
				Log.d("fota", "row2");
				if (wifiCheckBox.isChecked()) 
				{
					wifiCheckBox.setChecked(false);
					
					OtaSharePreferenceUtil.saveBooleanValue(getApplicationContext(), OtaConstant.OTA_SP_INFO,OtaConstant.WIFI_ONLY, false);
				}else
				{
					wifiCheckBox.setChecked(true);
					
					OtaSharePreferenceUtil.saveBooleanValue(getApplicationContext(), OtaConstant.OTA_SP_INFO,OtaConstant.WIFI_ONLY, true);
				}
			}
			else if (name.equals("row3")||name.equals("relay3")) 
			{
				if (OtaSharePreferenceUtil.getBooleanValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, OtaConstant.ALLOW_ACCESS_AUTO, false)) 
				{
					showDialog();
				}
			}
			
		}
		
	}
	
	
}
