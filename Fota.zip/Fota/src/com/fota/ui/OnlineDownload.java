package com.fota.ui;

import java.io.File;
import java.net.URLEncoder;
import java.util.List;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.Dialog;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.WifiLock;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.fota.dao.TaskStatusDao;
import com.fota.model.MissionModel;
import com.fota.model.UpdateInfoModel;
import com.fota.service.OtaNotification;
import com.fota.sys.Constant;
import com.fota.sys.OtaConstant;
import com.fota.util.DeviceUtil;
import com.fota.util.FileMd5;
import com.fota.util.InstallPackage;
import com.fota.util.LogUtil;
import com.fota.util.OtaDownloadOperation;
import com.fota.util.OtaSharePreferenceUtil;
import com.fota.util.ProgressWheel;
import com.fota.util.ServiceUtil;
import com.fota.util.StringUtil;
import com.fota.R;

public class OnlineDownload extends Activity
{
	private Button download;
	
	private Button cancle;
	
	private ProgressWheel progressWheel;

	private String downloarurl=null;
									
	private String filemd5 = null;
	
	private String filename = null;
	
	private  int clicknum = 0;
	
	private int updateway = 0;
	
	private Context context;
	
	private MissionModel model;
	
	private TaskStatusDao  reportStatus;
	
	private PowerManager pwManager = null;
	
	private WakeLock lock = null;
	
	private WifiManager wifiManager = null;
	
	private WifiLock wifiLock = null;
	
	private boolean checkmd5 = false;
	
	private boolean back = false;
	
	private  int percent = 0;
	
	private long totalsize = 0;
	
	private Handler downloadHandler = new Handler()
	{
		public void handleMessage(android.os.Message msg) 
		{
			switch (msg.what) 
			{
			case 0:
				LogUtil.log(Log.DEBUG,"fota", "msg.what 0");
				File existFile= new File(OtaConstant.getCache(getApplicationContext()));
				
				int times = OtaSharePreferenceUtil.getIntValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.GET_CATCH_TIMES, 0);
				
				boolean isconnect = ServiceUtil.isConnectingToInternet(context);
				
				if(existFile.length()!=OtaSharePreferenceUtil.getLongValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.TOTAL_SIZE, 0)
						&&times<=20)
				{
					LogUtil.log(Log.DEBUG,"fota", "download not success go on");
					
					Thread secondThread = new Thread(new Runnable() {
						@Override
						public void run() {
							
							OtaConstant.status = false;
							
							try 
							{
								Thread.sleep(5000);
							} catch (Exception e) 
							{
								// TODO: handle exception
							}
							int times = OtaSharePreferenceUtil.getIntValue(context, OtaConstant.OTA_SP_INFO,OtaConstant.GET_CATCH_TIMES, 0);
							
							OtaSharePreferenceUtil.saveIntValue(context,OtaConstant.OTA_SP_INFO,OtaConstant.GET_CATCH_TIMES, times + 1);
							
							Thread downloadThread = new Thread(new OtaDownloadOperation(downloarurl,OtaConstant.getCache(getApplicationContext()),downloadHandler, totalsize));

							downloadThread.start();

						}
					});
					secondThread.start();
					
				}
				else
				{
					progressWheel.setText(context.getResources().getString(R.string.ota_noti_neterror));
					
					LogUtil.log(Log.DEBUG,"fota", "download fail");
					
					download.setClickable(true);
					
					OtaSharePreferenceUtil.saveIntValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.GET_CATCH_TIMES, 0);
					
					TaskStatusDao reportStatus2 = new TaskStatusDao(getApplicationContext());
					
					int taskid = reportStatus2.getTaskId(OtaConstant.FIRMWARM_TASK, OtaConstant.TASK_STATUS_TASK_BEGIN);
					
					if(taskid == 0)
					{
						reportStatus2.TaskStatusBegin(OtaConstant.FIRMWARM_TASK, OtaConstant.TASK_STATUS_TASK_BEGIN);
						
						taskid = reportStatus2.getTaskId(OtaConstant.FIRMWARM_TASK, OtaConstant.TASK_STATUS_TASK_BEGIN);
					}
					
					reportStatus2.UpdateStatus(OtaConstant.TASK_STATUS_DOWNLOAD_FAIL, taskid);
					
					reportStatus2.UpdateFinish(taskid);
					
//					deletetempFile(filename);
					
					reportStatus2.reportServer(taskid);
					
					download.setClickable(true);
					
				}     
				break;
				
			case  1:
				if (msg.arg1 < 100) 
				{
					LogUtil.log(Log.DEBUG,"fota", "download: " + msg.arg1 + "  progress:" + percent);
					
					progressWheel.setProgress(msg.arg1);
					
					progressWheel.setText(msg.arg1 + "%" + "\n" + msg.obj.toString());
						
					percent = msg.arg1;
					
				}else
				{
					// 下载成功
					TaskStatusDao repoStatus = new TaskStatusDao(getApplicationContext());
					
					int taskid2 = repoStatus.getTaskId(OtaConstant.FIRMWARM_TASK, OtaConstant.TASK_STATUS_TASK_BEGIN);
					
					repoStatus.UpdateStatus(OtaConstant.TASK_STATUS_DOWNLOAD_SUC,taskid2);
					
					OtaSharePreferenceUtil.saveIntValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.GET_CATCH_TIMES, 0);
					
					OtaConstant.status = false;
					
					checkMd5();
					LogUtil.log(Log.DEBUG,"fota", "firmware download success");
				}
				break;
			case 2:
				checkNotification();
				
				progressWheel.setProgress(360);
				
				progressWheel.setText(getApplicationContext().getResources().getString(R.string.download_complete));
				
				download.setClickable(true);
				
				download.setText(R.string.update_now);
				
				cancle.setText(R.string.cancle);
				
				OtaConstant.status = false;
				
				clicknum += 1;
				break;
				
			default:
				break;
			}
		};
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.onlinedowanload);
		
		context = getApplicationContext();
		
		//07-02添加
		initContent();
		
		//初始化数据
		reportStatus = new TaskStatusDao(context);
		
		model = reportStatus.getModel();
		
		filemd5 = model.getFilemd5();
		
		totalsize = model.getTotalsize();
		
		filename = model.getFirwname();

		OtaSharePreferenceUtil.saveStringValue(context, OtaConstant.OTA_SP_INFO,OtaConstant.UPDATE_FILE_NAME, filename);
		
		OtaSharePreferenceUtil.saveLongValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.TOTAL_SIZE, totalsize);
		
		//开始一个任务状态
		int taskid = reportStatus.getTaskId(OtaConstant.FIRMWARM_TASK, OtaConstant.TASK_STATUS_TASK_BEGIN);
	
		if(taskid == 0)
		{
			reportStatus.TaskStatusBegin(OtaConstant.FIRMWARM_TASK, OtaConstant.TASK_STATUS_TASK_BEGIN);
		}

		String uuid = OtaSharePreferenceUtil.getStringValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID, "");
    	
    	if(StringUtil.isNullOrEmpty(uuid))
    	{
    		uuid = DeviceUtil.getDeviceId(context);
    		
    		
    		OtaSharePreferenceUtil.saveStringValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID, uuid);
    		
    	}
		//06-25修改 url里的参数的格式为utf-8
//		downloarurl = model.getFirmurl()+"?fwFileName="+model.getFirwname()+"&UUID="+uuid;
//
//		if(StringUtil.isNullOrEmpty(model.getFirmurl()))
//		{
//			String headurl = OtaSharePreferenceUtil.getStringValue(context, OtaConstant.LAST_URL, "");
//			
//			if(StringUtil.isNullOrEmpty(headurl))
//			{
//				downloarurl = OtaConstant.OTA_YUMIN + OtaConstant.OTA_FIRMWARE_URL+"?fwFileName="+model.getFirwname()+"&UUID="+uuid;
//			}
//			else
//			{
//				downloarurl = headurl + OtaConstant.OTA_FIRMWARE_URL+"?fwFileName="+model.getFirwname()+"&UUID="+uuid;
//			}
//		}
    	
    	try{
    		downloarurl = model.getFirmurl()+"?fwFileName="+URLEncoder.encode(model.getFirwname(),"UTF-8")+"&UUID="+URLEncoder.encode(uuid,"UTF-8");
//    		downloarurl = OtaConstant.OTA_DOWNLOAD_BASE+"?filename="+URLEncoder.encode(model.getFirwname(),"UTF-8")+"&UUID="+URLEncoder.encode(uuid,"UTF-8");

    		if(StringUtil.isNullOrEmpty(model.getFirmurl()))
    		{
    			String headurl = OtaSharePreferenceUtil.getStringValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.LAST_URL, "");
    		}
    		
    	}catch (Exception e) {
    		
    	}
    	
		LogUtil.log(Log.DEBUG,"fota", "OnlineDownload downloadurl is:" + downloarurl+"\n"+"totalsize:   " + totalsize);
		
		download = (Button)findViewById(R.id.download);
		
		cancle = (Button)findViewById(R.id.cancle);
		
		progressWheel = (ProgressWheel)findViewById(R.id.progress);
		
		progressWheel.setText(percent + "%");

		download.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				download.setClickable(false);
				LogUtil.log(Log.DEBUG,"fota", "download click,the clicknum is:" + clicknum);
				
				if(clicknum == 0)
				{
					progressWheel.setText(percent + "%");
					
					OtaConstant.status = false;
					
					OtaDownloadOperation otaOperation = new OtaDownloadOperation(downloarurl, OtaConstant.getCache(getApplicationContext()), downloadHandler,totalsize);

					Thread downloadThread = new Thread(otaOperation);
					
					downloadThread.start();
					
					cancle.setText(R.string.pause);
				}
				else
				{
					goUpdate();
				}
			}
		});
		
		cancle.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				LogUtil.log(Log.DEBUG,"fota", "cancle click,the clicknum is:" + clicknum + "  status:" + OtaConstant.status);
				if(clicknum == 0&&OtaConstant.status==true)
				{
					//暂停下载
					OtaConstant.status = false;
					
					download.setClickable(true);
					
					cancle.setText(R.string.negative_button);

					download.setClickable(true);
					
					progressWheel.setText(percent + "%" + "\n" + "0KB/s");
					LogUtil.log(Log.DEBUG,"fota", "pause download file size: " + new File(OtaConstant.getCache(getApplicationContext())).length());
				}
				else
				{
					finish();
				}
			}
		});
		checkUpdatePackage();
		
		pwManager = (PowerManager) getSystemService(Service.POWER_SERVICE);
		
		lock = pwManager.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK|PowerManager.ON_AFTER_RELEASE, "xfota");
		
		wifiManager = (WifiManager) getSystemService(Service.WIFI_SERVICE);
		
		wifiLock = wifiManager.createWifiLock("fota");
		
		wifiLock.acquire();
		
		lock.acquire();
	}
	//07-02添加
	private TextView updateInfo;
	private void initContent() {
		updateInfo= (TextView) findViewById(R.id.updateInfo);
		String info = UpdateInfoModel.getInfoString(context, OtaSharePreferenceUtil.getIntValue(context, OtaConstant.OTA_SP_FW,"fw_id", 0));
		LogUtil.log(LogUtil.INFO, "fota", "update info :"+info);
		updateInfo.setText(info);
	}
	

	public void checkMd5()
	{
		Thread checkThread = new Thread(new Runnable() {
			
			@Override
			public void run() 
			{
				checkmd5 = FileMd5.checkMD5(filemd5, new File(OtaConstant.getCache(getApplicationContext())));//OtaConstant.OTA_FW_PATH));
				
				if(checkmd5)
				{
					TaskStatusDao  reStatus = new TaskStatusDao(context);
					
					int taskid = reStatus.getTaskId(OtaConstant.FIRMWARM_TASK, OtaConstant.TASK_STATUS_DOWNLOAD_SUC);
					
					reStatus.UpdateStatus(OtaConstant.TASK_STATUS_CHECK_SUC, taskid);
				}
				
				Message msg = Message.obtain();
				
				msg.what = 2;
				
				downloadHandler.sendMessage(msg);
			}
		});
		checkThread.start();
	}
	
	public void checkUpdatePackage()
	{
		File  updateFile = new File(OtaConstant.getCache(getApplicationContext()));
		LogUtil.log(Log.DEBUG,"fota", "checkUpdataPackagte");
		if(!updateFile.exists())
		{
			progressWheel.setText("0%");
			
			download.setText(R.string.download);
			
			download.setClickable(true);
			
			cancle.setText(R.string.pause);
			
			return;
		}
		
		long size = OtaSharePreferenceUtil.getLongValue(context, OtaConstant.OTA_SP_INFO,OtaConstant.TOTAL_SIZE, 0);
		
		if(updateFile.length() == size && size!=0)
		{
			progressWheel.setProgress(360); 
			
			progressWheel.setText(getApplicationContext().getResources().getString(R.string.download_complete));
			
			clicknum = 1;
			
			download.setText(R.string.update_now);
			
			cancle.setText(R.string.cancle);
			
			OtaConstant.status = false;
			
			back = true;
		}
		//08-28添加
		if(updateFile.length() > size && size!=0)
		{
			updateFile.delete();
				
			progressWheel.setText("0%");
			
			download.setText(R.string.download);
			
			download.setClickable(true);
			
			cancle.setText(R.string.pause);
		}
	}
	
	public void checkNotification()
	{
		ActivityManager am = (ActivityManager) getSystemService(Service.ACTIVITY_SERVICE);
		
		List<RunningTaskInfo> tasks = am.getRunningTasks(1);
		
		if(!tasks.isEmpty())
		{
			ComponentName cmp = tasks.get(0).topActivity;
			
			if(!cmp.getClassName().equals("com.fota.ui.OnlineDownload"))
			{
				OtaNotification noti = new OtaNotification(context);
				
				noti.setOndown(true);
				
				noti.sendNotification();
			}
		}
	}

	public void updateRed()
	{
		LogUtil.log(Log.DEBUG,"fota", "update redbend");
		final File updatefile = new File(OtaConstant.getCache(getApplicationContext()));
		
		String servermd5 = OtaSharePreferenceUtil.getStringValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.OTA_FW_MD4, "");
		
		boolean check = FileMd5.checkMD5(filemd5,updatefile);
		
		if (check)
		{
			final Dialog updateDialog = new Dialog(this);
			
			updateDialog.setContentView(R.layout.confirmdialog);
    		
			updateDialog.setTitle(R.string.update_title);
    		
			TextView message = (TextView) updateDialog.findViewById(R.id.confirm_message);
			
			message.setText(R.string.update_message);
			
    		Button update = (Button)updateDialog.findViewById(R.id.confir_download);
    		
    		update.setText(R.string.confirm_update);
    		
    		Button cancle = (Button)updateDialog.findViewById(R.id.cancle_download);
    		
    		cancle.setText(R.string.confirm_cancel);
    		
    		download.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
					
					pm.reboot("recovery");
					
				}
			});
    		
    		cancle.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					updateDialog.dismiss();
				}
			});
    		updateDialog.setCancelable(false);
    		
    		updateDialog.show();
			
		}
		else
		{
			Toast.makeText(context, R.string.file_damage, Toast.LENGTH_LONG).show();
		}
		
	}
	
	public void updateAndroid()
	{

		if(checkmd5 || back)
		{
			LogUtil.log(Log.DEBUG,"fota", "md5 check success");
			 final Dialog dlg = new Dialog(this,R.style.MyDialog);
			 
			 dlg.setCanceledOnTouchOutside(false);
	         LayoutInflater inflater = LayoutInflater.from(this);
	         
	         InstallPackage dlgView = (InstallPackage) inflater.inflate(R.layout.install_ota, null,false);
	         
	         dlgView.setPackagePath(OtaConstant.getCache(getApplicationContext()));
	         
	         dlg.setContentView(dlgView);
	         
	         dlg.findViewById(R.id.confirm_cancel).setOnClickListener(new View.OnClickListener()
	         {
	             @Override
	             public void onClick(View v) 
	             {
	            	//06-25
	             OtaSharePreferenceUtil.saveBooleanValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, "isCancle", true);
	                 dlg.dismiss();
	                 download.setClickable(true);
	             }
	         });
	         dlg.show();
		}
		else
		{   
			myCustomToast(R.string.file_damage);
			
			//升级包下载过程受损，校验md5失败
			TaskStatusDao report = new TaskStatusDao(context);
			
			int taskid = report.getTaskId(OtaConstant.FIRMWARM_TASK, OtaConstant.TASK_STATUS_DOWNLOAD_SUC);
			
			report.UpdateStatus(OtaConstant.TASK_STATUS_CHECK_FAIL,taskid);
			
			report.UpdateFinish(taskid);			
			
			report.reportServer(taskid);
			
			deletetempFile();
			
			clicknum = 0;
			
			download.setText(R.string.download);
			
			cancle.setText(R.string.cancle);
			
			download.setClickable(true);
		}
		
	}

	
	public void goUpdate()
	{
		if (updateway == 0) 
		{
			updateAndroid();
		}
		else
		{
			updateRed();
		}
	}
	
	public boolean testFileExist()
	{
		File file = new File(OtaConstant.getCache(getApplicationContext()));
		if(file.exists())
		{
			return true;
		}
		return false;
	}
	
	public void deletetempFile()
	{
		File file = new File(OtaConstant.getCache(getApplicationContext()));
		
		if (file.exists()) 
		{
			file.delete();
			LogUtil.log(Log.DEBUG,"fota", "delete temp file");
		}
		
	}
	
	public void myCustomToast(int id)
	{
		final Dialog mydialog = new Dialog(this);
		   
		mydialog.setTitle(R.string.noti_title);
		   
		mydialog.setContentView(R.layout.noticedailog);
		   
		TextView textView = (TextView)mydialog.findViewById(R.id.text);
		   
		Button button = (Button)mydialog.findViewById(R.id.button);
		   
		textView.setText(id);
		   
		button.setOnClickListener(new View.OnClickListener() {
			
	    @Override
	    public void onClick(View v) {
			// TODO Auto-generated method stub
			mydialog.dismiss();
		}
		});
		mydialog.show();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if(keyCode == KeyEvent.KEYCODE_BACK)
		{
//			OtaConstant.status = false;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	protected void onDestroy() 
	{
		super.onDestroy();
		
		LogUtil.log(Log.DEBUG, "fota", "delete the files");
		
//		FileUtil.deleteFile(OtaConstant.OTA_FW_PATH);
		
	}
	
	@Override
	protected void onPause()
	{
		// TODO Auto-generated method stub
		super.onPause();
		
		lock.release();
		
		wifiLock.release();
		LogUtil.log(Log.DEBUG,"fota", "release lock");
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
		checkUpdatePackage();
		
		lock.acquire();
		
		wifiLock.acquire();
		LogUtil.log(Log.DEBUG,"fota", "acquire lock");
	}
}
