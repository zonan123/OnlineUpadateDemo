package com.fota.ui;

import java.io.File;
import java.util.List;

import android.R.anim;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.app.Service;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.fota.dao.TaskStatusDao;
import com.fota.model.MissionModel;
import com.fota.service.OtaNotification;
import com.fota.service.SelfUpdate;
import com.fota.sys.OtaConstant;
import com.fota.util.InstallPackage;
import com.fota.util.LogUtil;
import com.fota.util.OtaServerOperation;
import com.fota.util.OtaSharePreferenceUtil;
import com.fota.util.ServiceUtil;
import com.fota.util.StringUtil;
import com.fota.R;

public class OtaMainActivity extends Activity {
    
	private Button checkButton;
	
	private Button menuButton;
	
	private TextView infoText;
	
	private ImageView searchView;
	
	private ImageView downloadnotice;
	
	private AnimationDrawable animation;
	private ValueAnimator valueAnimator;
	
	
	Handler myHandler = new Handler()
	{
		public void handleMessage(android.os.Message msg)
		{
			
			LogUtil.log(LogUtil.INFO, "fota", "msg what "+msg.what);
			switch (msg.what) 
			{
			//未联网，弹窗提示
			case OtaConstant.MSG_NET_ERROR:
				if(valueAnimator.isRunning())
				{
					valueAnimator.cancel();
				}
				searchView.setVisibility(View.GONE);
				noticeInfo(R.string.net_not_available);
				
				break;
			//没有可用更新，弹窗提示
			case OtaConstant.MSG_NO_UPDATE:
				
				if(valueAnimator.isRunning())
				{
					valueAnimator.end();
				}
				searchView.setVisibility(View.GONE);
				
				noticeInfo(R.string.no_available_update);
				
				//MissionModel model = (MissionModel) msg.obj;
				//LogUtil.log(LogUtil.INFO, "fota", "mission model :"+model.toString());
				
//				File updateFile = new File(OtaConstant.SDUPDATE_APK);
//				
//				boolean exist = updateFile.exists();
				
			//查看是否有自升级或者，开关push任务、
//				if(model!=null && !exist)
//				{
//					SelfUpdate selfUpdate = new SelfUpdate(getApplicationContext(), model,true,0);
//					
//					Thread selfthread = new Thread(selfUpdate);
//					
//					selfthread.start();
//				}
				break;
			//有可用更新，infotext显示可用新版本号，设置点击跳转
			case OtaConstant.MSG_UPDATE:
				
				if(valueAnimator.isRunning())
				{
					valueAnimator.end();
				}
				searchView.setVisibility(View.GONE);
				final MissionModel model2 = (MissionModel) msg.obj;
				
				final String newdisplay = model2.getNewdisplay();
				
				infoText.setText(R.string.avalible_update);
	    		
	    		infoText.append(newdisplay);
	    		
	    		downloadnotice.setVisibility(View.VISIBLE);
	    		
	    		new TaskStatusDao(getApplicationContext()).saveModel(model2);
				
	    		downloadnotice.setOnClickListener(new View.OnClickListener() {
	    			
	    			@Override
	    			public void onClick(View v) {
	    				// TODO Auto-generated method stub
	    				goDownload();
	    			}
	    		});
	    		
				infoText.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						if(!StringUtil.isNullOrEmpty(newdisplay));
						{
							goDownload();
						}
					}
				});
				
				break;
			default:
				break;
			}
		};
	};
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.otamainactivity);
        
        checkButton = (Button)findViewById(R.id.check);
        
		menuButton = (Button)findViewById(R.id.menu);
		
		infoText = (TextView)findViewById(R.id.builnumber);
		
		infoText.setText(R.string.no_update);
		
		infoText.append(android.os.Build.DISPLAY);
		
		searchView = (ImageView)findViewById(R.id.search);
		
		valueAnimator = getRotationZAnimator(searchView, 1500, -1);
		searchView.setVisibility(View.GONE);
		
		downloadnotice = (ImageView)findViewById(R.id.hand);
		
		InitView();
		
		OtaSharePreferenceUtil.saveStringValue(this, OtaConstant.OTA_SP_INFO,
					OtaConstant.CURRENT_DISPLAYID, Build.DISPLAY);
		
		checkButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {

				downloadnotice.setVisibility(View.GONE);
				
				searchView.setVisibility(View.VISIBLE);
				
				valueAnimator.start();
				
				OtaServerOperation otaServerOperation = new OtaServerOperation(getApplicationContext(), myHandler,OtaConstant.OTA_VISIT_Click);
				
				Thread visit = new Thread(otaServerOperation);
				
				visit.start();
			}
		});
		
		menuButton.setOnClickListener(new View.OnClickListener() {
			                                                          
			@Override
			public void onClick(View v) {
				menuItem();
			}
		});
		
		
		//测试时解除注释
//		infoText.setOnClickListener(new View.OnClickListener() {
//			
//			@Override
//			public void onClick(View v)
//			{
//				goDownload();
//			}
//		});
	
    }
    
    public ValueAnimator getRotationZAnimator(final View v ,int duration , int repeatCount){
        ValueAnimator valueAnim = ValueAnimator.ofFloat(360f,0f);
          LinearInterpolator lin = new LinearInterpolator();
          valueAnim.setInterpolator(lin);
          valueAnim.setDuration(duration);
          valueAnim.setRepeatCount(repeatCount);
          valueAnim.addUpdateListener(new AnimatorUpdateListener() {
              public void onAnimationUpdate(ValueAnimator value) {
                  float cVal = (Float)value.getAnimatedValue();
                  double radian = Math.toRadians(cVal);
                  double sin = Math.sin(radian) ;
                  double cos = Math.cos(radian) ;
                  float _tranX = (float) (sin * 20) ;
                  float _tranY = (float) (cos * 20) ;
                  v.setTranslationX(_tranX) ;
                  v.setTranslationY(_tranY) ;
              }
          });

          return valueAnim;
    }
    
    public void InitView()
    {
    	TaskStatusDao reportStatus = new TaskStatusDao(getApplicationContext());
    	
    	MissionModel model = reportStatus.getModel();
    	
    	String  display = model.getNewdisplay();
    	
    	if(!StringUtil.isNullOrEmpty(display)&&!display.equalsIgnoreCase(android.os.Build.DISPLAY))
    	{
    		infoText.setText(R.string.avalible_update);
    		
    		infoText.append(display);
    		
    		downloadnotice.setVisibility(View.VISIBLE);
    		
    		downloadnotice.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					goDownload();
				}
			});
    		
    		infoText.setOnClickListener(new View.OnClickListener() {
    			
    			@Override
    			public void onClick(View v)
    			{
    				goDownload();
    			}
    		});

    	}
    	else
    	{
    		infoText.setText(R.string.no_update);
    		
    		infoText.append(android.os.Build.DISPLAY);
		}
    	
    }
 
    public void menuItem()
    {	
    	final  Dialog  myDialog = new Dialog(this);
    	
    	myDialog.setContentView(R.layout.mydialog);
    	
    	myDialog.setTitle(R.string.menu_setting);
    	
    	Button local = (Button)myDialog.findViewById(R.id.local_menu);
    	
    	Button setting = (Button)myDialog.findViewById(R.id.setting_menu);
    	
    	local.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent0 = new Intent(getApplicationContext(),FileSelector.class);
				
				startActivityForResult(intent0, 0);
			}
		});
    	setting.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent1 = new Intent(getApplicationContext(),UpdateSetting.class);
				
				startActivity(intent1);
			}
		});
    	myDialog.show();
    }
    
    public void  goDownload()
    {
   
    	if (!ServiceUtil.getNetType(getApplicationContext()).equalsIgnoreCase("wifi")
    			&&OtaSharePreferenceUtil.getBooleanValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, OtaConstant.WIFI_ONLY, false))
    	{
    		final Dialog downloadDialog = new Dialog(this);
    		
    		downloadDialog.setContentView(R.layout.confirmdialog);
    		
    		downloadDialog.setTitle(R.string.download_confirm);
    		
    		Button download = (Button)downloadDialog.findViewById(R.id.confir_download);
    		
    		Button cancle = (Button)downloadDialog.findViewById(R.id.cancle_download);
    		
    		download.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent  intent = new Intent();
					//09-25  改为com.fota
					intent.setComponent(new ComponentName("com.fota", "com.fota.ui.OnlineDownload"));
			    	
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					
			    	startActivity(intent);
			    	
			    	downloadDialog.dismiss();
				}
			});
    		
    		cancle.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					downloadDialog.dismiss();
				}
			});
    		
    		downloadDialog.show();
			
		}
    	else
		{
			Intent intent = new Intent(this, OnlineDownload.class);
			
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			
			startActivity(intent);
		}		
    }
    
    
    public void noticeInfo(int res)
    {
    	final Dialog mydialog = new Dialog(this);
    	
    	mydialog.setContentView(R.layout.noticedailog);
    	
    	mydialog.setTitle(R.string.noti_title);
    	
    	TextView textView = (TextView)mydialog.findViewById(R.id.text);
    	
    	textView.setText(res);
    	
    	Button button = (Button)mydialog.findViewById(R.id.button);
    	
    	button.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mydialog.dismiss();
			}
		});
    	
    	ActivityManager am = (ActivityManager) getSystemService(Service.ACTIVITY_SERVICE);
		
		List<RunningTaskInfo> tasks = am.getRunningTasks(1);
		
		if(!tasks.isEmpty())
		{
			ComponentName cmp = tasks.get(0).topActivity;
			
			if(cmp.getClassName().equals("com.fota.ui.OtaMainActivity"))
			{
				mydialog.show();
			}
		}
    	
    }

    
    @Override
    protected void onDestroy() 
    {
    	super.onDestroy();
    	if(valueAnimator.isRunning())
		{	
			valueAnimator.cancel();
			LogUtil.log(Log.DEBUG,"fota", "stop the animation");
		}
    }
    
    @Override
    protected void onPause() 
    {
    	// TODO Auto-generated method stub
    	super.onPause();
    	if(valueAnimator.isRunning())
		{	
			valueAnimator.cancel();
			LogUtil.log(Log.DEBUG,"fota", "stop the animation");
		}
    	
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) 
    {
    	// TODO Auto-generated method stub
    	super.onActivityResult(requestCode, resultCode, data);
    	if (requestCode==0) 
		{
    		LogUtil.log(Log.DEBUG,"fota", "resultcode is:"+resultCode);
			if (data!=null) 
			{
				Bundle bundle = data.getExtras();
				
				String file = bundle.getString("file");
				
				LogUtil.log(Log.DEBUG,"fota", "string is:"+bundle.getString("file"));
				
				if (file != null) 
				{
		            final Dialog dlg = new Dialog(this,R.style.MyDialog);
		            
		            dlg.setCanceledOnTouchOutside(false);
		            LayoutInflater inflater = LayoutInflater.from(this);
		            
		            InstallPackage dlgView = (InstallPackage) inflater.inflate(R.layout.install_ota, null,
		                    false);
		            
		            dlgView.setPackagePath(file);
		            
		            dlg.setContentView(dlgView);
		            
		            dlg.findViewById(R.id.confirm_cancel).setOnClickListener(new View.OnClickListener() {
		                @Override
		                public void onClick(View v) {
		                	//05-19
		                	OtaSharePreferenceUtil.saveBooleanValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, "isCancle", true);
		                	
		                    dlg.dismiss();
		                }
		            });
		            
		            dlg.show();
		            //05-19 重新Dialog 的返回键
		            dlg.setOnKeyListener(new Dialog.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
						{
							if(keyCode == KeyEvent.KEYCODE_BACK){
								LogUtil.log(LogUtil.INFO, "OtaMainActivity", "KeyEvent.KEYCODE_BACK");
					        	OtaSharePreferenceUtil.saveBooleanValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, "isCancle", true);
							}
							
							return false;
						}
					});
		            
		        }
			}
		}
    }
}
