package com.fota.sys;

import android.content.Context;
import android.os.Environment;

public class OtaConstant {
	// 用于控制断点下载
	public static boolean status = false;
	// 默认轮询时间

	public static final String MODEL = "MODEL";

	public static final String BRAND = "BRAND";

	public static final String MANUFACTURER = "MANUFACTURER";

	public static final String DISPLAY = "DISPLAY";
	// 服务器可用新版本
	public static final String NEW_DISPLAYID = "NEW_DISPLAYID";
	// 当前版本
	public static final String CURRENT_DISPLAYID = "CURRENT_DISPLAYID";
	
	public static final String CACHE_FILE = "/cache/update.zip";
	// 自升级文件名
	public static final String APK_FILE_NAME = "APK_FILE_NAME";
	// 总大小
	public static final String TOTAL_SIZE = "TOTAL_SIZE";
	// 获取到的下载异常错误次数
	public static final String GET_CATCH_TIMES = "GET_CATCH_TIMES";
	// 下载过程中接收到异常的次数
	public static final String GET_FIRST_CATCH = "GET_FIRST_CATCH";
	// 升级包文件名
	public static final String UPDATE_FILE_NAME = "UPDATE_FILE_NAME";
	// 仅在wifi下下载
	public static final String WIFI_ONLY = "WIFI_ONLY";
	// 自升级下载次数
	public static final String DOWNLOAD_TIMES = "DOWNLOAD_TIMES";
	// 正在下载应用升级包
	public static final String IS_DOWNLOADING = "IS_DOWNLOADING";
	// 正在回传任务状态
	public static final String IS_REPORTING = "IS_REPORTING";
	// 当前应用版本号
	public static final String SOFT_VERSION = "SOFT_VERSION";
	// 自升级下载地址
	public static final String APK_URL = "APK_URL";
	// 允许自动检查更新
	public static final String ALLOW_ACCESS_AUTO = "ALLOW_ACCESS_AUTO";
	// 设置更新频率的索引
	public static final String DIALOG_CHECKBOX_INDEX = "DIALOG_CHECKBOX_INDEX";
	// 控制textinfo是否可跳转到下载界面
	public static final String TEXT_JUMP = "TEXT_JUMP";
	// 访问服务器标志位
	public static final String ALLOW_VISIT = "ALLOW_VISIT";
	// 正在访问
	public static final String IS_VISITING = "IS_VISITING";
	// 已经初始化过
	public static final String HAVE_INIT = "HAVE_INIT";
	// 唯一ID
	public static final String DEVICE_ID = "DEVICE_ID";
	// 没有网络
	public static final int MSG_NET_ERROR = 1;
	// 没有可用更新
	public static final int MSG_NO_UPDATE = 2;
	// 有可用更新
	public static final int MSG_UPDATE = 3;
	// 上次访问可用地址
	public static final String LAST_URL = "LAST_URL";
	

	// 本地存储的任务描述和状态
	public static final String SP_TASK_DESCRIPTION = "SP_TASK_DESCRIPTION";
	public static final String SP_TASK_STATUS = "SP_TASK_STATUS";
	// 任务状态
	public static final int TASK_STATUS_TASK_BEGIN = 12;
	public static final int TASK_STATUS_DOWNLOAD_SUC = 1; // 下载成功
	public static final int TASK_STATUS_DOWNLOAD_FAIL = 2; // 下载失败
	public static final int TASK_STATUS_CHECK_SUC = 3; // md5 校验成功
	public static final int TASK_STATUS_CHECK_FAIL = 4; // md 校验失败
	public static final int TASK_STATUS_SIGCHECK_FAIL_FILE_NOT_EXIT = 5;
	public static final int TASK_STATUS_SIGCHECK_FAIL_INVALID_UPGRADE_PACKAGE = 6;
	public static final int TASK_STATUS_SIGCHECK_SUC = 7;
	public static final int TASK_STATUS_INSTALL_SUC = 8;
	public static final int TASK_STATUS_INSTALL_FAIL = 9;
	public static final int TASK_STATUS_UPDATE_SUC = 10;
	public static final int TASK_STATUS_UPDATE_FAIL = 11;

	// 任务描述
	public static final int FIRMWARM_TASK = 1;
	public static final int APK_TASK = 2;

	/*
	 * 新版ota 新增
	 */
	// 保存设备运行的总时间
	public static final String DEVICE_RUNTIME = "device_runtime";

	// 设备UUID
	public static final String DEVICE_UUID = "device_uuid";

	// apk 下载 状态
	public static final int STATUS_APK_DOWNLOAD_SUC = 20;
	public static final int STATUS_APK_DOWNLOAD_FAIL = 21;
	public static final int STATUS_APK_CHECK_SUC = 22;
	public static final int STATUS_APK_CHECK_FAIL = 23;
	public static final int STATUS_APK_INSTALL_SUC = 24;
	public static final int STATUS_APK_INSTALL_FAIL = 25;
	public static final int STATUS_APK_UNKNOWN_ERR = 26;

	// 默认域名
	public static final String OTA_BASE = "http://ota.xbkpota.com/fota/fota/";//"https://localhost:8080/fota/";
	// 首次访问服务器地址 第二个是测试地址
	public static final String OTA_VISIT = "Otavisit.do";
	//默认下载域名
	public static final String OTA_DOWNLOAD_BASE = "http://ota.xbkpota.com/fota/";
	// 回传固件升级信息
	public static final String OTA_FW_REPORT = "insertFwLog.do";
	
	// 回传APK信息
	public static final String OTA_APK_REPORT = "reportApkLog.do";

	// 访问方式
	public static final String OTA_VISIT_CYCLE = "cycle";

	public static final String OTA_VISIT_Click = "click";

	// 下一次访问时间
	public static final String NEXT_VISIT = "next_visit";

	// 第几次访问
	public static final String RESPONSE_CODE = "resposne_code";
	
	// 保存注册时间
	public static final String OTA_REGIS_TIME = "dev_register_time";

	// 存数常用的会变的数据
	public static final String OTA_SP_INFO = "ota_info";
	// 存储device信息表
	public static final String OTA_SP_DEVICE = "ota_device";

	// 存储fw信息
	public static final String OTA_SP_FW = "ota_fw";

	// fw shareprefrence 中的key

	public static final String OTA_FW_ID = "fw_id";
	public static final String OTA_FW_CUR_VERSION = "fw_cur_version";
	public static final String OTA_FW_TARGET_VERSION = "fw_target_version";
	public static final String OTA_FW_TOTAL_SIZE = "fw_total_size";
	public static final String OTA_FW_DOWNLOAD_SIZE = "fw_download_size";
	public static final String OTA_FW_MD4 = "fw_md5";
	public static final String OTA_FW_DOWNLOAD_URL = "fw_download_url";
	public static final String OTA_FW_FILE_NAME = "fw_file_name";

	// fw 下载 状态
	public static final int STATUS_FW_DOWNLOAD_SUC = 30;
	public static final int STATUS_FW_DOWNLOAD_FAIL = 31;
	public static final int STATUS_FW_CHECK_SUC = 32;
	public static final int STATUS_FW_CHECK_FAIL = 33;
	public static final int STATUS_FW_INSTALL_SUC = 34;
	public static final int STATUS_FW_INSTALL_FAIL = 35;
	public static final int STATUS_FW_UNKNOWN_ERR =36;

	// 存储总共运行时间
	public static final String OTA_TOTAL_TIME = "ota_total_time";
	
	//apkFile path
	public static final String OTA_APK_PATH = Environment.getExternalStorageDirectory()+ "/Android/";
	
	//apkFile path
//	public static final String OTA_FW_PATH = Environment.getExternalStorageDirectory()+ "/Android/update.zip";
	
	public static String getCache(Context context){
//		return context.getCacheDir().getPath()+"/update.zip";
		return Environment.getExternalStorageDirectory()+ "/Android/update.zip";
	}
	
	//apk安装时间间隔
	public static final long OTA_APK_INSTALL_ALARM=10*60*1000;
	
	//ota 访问间隔
	public static final long OTA_VISIT_ALARM=24*60*60*1000;
	
	public static final long OTA_CYCLE_APK_TIME=60*60*1000;
	
	
	// 闹钟id
	
	public static final int OTA_CYCLE_VISIT_ALARM=0;
	
	public static final int OTA_CYCLE_APK_ALARM=1;
	
	
	
	//发送回传广播
	public static final String REPORT_APK_ACTION="com.fota.report.apk";
	public static final String REPORT_FW_ACTION="com.fota.report.fw";
	
	
	//apk 允许下载失败的次数
	public static final int OTA_APK_DOWNLOAD_ALLOW_ERR=3;

}
