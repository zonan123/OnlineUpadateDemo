package com.fota.service;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.widget.RemoteViews;

import com.fota.sys.OtaConstant;
import com.fota.util.OtaSharePreferenceUtil;
import com.fota.R;

public class OtaNotification
{
	private Context cn;
	
	private boolean ondown = false;
	
	public OtaNotification(Context context) 
	{
		this.cn = context;
	}
	
	public void setOndown(boolean down)
	{
		this.ondown = down;
	}
	
	public void sendNotification()
	{
		NotificationManager notiManager = (NotificationManager) cn.getSystemService(Service.NOTIFICATION_SERVICE);
		
		Notification notification = new Notification();
		
		Intent intent = new Intent();
		
		if(ondown)
		{
			intent.setClassName("com.fota", "com.fota.ui.OnlineDownload");
		}
		else
		{
			intent.setClassName("com.fota", "com.fota.ui.OtaMainActivity");
			
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		}
		
		PendingIntent pendingIntent = PendingIntent.getActivity(cn, 10010, intent, PendingIntent.FLAG_UPDATE_CURRENT);
		
		notification.contentIntent = pendingIntent;
		
		notification.flags = Notification.FLAG_AUTO_CANCEL;
		
		notification.icon = R.drawable.ic_title;
		
		Resources res = cn.getResources();
		
		notification.tickerText = res.getString(R.string.ota_noti_title);
		
		RemoteViews rm = new RemoteViews(cn.getPackageName(), R.layout.otanotification);
		
		if(ondown)
		{
			rm.setTextViewText(R.id.otamessage, res.getString(R.string.ota_noti_download));
		}
		else
		{
			rm.setTextViewText(R.id.otamessage, res.getString(R.string.ota_noti_message));
		}
		
		notification.contentView = rm;
		
		if(OtaSharePreferenceUtil.getBooleanValue(cn,OtaConstant.OTA_SP_INFO, OtaConstant.ALLOW_ACCESS_AUTO, false)||ondown)
		{
			notiManager.notify(0, notification);
		}
	}
}
