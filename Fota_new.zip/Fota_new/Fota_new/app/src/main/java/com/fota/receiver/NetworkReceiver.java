package com.fota.receiver;
 

import com.fota.sys.OtaConstant;
import com.fota.util.LogUtil;
import com.fota.util.OtaServerOperation;
import com.fota.util.OtaSharePreferenceUtil;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
/**
 * 网络变化广播接收器。
 * @author zw
 *
 */
public class NetworkReceiver extends BroadcastReceiver {  
	
	@Override
	public void onReceive(Context context, Intent intent) { 
		String action = intent.getAction();
		
		if (action.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
			
			Long curVisit = OtaSharePreferenceUtil.getLongValue(context, OtaConstant.OTA_SP_INFO,
					OtaConstant.NEXT_VISIT, System.currentTimeMillis());
			
			if ((curVisit - System.currentTimeMillis() <=0 ) || (curVisit - System.currentTimeMillis() >OtaConstant.OTA_VISIT_ALARM)){
				LogUtil.log(LogUtil.INFO, "fota", "into ota visit cycle");
				OtaServerOperation otaServerOperation = new OtaServerOperation(context, null,
						OtaConstant.OTA_VISIT_CYCLE);
				Thread visit = new Thread(otaServerOperation);
				visit.start();
			}
			printNetworkInfo(context);

		} 
	}
	
	private void printNetworkInfo(Context context){
		ConnectivityManager connectivityManager = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo info = connectivityManager.getActiveNetworkInfo();
		if (info != null && info.isAvailable()) {
			LogUtil.log(LogUtil.INFO, "fota", info.getTypeName());
			//
		}else {
			LogUtil.log(LogUtil.INFO, "fota", "network can't find");
		}
	}
}
