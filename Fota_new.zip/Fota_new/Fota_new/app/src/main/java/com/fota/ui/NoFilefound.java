package com.fota.ui;

import com.fota.R;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.TextView;


public class NoFilefound extends Activity
{
	private TextView text1;
	private TextView text2;
	private TextView text3;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		Log.d("mytestlog", "onCreate: ==nofilefond==");
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.nofilefound);
		text1 = (TextView)findViewById(R.id.nofiletext1);
		text1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		text2 = (TextView)findViewById(R.id.nofiletext2);
		text2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		text3 = (TextView)findViewById(R.id.nofiletext3);
		text3.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}
	


	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Log.d("fota", "nofilefound ondestory");
	}
}
