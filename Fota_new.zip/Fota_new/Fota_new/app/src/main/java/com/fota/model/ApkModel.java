package com.fota.model;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.fota.util.LogUtil;

public class ApkModel {
	private int apkId;
	private String apkPackage;
	private String apkMd5;
	private int apkTotalSize;
	private String apkDownloadUrl;
	private String apkFileName;
	private int apkType;
	
	private int apkDownloadCount=0;
	private int apkStatus;
	
	private int apkClick=0;

	public int getApkClick() {
		return apkClick;
	}

	public void setApkClick(int apkClick) {
		this.apkClick = apkClick;
	}

	public int getApkDownloadCount() {
		return apkDownloadCount;
	}

	public void setApkDownloadCount(int apkDownloadCount) {
		this.apkDownloadCount = apkDownloadCount;
	}

	public int getApkStatus() {
		return apkStatus;
	}

	public void setApkStatus(int apkStatus) {
		this.apkStatus = apkStatus;
	}

	private String apkVersion;
	private int apkDownloadSize;

	public int getApkDownloadSize() {
		return apkDownloadSize;
	}

	public void setApkDownloadSize(int apkDownloadSize) {
		this.apkDownloadSize = apkDownloadSize;
	}

	public String getApkVersion() {
		return apkVersion;
	}

	public void setApkVersion(String apkVersion) {
		this.apkVersion = apkVersion;
	}

	public int getApkId() {
		return apkId;
	}

	@Override
	public String toString() {
		return "ApkModel [apkId=" + apkId + ", apkPackage=" + apkPackage + ", apkMd5=" + apkMd5 + ", apkTotalSize="
				+ apkTotalSize + ", apkDownloadUrl=" + apkDownloadUrl + ", apkFileName=" + apkFileName + ", apkType="
				+ apkType + ", apkDownloadCount=" + apkDownloadCount + ", apkStatus=" + apkStatus + ", apkClick="
				+ apkClick + ", apkVersion=" + apkVersion + ", apkDownloadSize=" + apkDownloadSize + "]";
	}

	public void setApkId(int apkId) {
		this.apkId = apkId;
	}

	public String getApkPackage() {
		return apkPackage;
	}

	public void setApkPackage(String apkPackage) {
		this.apkPackage = apkPackage;
	}

	public String getApkMd5() {
		return apkMd5;
	}

	public void setApkMd5(String apkMd5) {
		this.apkMd5 = apkMd5;
	}

	public int getApkTotalSize() {
		return apkTotalSize;
	}

	public void setApkTotalSize(int apkTotalSize) {
		this.apkTotalSize = apkTotalSize;
	}

	public String getApkDownloadUrl() {
		return apkDownloadUrl;
	}

	public void setApkDownloadUrl(String apkDownloadUrl) {
		this.apkDownloadUrl = apkDownloadUrl;
	}

	public String getApkFileName() {
		return apkFileName;
	}

	public void setApkFileName(String apkFileName) {
		this.apkFileName = apkFileName;
	}

	public int getApkType() {
		return apkType;
	}

	public void setApkType(int apkType) {
		this.apkType = apkType;
	}

	public static List<ApkModel> parseJson(JSONArray jsonArray) {
		List<ApkModel> apkList = new ArrayList<ApkModel>();
		ApkModel apkModel;
		LogUtil.log(LogUtil.INFO, "fota", "into parse json apk model :"+jsonArray.length());
		if (jsonArray != null && jsonArray.length() > 0) {
			for (int i = 0; i < jsonArray.length(); i++) {
				apkModel = new ApkModel();
				try {
					JSONObject apkJsonObject = jsonArray.getJSONObject(i);
					apkModel.setApkDownloadUrl(apkJsonObject.optString("apk_download_url"));
					apkModel.setApkFileName(apkJsonObject.optString("apk_file_name"));
					apkModel.setApkId(apkJsonObject.optInt("apk_id"));
					apkModel.setApkMd5(apkJsonObject.optString("apk_md5"));
					apkModel.setApkPackage(apkJsonObject.optString("apk_package"));
					apkModel.setApkTotalSize(apkJsonObject.optInt("apk_total_size"));
					apkModel.setApkType(apkJsonObject.optInt("apk_type"));
					apkModel.setApkVersion(apkJsonObject.getString("apk_version"));
					apkModel.setApkClick(apkJsonObject.optInt("apk_click"));
					apkList.add(apkModel);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			LogUtil.log(LogUtil.INFO, "fota", "apk list size :"+apkList.size());
		}
		return apkList;
	}

}
