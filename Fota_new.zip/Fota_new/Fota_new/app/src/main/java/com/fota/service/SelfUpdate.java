package com.fota.service;

import java.io.File;
import java.net.URLEncoder;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;

import com.fota.dao.TaskStatusDao;
import com.fota.model.ApkModel;
import com.fota.model.MissionModel;
import com.fota.sys.OtaConstant;
import com.fota.util.DeviceUtil;
import com.fota.util.FileMd5;
import com.fota.util.FileUtil;
import com.fota.util.LogUtil;
import com.fota.util.OtaSharePreferenceUtil;
import com.fota.util.ServiceUtil;
import com.fota.util.StringUtil;

public class SelfUpdate implements Runnable
{

	public Context cn;
	
	MissionModel model;
	
	ApkModel apkModel;
	
	public boolean install = false;
	
	public boolean newtask = false;
	
	int taskid = 0;
	
	public SelfUpdate(Context context,MissionModel model,boolean task,int id) 
	{
		this.cn = context;
		
		this.model = model;
		
		this.newtask = task;
		
		this.taskid = id;
	}
	
	
	public void setInstall(boolean install)
	{
		this.install = install;
	}
	
	public void HandlerMission(MissionModel model)
    {
    	String newversion = model.getNewapkversion();
    	
    	String currentversion = new DeviceUtil().getCurrentSoftVersion(cn);	
    		
    	if(!newversion.equals(currentversion)&&!StringUtil.isNullOrEmpty(newversion))
    	{//有自升级任务
    		
    		OtaSharePreferenceUtil.saveBooleanValue(cn,OtaConstant.OTA_SP_INFO, OtaConstant.IS_DOWNLOADING, true);
    		
    		TaskStatusDao reportStatus = new TaskStatusDao(cn);
    		
    		if(newtask)
    		{
    			reportStatus.TaskStatusBegin(OtaConstant.APK_TASK, OtaConstant.TASK_STATUS_TASK_BEGIN);
        		
        		reportStatus.saveModel(model);
        		
        		OtaSharePreferenceUtil.saveStringValue(cn,OtaConstant.OTA_SP_INFO, OtaConstant.APK_FILE_NAME, model.getApkname());
    		}
    		
    		if(taskid == 0)
    		{
    			taskid = reportStatus.getTaskId(OtaConstant.APK_TASK, OtaConstant.TASK_STATUS_TASK_BEGIN);
    		}
 
    		 LogUtil.log(Log.DEBUG,"fota", "get task id :" + taskid);
//    		boolean download = ServiceUtil.downLoadFile22(model.getApkurl(), OtaConstant.SDUPDATE_APK, null);
    		
    		String uuid = OtaSharePreferenceUtil.getStringValue(cn,OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID, "");
	    	
	    	if(StringUtil.isNullOrEmpty(uuid))
	    	{
	    		uuid = DeviceUtil.getDeviceId(cn);
	    		
	    		OtaSharePreferenceUtil.saveStringValue(cn,OtaConstant.OTA_SP_INFO, OtaConstant.DEVICE_ID, uuid);
	    		
	    		
	    	}
	    	
	    	String url = null;
			try {
				url = model.getApkurl()+"?apkFileName="+URLEncoder.encode(model.getApkname(),"UTF-8")+"&UUID="+URLEncoder.encode(uuid,"UTF-8");

			} catch (Exception e) {}
	    	
    		LogUtil.log(Log.DEBUG,"fota", "SelfUpdate  url : " + url);
    		boolean download = ServiceUtil.downLoadFileWithBreak(url, OtaConstant.getCache(cn), null);
    		
    		OtaSharePreferenceUtil.saveBooleanValue(cn,OtaConstant.OTA_SP_INFO, OtaConstant.IS_DOWNLOADING, false);
    		
    		//增加下载次数
    		int downloadtimes = OtaSharePreferenceUtil.getIntValue(cn,OtaConstant.OTA_SP_INFO, OtaConstant.DOWNLOAD_TIMES, 0);
    		
    		downloadtimes += 1;
    		
    		OtaSharePreferenceUtil.saveIntValue(cn,OtaConstant.OTA_SP_INFO, OtaConstant.DOWNLOAD_TIMES, downloadtimes);
    		
    		if(download)
    		{
    			File updatefile = new File(OtaConstant.getCache(cn));
    			
    			if(FileMd5.checkMD5(model.getApkmd5(), updatefile))
    			{
    				reportStatus.UpdateStatus(OtaConstant.TASK_STATUS_DOWNLOAD_SUC,taskid);
        			
        			OtaSharePreferenceUtil.saveIntValue(cn,OtaConstant.OTA_SP_INFO, OtaConstant.DOWNLOAD_TIMES, 0);
        			
//        			reportStatus.reportServer(taskid);
        			
        			 LogUtil.log(Log.DEBUG,"fota", "selfupdata download success");
    			}
    			else
    			{
    				//校验失败，回传状态
        			reportStatus.UpdateStatus(OtaConstant.TASK_STATUS_CHECK_FAIL,taskid);
        			
        			reportStatus.UpdateFinish(taskid);
        			
        			reportStatus.reportServer(taskid);
        			
//        			reportStatus.deleteModel();
        			//任务完成，删除中间文件、任务数据
//            		FileUtil.deleteFile(OtaConstant.SDUPDATE_APK);
            		LogUtil.log(Log.DEBUG,"fota", "selfupdate fail ,check md5 fail");
    			}
    			
    		}
    		else
    		{	
    			int times = OtaSharePreferenceUtil.getIntValue(cn,OtaConstant.OTA_SP_INFO, OtaConstant.DOWNLOAD_TIMES, 0);
    			
    			if(times >= 3)
    			{
    				//下载失败，回传状态
        			reportStatus.UpdateStatus(OtaConstant.TASK_STATUS_DOWNLOAD_FAIL,taskid);
        			
        			reportStatus.UpdateFinish(taskid);
        			
        			reportStatus.reportServer(taskid);
        			
        			reportStatus.deleteModel();
        			//任务完成，删除中间文件、任务数据
//            		FileUtil.deleteFile(OtaConstant.SDUPDATE_APK);
            		
            		LogUtil.log(Log.DEBUG,"fota", "more than 3 times download");
            
    			}
    			else
    			{
    				reportStatus.UpdateStatus(OtaConstant.TASK_STATUS_DOWNLOAD_FAIL, taskid);
    				LogUtil.log(Log.DEBUG,"fota", "download fail,wait for next times");
				}
    		}
    		
    		
    	}
    	
    }
	
	public void Update()
	{
		TaskStatusDao reportStatus = new TaskStatusDao(cn);
		
//		int taskid = reportStatus.getTaskId(OtaConstant.APK_TASK, OtaConstant.TASK_STATUS_DOWNLOAD_SUC);
		
		LogUtil.log(Log.DEBUG,"fota", "Update taskid : " + taskid);
		
		//installApk(OtaConstant.SDUPDATE_APK);
		//自升级失败才会继续运行一下代码
		reportStatus.UpdateStatus(OtaConstant.TASK_STATUS_INSTALL_FAIL,taskid);
		
		LogUtil.log(Log.DEBUG,"fota", "selfUpdate fail");
		
		
		reportStatus.UpdateFinish(taskid);
		
		reportStatus.reportServer(taskid);
		
		reportStatus.deleteModel();
		
		FileUtil.deleteFile(OtaConstant.getCache(cn));
		
	}
	
	public static String installApk(Context context,String filePath,ApkModel apkModel)
	{
		String result="fail";
		LogUtil.log(LogUtil.INFO, "fota", "into install apk");
		
		if(apkModel==null)
		{
			result= "fail";
		}
		try
		{
			Process localProcess = Runtime.getRuntime().exec(
					"pm install -r " + filePath);
			
			localProcess.waitFor();
			
			localProcess.exitValue();
			
			LogUtil.log(LogUtil.INFO, "fota", "安装完成");

			result= DeviceUtil.isExistApk(context,apkModel) ? "ok" : "fail";
			if(result.equalsIgnoreCase("ok") && apkModel.getApkClick()==1){
//			if(true){
				PackageManager packageManager = context.getPackageManager();
				Intent intent=new Intent();
				intent =packageManager.getLaunchIntentForPackage(apkModel.getApkPackage());
				context.startActivity(intent);
			}
		}
		catch(Exception ex)
		{
			LogUtil.log(LogUtil.ERROR, "fota", "静默安装失败");
			result= "fail";
		}
		
		return result;
	}
	
	@Override
	public void run() 
	{
		if(install)
		{
			Update();
		}
		else
		{
			HandlerMission(model);
		}
	}
}
