package com.fota.receiver;

import com.fota.sys.OtaConstant;
import com.fota.util.LogUtil;
import com.fota.util.OtaSharePreferenceUtil;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

public class ShutdownBroadcastReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		
		LogUtil.log(LogUtil.ERROR, "fota", "=================device shut down=========================");
		  long totalTime1=OtaSharePreferenceUtil.getLongValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.OTA_TOTAL_TIME, -1);
		  long totalTime2=totalTime1+SystemClock.elapsedRealtime();
		  OtaSharePreferenceUtil.saveLongValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.OTA_TOTAL_TIME, totalTime2);
		

	}

}
