package com.fota.util;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fota.sys.Constant;

import android.annotation.SuppressLint;
import android.os.Environment;
import android.util.Log;

public class LogUtil {
	public static final int DEBUG = 1;
	public static final int INFO = 2;
	public static final int ERROR = 3;
	public static boolean isDebug = false;

	@SuppressLint("SimpleDateFormat")
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public static void log(int type, String tag, String value) {
		String path = Environment.getExternalStorageDirectory() + "/fota.log";
		File logfile = new File(path);
//		if (logfile.exists()) {
			switch (type) {
			case DEBUG:
				Log.d("fota", tag + "\n" + value + "\n");
				break;

			case INFO:
				Log.i("fota", tag + "\n" + value + "\n");
				break;

			case ERROR:
				Log.e("fota", tag + "\n" + value + "\n");
				break;

			default:
				break;
			}
//		}
		if(isDebug){
			log("["+ tag +"]" + value);
		}
	}

	private static void log(String value) {
		FileWriter fw = null;
		try {
			File file = new File(Constant.DEFAULT_DOWN_FILE_PATH + "/fota.log");
			if (!file.exists()) {
				file.createNewFile();
			}
			fw = new FileWriter(file, true);
			fw.append(sdf.format(new Date()) + ":" + value.toString() + "\r\n");
		} catch (Exception ex) {
			Log.i("fota", "log error="+ex.toString());
		} finally {
			try {
				if (fw != null)
					fw.close();
			} catch (Exception ex) {
			}
		}
	}
}
