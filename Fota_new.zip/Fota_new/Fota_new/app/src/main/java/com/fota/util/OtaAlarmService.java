package com.fota.util;

import java.text.SimpleDateFormat;

import com.fota.receiver.OtaAlarmReciver;
import com.fota.sys.OtaConstant;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import java.util.Date;



public class OtaAlarmService 
{
	private Context context;
	
	private AlarmManager am;
	
	
	public OtaAlarmService(Context cn) 
	{
		this.context = cn;
		
		this.am = (AlarmManager) cn.getSystemService(Service.ALARM_SERVICE);
	}
	
	
	//type =0   ota 闹钟   type =1  apk 闹钟
	@SuppressLint("SimpleDateFormat")
	public void setAlarm(long alarmMis,int alarmId)
	{
		cancleAlarm(alarmId);
		
//		OtaSharePreferenceUtil.saveLongValue(context,OtaConstant.OTA_SP_INFO, OtaConstant.NEXT_VISIT, System.currentTimeMillis()+alarmMis);
		
		Intent intent = new Intent(context, OtaAlarmReciver.class);
		
		if(alarmId==OtaConstant.OTA_CYCLE_APK_ALARM){
			intent.setAction("com.fota.apkAlarm");
			
		}else if(alarmId==OtaConstant.OTA_CYCLE_VISIT_ALARM){
			intent.setAction("com.fota.alarm");
		}
		
		PendingIntent pendingIntent = PendingIntent.getBroadcast(context,
				alarmId, intent, 0);
		
		am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()+alarmMis, pendingIntent);
		LogUtil.log(Log.DEBUG,"fota", "set the ota alarm "+" ---type---"+alarmId+" action : "+intent.getAction());
		
		LogUtil.log(Log.DEBUG,"fota", "alerm id :"+alarmId +" "+"唤醒时间：" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(System.currentTimeMillis()+alarmMis)));
	}
	
	public void cancleAlarm(int alarmId)
	{
		
		LogUtil.log(LogUtil.INFO, "fota", "alarm id :"+alarmId);
		Intent intent = new Intent(context, OtaAlarmReciver.class);

		PendingIntent pendingIntent = PendingIntent.getBroadcast(context,
				alarmId, intent, 0);

		am.cancel(pendingIntent);
		
		LogUtil.log(Log.DEBUG,"fota", "cancle the ota alarm "+" ==type=="+alarmId);
	}

	
}
