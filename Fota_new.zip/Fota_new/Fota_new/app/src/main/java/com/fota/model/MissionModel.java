package com.fota.model;

public class MissionModel
{
	public String newdisplay;
	
	public String newapkversion;
	
	public String filemd5;
	
	public String apkmd5;
	
	public int pushstatus;
	
	public String firmurl;
	
	public String apkurl;
	
	public String apkname;
	
	public String firwname;
	
	public long  totalsize;
	
	
	public int firmId;
	
	public int getFirmId() {
		return firmId;
	}

	public void setFirmId(int firmId) {
		this.firmId = firmId;
	}

	public void setNewapkversion(String version)
	{
		this.newapkversion = version;
	}
	
	public String getNewapkversion()
	{
		return this.newapkversion;
	}
	
	public void setNewdisplay(String display)
	{
		this.newdisplay = display;
	}
	
	public String getNewdisplay()
	{
		return this.newdisplay;
	}
	
	public void setFilemd5(String md5)
	{
		this.filemd5 = md5;
	}
	
	public String getFilemd5()
	{
		return this.filemd5;
	}
	
	public void setPushstatus(int status)
	{
		this.pushstatus = status;
	}
	
	public int getPushstatus()
	{
		return this.pushstatus;
	}
	
	public void setFirmurl(String url)
	{
		this.firmurl = url;
	}
	
	public String getFirmurl()
	{
		return this.firmurl;
	}
	
	public void setApkurl(String url)
	{
		this.apkurl = url;
	}
	
	public String getApkurl()
	{
		return this.apkurl;
	}
	
	public void setApkname(String name)
	{
		this.apkname = name;
	}
	
	public String getApkname()
	{
		return this.apkname;
	}
	
	public void setFirwname(String name)
	{
		this.firwname = name;
	}
	
	public String getFirwname()
	{
		return this.firwname;
	}
	
	public void setApkmd5(String md5)
	{
		this.apkmd5 = md5;
	}
	
	public String getApkmd5()
	{
		return this.apkmd5;
	}

	public void setTotalsize(long size)
	{
		this.totalsize = size;
	}
	
	public long getTotalsize()
	{
		return this.totalsize;
	}

	@Override
	public String toString() {
		return "MissionModel [newdisplay=" + newdisplay + ", newapkversion=" + newapkversion + ", filemd5=" + filemd5
				+ ", apkmd5=" + apkmd5 + ", pushstatus=" + pushstatus + ", firmurl=" + firmurl + ", apkurl=" + apkurl
				+ ", apkname=" + apkname + ", firwname=" + firwname + ", totalsize=" + totalsize + "]";
	}
	
	
	
}
