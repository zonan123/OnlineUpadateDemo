package com.fota.dao;

import java.util.ArrayList;
import java.util.List;

import com.fota.model.ApkModel;
import com.fota.util.LogUtil;

import android.content.Context;
import android.database.Cursor;

public class ApkDao {

	public static boolean saveApkModel(List<ApkModel> apkList, Context context) {

		LogUtil.log(LogUtil.INFO, "fota", "into save apk");
		boolean result = false;
		try {
			for (ApkModel apkModel : apkList) {
				OtaDbUtil dbUtil = OtaDbUtil.getOtaDbUtil(context);
				String sql = "replace into ota_apk_table "
						+ " (Apk_id,Apk_package,Apk_md5,Apk_total_size,Apk_download_url,Apk_filename,Apk_type,Apk_version,Apk_click)"
						+ " values (" + apkModel.getApkId() + ",'" + dbUtil.sqliteEscape(apkModel.getApkPackage())
						+ "','" + apkModel.getApkMd5() + "'," + apkModel.getApkTotalSize() + ",'"
						+ dbUtil.sqliteEscape(apkModel.getApkDownloadUrl()) + "','"
						+ dbUtil.sqliteEscape(apkModel.getApkFileName()) + "'," + apkModel.getApkType() + ",'"
						+ apkModel.getApkVersion() + "',"+ apkModel.getApkClick()+")";
				LogUtil.log(LogUtil.INFO, "fota", "apk info sql :" + sql);

				dbUtil.exec(sql);
				result = true;
			}
		} catch (Exception ex) {
			LogUtil.log(LogUtil.INFO, "fota", "apk info sql error");
			result = false;
			ex.printStackTrace();
		}
		return result;

	}

	// UPDATE COMPANY SET ADDRESS = 'Texas' WHERE ID = 6;
	public static boolean insertApkodel(ApkModel apkModel, Context context) {
		StringBuffer strBuf = new StringBuffer();
		strBuf.append("update ota_apk_table ");
		if (apkModel.getApkDownloadCount() != 0) {
			strBuf.append("set Apk_download_count=" + apkModel.getApkDownloadCount());
		}
		if (apkModel.getApkType() != 0) {
			strBuf.append("set Apk_download_count=" + apkModel.getApkDownloadCount());
		}
		strBuf.append(" where Apk_id=" + apkModel.getApkId());
		return false;
	}

	public static boolean saveApkModel(ApkModel apkModel, Context context) {
		boolean result = false;
		try {
			OtaDbUtil dbUtil = OtaDbUtil.getOtaDbUtil(context);
			String sql = "replace into ota_apk_table "
					+ " (Apk_id,Apk_package,Apk_md5,Apk_total_size,Apk_download_url,Apk_filename,Apk_type,Apk_version,Apk_download_size,Apk_download_count,Apk_status,Apk_click)"
					+ " values (" + apkModel.getApkId() + ",'" + dbUtil.sqliteEscape(apkModel.getApkPackage()) + "','"
					+ dbUtil.sqliteEscape(apkModel.getApkMd5()) + "'," + apkModel.getApkTotalSize() + ",'"
					+ dbUtil.sqliteEscape(apkModel.getApkDownloadUrl()) + "','"
					+ dbUtil.sqliteEscape(apkModel.getApkFileName()) + "'," + apkModel.getApkType() + ",'"
					+ dbUtil.sqliteEscape(apkModel.getApkVersion()) + "'," + apkModel.getApkDownloadSize() + ","
					+ apkModel.getApkDownloadCount() + "," + apkModel.getApkStatus()+","+apkModel.getApkClick()+")";
			LogUtil.log(LogUtil.INFO, "fota", "apk info sql :" + sql);
			dbUtil.exec(sql);
			result = true;

		} catch (Exception ex) {
			LogUtil.log(LogUtil.INFO, "fota", "apk info sql error");
			result = false;
			ex.printStackTrace();
		}
		return result;

	}

	public static ApkModel getApkInfo(Context context) {
		// select * from [table] order by id limit 20
		String sql = "select * from ota_apk_table order by Apk_id limit 1";
		ApkModel apkModel = new ApkModel();
		Cursor cursor = null;
		try {
			OtaDbUtil dbUtil = OtaDbUtil.getOtaDbUtil(context);
			cursor = dbUtil.rawquery(sql, null);
			if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
				apkModel.setApkDownloadSize(cursor.getInt(cursor.getColumnIndex("Apk_download_size")));
				apkModel.setApkDownloadUrl(
						dbUtil.sqliteUnescape(cursor.getString(cursor.getColumnIndex("Apk_download_url"))));
				apkModel.setApkFileName(dbUtil.sqliteUnescape(cursor.getString(cursor.getColumnIndex("Apk_filename"))));
				apkModel.setApkId(cursor.getInt(cursor.getColumnIndex("Apk_id")));
				apkModel.setApkMd5(cursor.getString(cursor.getColumnIndex("Apk_md5")));
				apkModel.setApkPackage(cursor.getString(cursor.getColumnIndex("Apk_package")));
				apkModel.setApkTotalSize(cursor.getInt(cursor.getColumnIndex("Apk_total_size")));
				apkModel.setApkType(cursor.getInt(cursor.getColumnIndex("Apk_type")));
				apkModel.setApkVersion(dbUtil.sqliteUnescape(cursor.getString(cursor.getColumnIndex("Apk_version"))));
				apkModel.setApkDownloadCount(cursor.getInt(cursor.getColumnIndex("Apk_download_count")));
				apkModel.setApkStatus(cursor.getInt(cursor.getColumnIndex("Apk_status")));
				apkModel.setApkClick(cursor.getInt(cursor.getColumnIndex("Apk_click")));
			} else {
				apkModel = null;
			}
			cursor.close();
			LogUtil.log(LogUtil.INFO, "fota", "count row " + cursor.getCount());
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return apkModel;
	}

	public static List<ApkModel> getAllApk(Context context) {
		// select * from [table] order by id limit 20
		String sql = "slelect * from ota_apk_table";
		List<ApkModel> apkList = new ArrayList<ApkModel>();
		OtaDbUtil dbUtil = null;
		Cursor cursor = null;
		try {
			dbUtil = OtaDbUtil.getOtaDbUtil(context);
			cursor = dbUtil.rawquery(sql, null);
			while (cursor.moveToNext()) {
				ApkModel apkModel = new ApkModel();
				apkModel.setApkDownloadSize(cursor.getInt(cursor.getColumnIndex("Apk_download_size")));
				apkModel.setApkDownloadUrl(
						dbUtil.sqliteUnescape(cursor.getString(cursor.getColumnIndex("Apk_download_url"))));
				apkModel.setApkFileName(dbUtil.sqliteUnescape(cursor.getString(cursor.getColumnIndex("Apk_filename"))));
				apkModel.setApkId(cursor.getInt(cursor.getColumnIndex("Apk_id")));
				apkModel.setApkMd5(cursor.getString(cursor.getColumnIndex("Apk_md5")));
				apkModel.setApkPackage(dbUtil.sqliteUnescape(cursor.getString(cursor.getColumnIndex("Apk_package"))));
				apkModel.setApkTotalSize(cursor.getInt(cursor.getColumnIndex("Apk_total_size")));
				apkModel.setApkType(cursor.getInt(cursor.getColumnIndex("Apk_type")));
				apkModel.setApkVersion(dbUtil.sqliteUnescape(cursor.getString(cursor.getColumnIndex("Apk_version"))));
				apkList.add(apkModel);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}

		return apkList;
	}

	public static boolean dropApkInfoByKey(int apkId, Context context) {
		boolean result = false;
		try {
			String sql = "delete from ota_apk_table where Apk_id=" + apkId;
			OtaDbUtil.getOtaDbUtil(context).exec(sql);
			result = true;
		} catch (Exception ex) {

			result = false;
			ex.printStackTrace();
		}
		return result;
	}

}
