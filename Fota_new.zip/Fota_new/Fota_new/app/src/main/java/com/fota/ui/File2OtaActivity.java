package com.fota.ui;

import com.fota.sys.OtaConstant;
import com.fota.util.InstallPackage;
import com.fota.util.LogUtil;
import com.fota.util.OtaSharePreferenceUtil;
import com.fota.R;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

public class File2OtaActivity extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		LogUtil.log(LogUtil.INFO, "File2OtaActivity", "strat  File2OtaActivity");
		
		String filePath = getIntent().getStringExtra("filePath");
		
		if(filePath != null){
			final Dialog dlg = new Dialog(this,R.style.MyDialog);
		      
//	        dlg.setTitle(R.string.confirm_update);
		    dlg.setCanceledOnTouchOutside(false);
		    LayoutInflater inflater = LayoutInflater.from(this);
		      
		    InstallPackage dlgView = (InstallPackage) inflater.inflate(R.layout.install_ota, null,
		              false);
		      
		    dlgView.setPackagePath(filePath);
		      
		    dlg.setContentView(dlgView);
		      
		    dlg.findViewById(R.id.confirm_cancel).setOnClickListener(new View.OnClickListener() {
		          @Override
		        public void onClick(View v) {
		        	//05-19
	                OtaSharePreferenceUtil.saveBooleanValue(getApplicationContext(),OtaConstant.OTA_SP_INFO, "isCancle", true);
	                
	                
	                
		            dlg.dismiss();
		            finish();
		        }
		    });
		      
		    dlg.show();
		}
    	
		
	}
}
