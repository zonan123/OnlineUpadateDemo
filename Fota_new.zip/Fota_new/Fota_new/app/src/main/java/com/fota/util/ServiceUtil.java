package com.fota.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Map;



import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Message;
import android.util.Log;


public class ServiceUtil
{

	public static String sendGet(String url, Map<String,String> params)
	{
		StringBuffer result = new StringBuffer();
		BufferedReader br = null;
		InputStreamReader isr = null;
		InputStream is = null;
		String value="?";
		try
		{
			
			if(params!=null)
			{
				
				for(String key : params.keySet())
				{
					value=value+key+"="+URLEncoder.encode(params.get(key), "UTF-8")+"&";
				}
			}
			
			URL realUrl = new URL(url+value);
			
			LogUtil.log(LogUtil.INFO, "fota", "real url "+realUrl);
			
			URLConnection conn = realUrl.openConnection();
			
			conn.setConnectTimeout(50000);
			
			conn.setReadTimeout(50000);
			
			conn.setRequestProperty("accept", "*/*");
			
			conn.setRequestProperty("connection", "Keep-Alive");
			
			conn.setRequestProperty("user-agent","Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");

			conn.connect();
			
			int responseCode = ((HttpURLConnection)conn).getResponseCode();
			
//			Log.d("fota", "visit server response code:" + responseCode);
			
			is = conn.getInputStream();
			
			isr = new InputStreamReader(is);
			
			br = new BufferedReader(isr);
			
			String line = null;
			
			while ((line = br.readLine()) != null)
			{
				result.append(line);
			}
			
			LogUtil.log(LogUtil.INFO, "ServiceUtil sendGet", "connect url["+ url +"] result:" + result.toString());
		}
		catch (Exception e)
		{
			LogUtil.log(LogUtil.ERROR, "ServiceUtil sendGet", "connect url["+ url +"] error:" + e.getMessage());
//			Log.d("fota", "ServiceUtil exception:" + e.toString()+"\nerror message:" + e.getMessage());
			
		}
		finally
		{
			try{if(br!=null)br.close();}catch(Exception ex){}
			try{if(isr!=null)isr.close();}catch(Exception ex){}
			try{if(is!=null)is.close();}catch(Exception ex){}
		}
		return result.toString();
	}
	
	public static String sendPost(String url, Map<String,String> params,byte[] buffer)
	{
		StringBuffer result = new StringBuffer();
		
		BufferedReader br = null;
		InputStreamReader isr = null;
		InputStream is = null;
		
		OutputStream os = null;
		
		try
		{
			URL realUrl = new URL(url);
			
			URLConnection conn = realUrl.openConnection();
			
			conn.setDoOutput(true);
			
			conn.setConnectTimeout(50000);
			
			conn.setReadTimeout(50000);
			
			conn.setRequestProperty("accept", "*/*");
			
			conn.setRequestProperty("connection", "Keep-Alive");
			
			conn.setRequestProperty("user-agent","Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");
			
			if(params!=null)
			{
				for(String key : params.keySet())
				{
					conn.setRequestProperty(key, params.get(key));
				}
			}

			conn.connect();
			
			os = conn.getOutputStream();
			
			os.write(buffer);
			
			is = conn.getInputStream();
			
			isr = new InputStreamReader(is);
			
			br = new BufferedReader(isr);
			
			String line = null;
			
			while ((line = br.readLine()) != null)
			{
				result.append(line);
			}
			
			LogUtil.log(LogUtil.INFO, "ServiceUtil sendPost", "connect url["+ url +"] result:" + result.toString());
		}
		catch (Exception e)
		{
			LogUtil.log(LogUtil.ERROR, "ServiceUtil sendPost", "connect url["+ url +"] error:" + e.getMessage());
		}
		finally
		{
			try{if(br!=null)br.close();}catch(Exception ex){}
			try{if(isr!=null)isr.close();}catch(Exception ex){}
			try{if(is!=null)is.close();}catch(Exception ex){}
			try{if(os!=null)os.close();}catch(Exception ex){}
		}
		
		return result.toString();
	}
	
	public static boolean downLoadFile22(String url,String filePath,Handler handler)
	{
		InputStream is = null;
		
		FileOutputStream fos = null;
		
		File file = null;
		
		try
		{
			URL realUrl = new URL(url);
			
			URLConnection conn = realUrl.openConnection();
			
			conn.setConnectTimeout(50000);
			
			conn.setReadTimeout(50000);
			
			conn.setRequestProperty("accept", "*/*");
			
			conn.setRequestProperty("connection", "Keep-Alive");
			
			conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");
			
			conn.setDoOutput(true);
			
			conn.setDoInput(true);

			conn.connect();
//			Log.d("fota", "before getinputstream");
			is = conn.getInputStream();
//			Log.d("fota", "after getinputstream");
			int length = conn.getContentLength();
			
			if (length > 0)
			{
				FileUtil.deleteFile(filePath);
				
				file = new File(filePath);
				
				if(!file.exists())
					file.createNewFile();
				
				fos = new FileOutputStream(file);
				
				byte[] temp = new byte[1024];
				
				int readLen = 0;
				
				int curReadLength = 0;
				
				int curPercent = 0;
				
				int tmpPercent = 0;
				
				while ((readLen = is.read(temp, 0, 1024)) != -1)
				{
					curReadLength += readLen;
					
					fos.write(temp,0,readLen);
					
					tmpPercent = (int) (curReadLength * 100 / length);
					
					//百分之5增加一次
					if((tmpPercent - 5)> curPercent)
					{
						curPercent = tmpPercent;
						
						if(handler!=null)
						{
							Message msg = Message.obtain();
							msg.what = 1;
							msg.obj = curPercent;
							handler.sendMessage(msg);
						}
					}
				}
				
				fos.flush();
				
				if(handler!=null)
				{
					handler.sendEmptyMessage(0);
				}
			}
			
			if(length==file.length())
				return true;
			else
			{
				LogUtil.log(LogUtil.INFO, "ServiceUtil downLoadFile", "文件下载的不一致，已删除");
				file.delete();
			}
		}
		catch(Exception ex)
		{
			try{ if(file!=null)file.delete(); }catch(Exception e){}
			
			if(handler!=null)
			{
				handler.sendEmptyMessage(0);
			}
			Log.d("fota", "download fail:"+ex.getMessage());
			LogUtil.log(LogUtil.INFO, "ServiceUtil downLoadFile", "文件下载失败");
		}
		finally
		{
			try{if (fos != null){fos.close();}}catch (Exception ex){ex.printStackTrace();}
			try{if (is != null){is.close();}}catch (Exception ex){ex.printStackTrace();}				
		}
		return false;
	}
	
	public static boolean downLoadFileWithBreak(String url,String filePath,Handler handler)
	{
		
		InputStream is = null;
		
		FileOutputStream fos = null;
		
		File file = null;

		for(int i=0; i<5; i++)
		{
			try
			{
				url = url.trim();
				
				URL realUrl = new URL(url);
				
				URLConnection conn = realUrl.openConnection();
				
				conn.setConnectTimeout(50000);
				
				conn.setReadTimeout(50000);
				
				conn.setRequestProperty("accept", "*/*");
				
				conn.setRequestProperty("connection", "Keep-Alive");
				
				conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");
				
				conn.setDoOutput(true);
				
				conn.setDoInput(true);
				
				file = new File(filePath);
				
				long existFileLength = 0;
				
				if(!file.exists())
				{
					file.createNewFile();
				}
				else
				{
					existFileLength = file.length();
				}
				
				fos = new FileOutputStream(file,true);
				
				if(existFileLength>0)
					conn.setRequestProperty("RANGE","bytes=" + existFileLength + "-");

				conn.connect();
				
				int responseCode = ((HttpURLConnection)conn).getResponseCode();
				
				if(responseCode==416)
				{
					if(handler!=null)
					{
						handler.sendEmptyMessage(0);
					}
					return true;
				}
				
				is = conn.getInputStream();
				
				int length = conn.getContentLength();
				
				if (length > 0)
				{
					byte[] temp = new byte[1024];
					
					int readLen = 0;
					
					int curReadLength = 0;
					
					int curPercent = 0;
					
					int tmpPercent = 0;
					
					while ((readLen = is.read(temp, 0, 1024)) != -1)
					{
						curReadLength += readLen;
						
						fos.write(temp,0,readLen);
						
						if(handler!=null)
						{
							tmpPercent = (int) (curReadLength * 100 / length);
							
							if(tmpPercent > curPercent)
							{
								curPercent = tmpPercent;
								Message msg = Message.obtain();
								msg.what = 1;
								msg.obj = curPercent;
								handler.sendMessage(msg);
							}
						}
					}
					
					fos.flush();
					
					if(handler!=null)
					{
						handler.sendEmptyMessage(0);
					}
				}
				//07-10添加
				if(length==file.length())
					return true;
				else
				{
					LogUtil.log(LogUtil.INFO, "ServiceUtil downLoadFile", "文件下载的不一致，已删除");
					file.delete();
				}
				
//				return true; //07-10注释
			}
			catch(Exception ex)
			{
				if(handler!=null)
				{
					handler.sendEmptyMessage(0);
				}
				
				LogUtil.log(LogUtil.INFO, "ServiceUtil downLoadFile", "文件下载失败:" + ex.getMessage());
			}
			finally
			{
				try{if (fos != null){fos.close();}}catch (Exception ex){ex.printStackTrace();}
				try{if (is != null){is.close();}}catch (Exception ex){ex.printStackTrace();}				
			}
		}
		return false;
	}
	
	
	
	public static boolean isConnectingToInternet(Context context)
	{
		ConnectivityManager connMgr = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		
		if (connMgr != null)
		{
			NetworkInfo[] info = connMgr.getAllNetworkInfo();
			if (info != null)
			{
				for (int i = 0; i < info.length; i++)
				{
					if (info[i].getState() == NetworkInfo.State.CONNECTED)
					{
						LogUtil.log(LogUtil.INFO, "fota", "network already connect");
						return true;
					}
				}
			}
		}
		LogUtil.log(LogUtil.INFO, "fota", "network can't connect");
		return false;
	}
	
	public static String getNetType(Context context)
	{
		try
		{
			ConnectivityManager cm = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo info = cm.getActiveNetworkInfo();
			if (null != info)
			{
				return info.getTypeName();
			}
			else
			{
				return "unknow";
			}
		}
		catch (Exception e)
		{
			return "unknow";
		}
	}
	
	public static String getMac(Context context)
	{
		String strMac = "";
		try
		{
			WifiManager wifi = (WifiManager)context
					.getSystemService(Context.WIFI_SERVICE);
			WifiInfo info = wifi.getConnectionInfo();
			if (null != info)
			{
				strMac = info.getMacAddress();
			}
		}
		catch (Exception e)
		{
			strMac = "unknow";
		}
		return strMac;
	}
	
}
