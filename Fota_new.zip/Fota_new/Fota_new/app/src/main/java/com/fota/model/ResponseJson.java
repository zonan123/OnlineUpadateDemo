package com.fota.model;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fota.util.LogUtil;

public class ResponseJson {

	public List<JSONObject> apkModel;
	
	public JSONArray apkJsonArray;
	
	public List<JSONObject> updateModel;
	
	public JSONArray  updateJsonArray;

	public FirmwareModel fwModel;

	public int responseCode = -1;

	public int nextVist = 24 * 60 * 60 * 1000;

	
	public String regisTime;
	
	

	// 将json 数据按实体对象保存

	public static ResponseJson parseJson(JSONObject jsonObject) {
		if (jsonObject == null) {
			LogUtil.log(LogUtil.DEBUG, "fota", "response json is null");
		}
		ResponseJson responseJson = new ResponseJson();
		
		//apk info
		if (jsonObject.optJSONArray("apk_info") != null) {
			responseJson.apkJsonArray = jsonObject.optJSONArray("apk_info");
			if (responseJson.apkJsonArray != null) {
				responseJson.apkModel = new ArrayList<JSONObject>();
				for (int i = 0; i < responseJson.apkJsonArray.length(); i++) {
					LogUtil.log(LogUtil.DEBUG, "fota",
							"size i :" + i + "object :" + responseJson.apkJsonArray.optJSONObject(i).toString());
					responseJson.apkModel.add(responseJson.apkJsonArray.optJSONObject(i));
				}
			}
		}else{
			LogUtil.log(LogUtil.INFO, "fota", "apk info is null");
		}
		
		//获取 fw 信息
		if (jsonObject.optJSONObject("fw_info") != null) {
			responseJson.fwModel = FirmwareModel.parseFwJson(jsonObject.optJSONObject("fw_info"));
			LogUtil.log(LogUtil.INFO, "fota", "aleady get fw json");
			//获取update 信息
			if (jsonObject.optJSONArray("update_info") != null) {
				responseJson.updateJsonArray = jsonObject.optJSONArray("update_info");
				
				responseJson.updateModel=new ArrayList<JSONObject>();
				
				LogUtil.log(LogUtil.INFO, "fota", "update json array size :"+responseJson.updateJsonArray.length());
				
				for (int i = 0; i < responseJson.updateJsonArray.length(); i++) {
					
					LogUtil.log(LogUtil.DEBUG, "fota",
							"size :" + i + "update info :" + responseJson.updateJsonArray.optJSONObject(i).toString());
					responseJson.updateModel.add(responseJson.updateJsonArray.optJSONObject(i));
				}
			}else{
				LogUtil.log(LogUtil.INFO, "fota", "update info is null");
			}
		}else{
			LogUtil.log(LogUtil.INFO, "fota", "fw info is null");
		}
		
		
		int serNextVisit = jsonObject.optInt("next_time");
		if (serNextVisit != 0) {
			responseJson.nextVist = jsonObject.optInt("next_time");
		}
		responseJson.responseCode = jsonObject.optInt("respone_code");

		responseJson.regisTime = jsonObject.optString("dev_register_data");

		return responseJson;
	}

}
