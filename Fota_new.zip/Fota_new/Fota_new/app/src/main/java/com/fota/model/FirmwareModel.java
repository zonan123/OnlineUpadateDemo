package com.fota.model;

import org.json.JSONObject;

import com.fota.util.LogUtil;

public class FirmwareModel 
{
	public int fwID;
	
	public String fwCurVersion;
	
	public String fwTargetVersion;
	
	public int fwTotailSize;
	
	public int  fwDownLoadSize;
	
	public String fwMd5;
	
	public String fwDownloadUrl;
	
	public String fwFileName;

	public int getFwID() {
		return fwID;
	}

	public void setFwID(int fwID) {
		this.fwID = fwID;
	}

	public String getFwCurVersion() {
		return fwCurVersion;
	}

	public void setFwCurVersion(String fwCurVersion) {
		this.fwCurVersion = fwCurVersion;
	}

	public String getFwTargetVersion() {
		return fwTargetVersion;
	}

	public void setFwTargetVersion(String fwTargetVersion) {
		this.fwTargetVersion = fwTargetVersion;
	}

	public int getFwTotailSize() {
		return fwTotailSize;
	}

	public void setFwTotailSize(int fwTotailSize) {
		this.fwTotailSize = fwTotailSize;
	}

	public int getFwDownLoadSize() {
		return fwDownLoadSize;
	}

	public void setFwDownLoadSize(int fwDownLoadSize) {
		this.fwDownLoadSize = fwDownLoadSize;
	}

	public String getFwMd5() {
		return fwMd5;
	}

	public void setFwMd5(String fwMd5) {
		this.fwMd5 = fwMd5;
	}

	public String getFwDownloadUrl() {
		return fwDownloadUrl;
	}

	public void setFwDownloadUrl(String fwDownloadUrl) {
		this.fwDownloadUrl = fwDownloadUrl;
	}

	public String getFwFileName() {
		return fwFileName;
	}

	public void setFwFileName(String fwFileName) {
		this.fwFileName = fwFileName;
	}
	
	
	public static FirmwareModel parseFwJson(JSONObject jsonObject){
		FirmwareModel fwModel=new FirmwareModel();
		fwModel.setFwCurVersion(jsonObject.optString("fw_old_version"));
		fwModel.setFwDownLoadSize(jsonObject.optInt(""));
		fwModel.setFwDownloadUrl(jsonObject.optString("fw_download_url"));
		fwModel.setFwFileName(jsonObject.optString("fw_file_name"));
		fwModel.setFwID(jsonObject.optInt("fw_id"));
		fwModel.setFwMd5(jsonObject.optString("fw_md5"));
		fwModel.setFwTargetVersion(jsonObject.optString("fw_new_version"));
		fwModel.setFwTotailSize(jsonObject.optInt("fw_total_size"));
		
		return fwModel;
		
	}
	
	
    
    public MissionModel convertMissionModel(FirmwareModel firmwareModel){
    	MissionModel missModel=new MissionModel();
    	missModel.setFilemd5(firmwareModel.getFwMd5());
    	missModel.setFirmurl(firmwareModel.getFwDownloadUrl());
    	missModel.setFirwname(firmwareModel.getFwFileName());
    	missModel.setNewdisplay(firmwareModel.getFwTargetVersion());
    	missModel.setTotalsize(firmwareModel.getFwTotailSize());
    	missModel.setFirmId(firmwareModel.getFwID());
    	LogUtil.log(LogUtil.INFO, "fota", missModel.toString());
    	return missModel;
    }

	@Override
	public String toString() {
		return "FirmwareTableModel [fwID=" + fwID + ", fwCurVersion=" + fwCurVersion + ", fwTargetVersion="
				+ fwTargetVersion + ", fwTotailSize=" + fwTotailSize + ", fwDownLoadSize=" + fwDownLoadSize + ", fwMd5="
				+ fwMd5 + ", fwDownloadUrl=" + fwDownloadUrl + ", fwFileName=" + fwFileName + "]";
	}
	
	
}
