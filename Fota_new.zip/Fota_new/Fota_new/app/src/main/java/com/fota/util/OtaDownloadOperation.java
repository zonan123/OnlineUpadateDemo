package com.fota.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;

import com.fota.sys.OtaConstant;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class OtaDownloadOperation implements Runnable
{
	
	private String neturl;
	
	private String filepath;
	
	private Handler handler;
	
	private long totalsize;
	
	private boolean pause = false;
	
	
	public OtaDownloadOperation(String url,String path,Handler handler,long size)
	{
		this.neturl = url;
		
		this.filepath = path;
		
		this.handler = handler;
		
		this.totalsize = size;
	}
	
	public void setPause(boolean p)
	{
		this.pause = p;
	}
	
	private  void DownloadWithBreak(String neturl,String filepath,Handler handler)
	{
		InputStream instream = null;
		
		FileOutputStream outsteam = null;
		
		File savefile = null;
		
		try
		{
			
			URL url = new URL(neturl);
			
			URLConnection uConnection = url.openConnection();
			
			uConnection.setDoInput(true);
			
			uConnection.setDoOutput(true);
			
			uConnection.setConnectTimeout(500000);
			
			uConnection.setReadTimeout(500000);
			
			uConnection.setRequestProperty("accept", "*/*");
			
			uConnection.setRequestProperty("connection", "Keep-Alive");
			
//			uConnection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");
			
			uConnection.setRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.34 Safari/534.24");
			
			savefile = new File(filepath);
			
			long  exitfilelength = 0;
			
			if(savefile.exists())
			{
				exitfilelength = savefile.length();
				
//				LogUtil.log(LogUtil.INFO, "fota", "exists file error, delete savefile!!");
//				savefile.delete();
//				
//				savefile.createNewFile();
			}
			else
			{
				savefile.createNewFile();
			}
			LogUtil.log(Log.DEBUG,"fota", "otaDownloadOperation length is:" + exitfilelength);
			
			if(exitfilelength > 0)
			{
				uConnection.setRequestProperty("Range", "bytes=" + exitfilelength + "-");
				LogUtil.log(Log.DEBUG,"fota", "range : bytes=" + exitfilelength + "-");
			}
			
			uConnection.connect();
			
			int responseCode = ((HttpURLConnection)uConnection).getResponseCode();
			LogUtil.log(Log.DEBUG,"fota", "response code:" + responseCode);
			if (responseCode == 416) 
			{
				return;
			}
			
			instream = uConnection.getInputStream();
			LogUtil.log(Log.DEBUG, "fota", "stream length:  " + uConnection.getContentLength());
			outsteam = new FileOutputStream(savefile, true);
			
//			totalsize = uConnection.getContentLength();

			LogUtil.log(Log.DEBUG,"fota", "totalsize is:" + totalsize);
			long downsize = exitfilelength;
			
			byte[] buff = new byte[1024];
			
			int len = 0;
			
			int currentPercent = 0;
			
			int tmPercent = 0;
			
			long tempMill=System.currentTimeMillis();
			
			long tempSize = downsize;
			
			OtaConstant.status = true;
			
			while((len=instream.read(buff))!=-1 && OtaConstant.status)
			{
				outsteam.write(buff, 0, len);
				
				downsize += len;
				
				currentPercent = (int)(downsize * 100 / totalsize);
				
				if(handler != null)
				{
					//计算下载百分比
					if(System.currentTimeMillis() - tempMill >=1000 || currentPercent == 100)
					{
						int speed = (int)(downsize - tempSize);
						
						Message msg = Message.obtain();
						
						msg.arg1 = currentPercent;
							
						tmPercent = currentPercent;
						
						msg.obj = getSpeed(speed);
						
						msg.what = 1;
						LogUtil.log(Log.DEBUG,"fota", "speed is: "+ getSpeed(speed)+" downloadsize:"+downsize+" tempsize:"+tempSize+"\nthreadId:"+Thread.currentThread().getId());
						LogUtil.log(Log.DEBUG,"fota", "currentPercent:" +currentPercent+"  tempPercent:" + tmPercent+" mag.arg1"+msg.arg1);
						handler.sendMessage(msg);
						
						tempSize = downsize;
						
						tempMill = System.currentTimeMillis();
					}
				}
			}
			
			outsteam.flush();
			//下载完成
			if(downsize == totalsize && handler!=null)
			{
				Message msg = Message.obtain();
				msg.what = 1;
				msg.arg1 = 100;
				handler.sendMessage(msg);
			}
			
		} 
		catch (Exception e) 
		{
			LogUtil.log(Log.DEBUG, "OtaDownloadOperation", "Message:" + e.getMessage());
			Log.d("fota", "download exception: " + e.toString() + "\nerror message: " + e.getMessage());
			e.printStackTrace();
			if(handler!=null)
			{
				Message msg = Message.obtain();
				
				msg.what = 0;
				
				msg.arg1 =(int)totalsize;
				
				handler.sendMessage(msg);
			}
		}
		finally
		{
			try 
			{
				if(instream!=null)instream.close();
				if(outsteam!=null)outsteam.close();
			} 
			catch (Exception e2) {
				// TODO: handle exception
			}
		}
		
	}
	
	public String getSpeed(int speed)
	{
		if(speed < 1024)
		{
			return speed + "B/s";
		}
		else if (speed >= 1024&&((double)speed/(double)1024 < 1024)) 
		{
			return speed/1024 + "KB/s";
		}
		else if (speed >= 1024&&((double)speed/(double)1024 > 1024)) 
		{
			DecimalFormat fm = new DecimalFormat(".#");
			double sendspeed = (double)speed/(double)(1024*1024);
			return  fm.format(sendspeed) + "MB/s";
		}
		return null;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try 
		{
			Thread.sleep(3000);
		} catch (Exception e) {
				// TODO: handle exception
		}
		DownloadWithBreak(neturl, filepath, handler);
	}
}
