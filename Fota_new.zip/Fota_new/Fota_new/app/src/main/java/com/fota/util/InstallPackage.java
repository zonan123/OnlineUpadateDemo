package com.fota.util;

import java.io.File;

import com.fota.dao.TaskStatusDao;
import com.fota.sys.OtaConstant;
import com.fota.R;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Handler;
import android.text.method.ScrollingMovementMethod;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LayoutAnimationController;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;


public class InstallPackage extends LinearLayout implements OtaUpgradeUtils.ProgressListener{
    
    private ProgressBar mProgressBar;
    private OtaUpgradeUtils mUpdateUtils;
    private LinearLayout mOutputField;
    private LayoutInflater mInflater;
    private String mPackagePath;
    private Handler mHandler = new Handler();
    private Button mDismiss,update_but;
    // add context
    private Context cn;
    private  TextView tv;

    public InstallPackage(Context context, AttributeSet attrs) {
        super(context, attrs);
        cn = context;
        mUpdateUtils = new OtaUpgradeUtils(context);
        mInflater = LayoutInflater.from(context);
        requestFocus();
    }
    
    public void setPackagePath(String path){
        mPackagePath = path;
    }
    
    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        mProgressBar = (ProgressBar) findViewById(R.id.verify_progress);
        mOutputField = (LinearLayout) findViewById(R.id.output_field);
        tv = (TextView) mInflater.inflate(R.layout.medium_text, null);
        tv.setMovementMethod(ScrollingMovementMethod.getInstance());
        tv.setText(R.string.install_ota_output_confirm);

        mOutputField.addView(tv);
        Animation animation = new AlphaAnimation(0.0f,1.0f);
        animation.setDuration(600);
        LayoutAnimationController controller =
            new LayoutAnimationController(animation);
        mOutputField.setLayoutAnimation(controller);
        mDismiss = (Button)findViewById(R.id.confirm_cancel);
        update_but= (Button)findViewById(R.id.confirm_update);
        update_but.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
            	//07-02 添加电量检测判断
            	if(powerStatus())
            	{
	                tv.setText(R.string.install_ota_output_start);
	                new Thread(new Runnable(){
	                    @Override
	                    public void run() {
	                        mUpdateUtils.upgradeFromOta(mPackagePath, InstallPackage.this);
	                    }            
	                }).start();
	//                mDismiss.setEnabled(false); 05-19 修改设置为 可以点击取消按钮
	                //05-19 
	               OtaSharePreferenceUtil.saveBooleanValue(cn,OtaConstant.OTA_SP_INFO, "isCancle", false);
	                
	                update_but.setEnabled(false);//05-05 修改设置为不可以点击
	               
	              //05-19修改  改变update按钮的样式
	                changeStyle();
            	}
            }
        });
    }
    
    //07-02添加的电量不足时设置弹窗
    public void dialogTest(String str)
    {
    	new AlertDialog.Builder(cn)
	    	.setTitle(cn.getString(R.string.power_title))
	    	.setMessage(str)
	    	.setPositiveButton(cn.getString(R.string.power_but), null)
	    	.show();
    }
    
    //07-02添加的电量状态检测功能
    private float batteryPct;
	private IntentFilter ifilter;
	private Intent batteryStatus;
    public boolean powerStatus()
    {
    	ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
    	batteryStatus = cn.registerReceiver(null, ifilter);
    	//当前剩余电量
		int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
		//电量最大值
		int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
		//电量百分比
		batteryPct = level / (float)scale *100;
		//当前电量
		int curpower = (int) batteryPct;
		// 是否在充电
		int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
		boolean isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
		                     status == BatteryManager.BATTERY_STATUS_FULL;
		if(curpower <= 30 && !isCharging)
		{
			//电量不足，请链接充电器
        	dialogTest(cn.getString(R.string.power_reminder01));
			return false;
		}
		if(curpower <= 30 && isCharging)
		{
			//请保持链接充电器
			dialogTest(cn.getString(R.string.power_reminder02));
			return true;
		}
		return true;
    }
    
    //05-19修改 改变样式 
    private void changeStyle(){
//    	update_but.setTextColor(this.getResources().getColor(R.drawable.buttoncolor2));
    	update_but.setBackground(this.getResources().getDrawable(R.mipmap.p6_05));
	}
    //05-19修改 还原样式
    private void returnStyle(){
//    	update_but.setTextColor(this.getResources().getColor(R.drawable.buttoncolor));
    	update_but.setBackground(this.getResources().getDrawable(R.drawable.button_p6));
    }
    
    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
    	if(!mDismiss.isEnabled() && keyCode == KeyEvent.KEYCODE_BACK){
    		return true;
    	}
		return super.onKeyDown(keyCode, event);
	}

	public void deleteSource(boolean b){
        mUpdateUtils.deleteSource(b);
    }

    @Override
    public void onProgress(final int progress) {
        mHandler.post(new Runnable(){

            @Override
            public void run() {
                if(progress == 0){
//                    TextView tv = (TextView) mInflater.inflate(R.layout.medium_text, null);
//                    tv.setText(R.string.install_ota_output_checking);
//                    mOutputField.addView(tv);
                	String str = cn.getString(R.string.install_ota_output_checking);
                	tv.append(str);
                }else if(progress == 100){
//                    TextView tv = (TextView) mInflater.inflate(R.layout.medium_text, null);
//                    tv.setText(R.string.install_ota_output_check_ok);
//                    mOutputField.addView(tv);
                	String str = cn.getString(R.string.install_ota_output_check_ok);
                	tv.append(str);
                }
                mProgressBar.setProgress(progress/2);                
            }            
        });        
    }

    @Override
    public void onVerifyFailed(int errorCode, Object object) {
    	
     final int errorcode = errorCode;
        mHandler.post(new Runnable(){
            @Override
            public void run() {
//                TextView tv = (TextView) mInflater.inflate(R.layout.medium_text, null);
//                tv.setText(R.string.install_ota_output_check_error);
//                mOutputField.addView(tv);
            	String str = cn.getString(R.string.install_ota_output_check_error);
            	tv.append(str);
                mDismiss.setEnabled(true);
                update_but.setEnabled(true); //05-05
                returnStyle();//05-19修改  还原update按钮的样式
                //report verfy fail
                LogUtil.log(Log.DEBUG,"fota", "verify fail errorcode:" + errorcode);
                TaskStatusDao reportStatus = new TaskStatusDao(cn);
                int taskid = reportStatus.getTaskId(OtaConstant.FIRMWARM_TASK, OtaConstant.TASK_STATUS_CHECK_SUC);
                if(errorcode == 0)
                {
                	reportStatus.UpdateStatus(OtaConstant.TASK_STATUS_SIGCHECK_FAIL_INVALID_UPGRADE_PACKAGE,taskid);
                }
                else if (errorcode == 1)
                {
					reportStatus.UpdateStatus(OtaConstant.TASK_STATUS_SIGCHECK_FAIL_FILE_NOT_EXIT,taskid);
				}
                reportStatus.UpdateFinish(taskid);
                new FileUtil().deleteFile(OtaConstant.getCache(cn));
                reportStatus.reportServer(taskid);
                reportStatus.deleteModel();
            }}        
        );        
    }

    @Override
    public void onCopyProgress(final int progress) {
        mHandler.post(new Runnable(){
            @Override
            public void run() {
                if(progress == 0){
//                    TextView tv1 = (TextView) mInflater.inflate(R.layout.medium_text, null);
//                    tv1.setText(R.string.install_ota_output_copying);
//                    mOutputField.addView(tv1);
                	String str = cn.getString(R.string.install_ota_output_copying);
                	tv.append(str);
                }else if(progress == 100){
//                    TextView tv = (TextView) mInflater.inflate(R.layout.medium_text, null);
//                    tv.setText(R.string.install_ota_output_copy_ok);
//                    mOutputField.addView(tv);
//                    tv = (TextView) mInflater.inflate(R.layout.medium_text, null);
//                    tv.setText(R.string.install_ota_output_restart);
//                    mOutputField.addView(tv);
                	String str1 = cn.getString(R.string.install_ota_output_copy_ok);
                	String str2 = cn.getString(R.string.install_ota_output_restart);
                	tv.append(str1+str2);
                }        
                mProgressBar.setProgress(50 + progress/2);
            }            
        });        
    }

    @Override
    public void onCopyFailed(int errorCode, Object object) {
        mHandler.post(new Runnable(){
            @Override
            public void run() {
//                TextView tv = (TextView) mInflater.inflate(R.layout.medium_text, null);
//                tv.setText(R.string.install_ota_output_copy_failed);
//                mOutputField.addView(tv);
            	String str = cn.getString(R.string.install_ota_output_copy_failed);
            	tv.append(str);
                mDismiss.setEnabled(true);
                update_but.setEnabled(true); //05-05
                returnStyle();//05-19修改  还原update按钮的样式
                mUpdateUtils.installPackage(cn, new File(mPackagePath));
            }            
        });        
    }
}
