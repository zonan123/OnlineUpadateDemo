package com.fota.receiver;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.fota.dao.ApkDao;
import com.fota.model.ApkModel;
import com.fota.sys.OtaConstant;
import com.fota.task.DownloadApkTask;
import com.fota.util.LogUtil;
import com.fota.util.OtaAlarmService;
import com.fota.util.OtaServerOperation;
import com.fota.util.OtaSharePreferenceUtil;

public class OtaAlarmReciver extends BootReceiver {
	@Override
	public void onReceive(Context context, Intent intent) {

		if (intent.getAction().equals("com.fota.alarm")) {
			LogUtil.log(Log.DEBUG, "fota", "recive the ota alarm");
			OtaSharePreferenceUtil.saveBooleanValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.ALLOW_VISIT, true);

			OtaSharePreferenceUtil.saveBooleanValue(context, OtaConstant.OTA_SP_INFO, OtaConstant.IS_VISITING, false);

			OtaServerOperation otaServerOperation = new OtaServerOperation(context, null, OtaConstant.OTA_VISIT_CYCLE);

			Thread thread = new Thread(otaServerOperation);

			thread.start();
		} else if (intent.getAction().equals("com.fota.apkAlarm")) {
			//LogUtil.log(Log.DEBUG, "fota", "recive the download apk");
			ApkModel apkModel = ApkDao.getApkInfo(context);
			if (apkModel==null) {
				new OtaAlarmService(context).setAlarm(OtaConstant.OTA_CYCLE_APK_TIME, OtaConstant.OTA_CYCLE_APK_ALARM);
				LogUtil.log(Log.DEBUG, "fota", " OtaAlarmReciver apk model  null");
			} else {
				DownloadApkTask downloadApk = new DownloadApkTask(apkModel, context);
				Thread thread = new Thread(downloadApk);
				thread.start();
				LogUtil.log(Log.DEBUG, "fota", "OtaAlarmReciver apk model is not null");
			}
		}
	}
}
