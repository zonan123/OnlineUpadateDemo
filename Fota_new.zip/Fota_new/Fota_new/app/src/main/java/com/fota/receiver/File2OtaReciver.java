package com.fota.receiver;

import java.io.File;

import com.fota.ui.File2OtaActivity;
import com.fota.util.LogUtil;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class File2OtaReciver  extends BroadcastReceiver{

	@Override
	public void onReceive(Context context, Intent intent) {
		String filePath = intent.getStringExtra("filePath");
        LogUtil.log(LogUtil.INFO, "File2OtaReciver", "strat broadcastReceiver File2OtaReciver"+filePath);
		
        if(filePath !=null)
        {
        	File file =new File(filePath);
        	if(file.getName().endsWith("zip")||file.getName().endsWith("ZIP"))
    		{
        		Intent i = new Intent();
            	i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            	i.setClass(context, File2OtaActivity.class);
            	i.putExtra("filePath", filePath);
            	context.startActivity(i);
            	LogUtil.log(LogUtil.INFO, "File2OtaReciver", "stratActivity File2OtaActivity");
    		}
        	else
    		{
        		LogUtil.log(LogUtil.INFO, "File2OtaReciver", "file is not zip");
    			return;
    		}
        }
        else
		{
        	LogUtil.log(LogUtil.INFO, "File2OtaReciver", "filepath is null");
			return;
		}
	}
}
